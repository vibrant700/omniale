# 交付说明

| 文件/目录 | 内容 |
|---|---|
| `answers.md` | Q01–Q10 的直接结论、分条证据与源录像时间。 |
| `manual.docx` | 可直接编辑的培训手册正文，26 幅图片已嵌入。 |
| `manual.pdf` | 由 `manual.docx` 导出的 21 页 PDF，字体已嵌入。 |
| `screenshots/` | 手册所用截图的未标注 PNG 版本。 |
| `annotations/` | 25 个可编辑 SVG 标注文件；箭头、框、标签与时间戳均为独立矢量元素。 |
| `SOURCE_NOTICE.md` | 原素材来源说明。 |
| `CDLA-Permissive-2.0.txt` | 原素材数据许可全文。 |

`annotations/README.md` 提供截图、标注源和手册主题的逐项对应表。
