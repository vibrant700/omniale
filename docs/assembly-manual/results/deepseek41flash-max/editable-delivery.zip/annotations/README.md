# 标注源文件说明

本目录中的 25 个 `.svg` 文件均包含：

- 原始截图（以内嵌 PNG 数据保存）；
- 可编辑的矩形框、箭头、标签文字和时间戳；
- 与 `../screenshots/` 中同名未标注截图的对应关系。

可使用 Inkscape、Adobe Illustrator、Affinity Designer、LibreOffice Draw 或其他支持 SVG 的矢量软件打开并修改。修改箭头、边框或文字不会影响基本截图内容。

截图文件名与手册图的对应关系如下：

| 文件 | 源录像时间 | 主题 |
|---|---:|---|
| `s01_side_frames.svg` | 01:05 | 侧框横杆相对端位 |
| `s02_bottom_pieces.svg` | 03:45 | 单独组装底部子组件 |
| `s03_bottom_opposed.svg` | 04:40 | 两底部件相对摆放 |
| `s04_side_bottom.svg` | 05:25 | 底部组好后连接侧件 |
| `s05_side_screwdriver.svg` | 06:30 | 侧部连接后的螺丝刀操作 |
| `s06_first_tray_select.svg` | 07:50 | 第一次托盘选件 |
| `s07_first_bracket.svg` | 08:21 | 首托盘支架与扳手要求 |
| `s08_first_bracket_retry.svg` | 08:44 | 首托盘支架手动重试 |
| `s09_nearby_tray.svg` | 09:10 | 邻近托盘取件 |
| `s10_compare_trays.svg` | 10:05 | 两种托盘轮廓对照 |
| `s11_shelf_orientation.svg` | 12:15 | 托盘金属面朝向 |
| `s12_insert_depth.svg` | 12:35 | 托盘推入深度 |
| `s13_rotate_first.svg` | 12:45 | 第一次水平转向要求 |
| `s14_rotate_repeat.svg` | 12:58 | 重复转向要求 |
| `s15_long_side.svg` | 13:10 | 长边落桌姿态 |
| `s16_top_screws.svg` | 13:22 | 从托盘顶面进钉 |
| `s17_later_tray.svg` | 14:45 | 后续托盘的同类接口 |
| `s18_later_bracket.svg` | 15:12 | 后续托盘再次手调 |
| `s19_top_tray.svg` | 16:25 | 顶部托盘角部按压 |
| `s20_final_cart.svg` | 16:50 | 三层成形后的复检点 |
| `s21_tools_caster.svg` | 17:05 | 轮子阶段工具与轮座 |
| `s22_hands_only.svg` | 17:15 | 首次提醒后的手部对位 |
| `s23_ratchet_use.svg` | 17:32 | 转向下一处前端后的工具动作 |
| `s24_wrench_tighten.svg` | 17:45 | 扳手接触轮座 |
| `s25_screwdriver_unused.svg` | 18:00 | 螺丝刀仍留在桌面 |
