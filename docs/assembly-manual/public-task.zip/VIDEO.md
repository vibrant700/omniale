# 输入录像

[下载完整原始录像](https://github.com/vibrant700/omniale/releases/download/assembly-manual-v1/z057-june-28-22-rashult_assemble.mp4)

SHA256: 2f8f8cd7b19491279f4b224d860a97ee43a025a29aa5b6eaa4df9a561740aad3
