# 原始录像

下载录像：
https://github.com/vibrant700/omniale/releases/download/assembly-manual-v1/z057-june-28-22-rashult_assemble.mp4

将下载文件命名为 `recording.mp4`，与 `TASK.md` 放在同一目录，再按委托完成工作。

录像约18分31秒，包含第一人称画面及原发布音频。来源和许可见 `SOURCE_NOTICE.md` 与 `CDLA-Permissive-2.0.txt`。
