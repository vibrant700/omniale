"""Build the original, modular SCV. Run with Blender 5.3 in background mode."""
import json
import sys
from pathlib import Path

import bpy
from mathutils import Matrix, Quaternion, Vector

HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE))
from model import arms, body, core as g, legs

DEST=HERE.parent


def world(scene, name, tint, strength):
    w=bpy.data.worlds.new(name)
    w.use_nodes=True
    w.node_tree.nodes['Background'].inputs[0].default_value=tint
    w.node_tree.nodes['Background'].inputs[1].default_value=strength
    scene.world=w


def area(col,name,loc,target,energy,size,tint=(1,1,1),shape='DISK',size_y=None):
    data=bpy.data.lights.new(name,'AREA')
    data.energy=energy;data.color=tint;data.shape=shape;data.size=size
    if size_y is not None: data.size_y=size_y
    o=bpy.data.objects.new(name,data)
    col.objects.link(o);o.location=loc
    o.rotation_euler=(Vector(target)-o.location).to_track_quat('-Z','Y').to_euler()
    return o


def view(scene,layer,pose,focus=(0,0,0),ortho=None):
    n='Asset inspection / 3Q'
    cam=bpy.data.cameras.new(n);o=bpy.data.objects.new(n,cam);layer.objects.link(o)
    o.location=pose;o.rotation_euler=(Vector(focus)-o.location).to_track_quat('-Z','Y').to_euler()
    if ortho:cam.type='ORTHO';cam.ortho_scale=ortho
    scene.camera=o
    return o


def render_settings(s, width, height):
    s.render.engine='CYCLES';s.cycles.samples=24;s.cycles.use_denoising=True
    s.cycles.max_bounces=6;s.cycles.diffuse_bounces=3;s.cycles.glossy_bounces=3
    s.render.resolution_x=width;s.render.resolution_y=height;s.render.resolution_percentage=100
    s.render.image_settings.file_format='PNG';s.render.image_settings.color_mode='RGB'
    s.view_settings.view_transform='AgX'
    s.render.threads_mode='FIXED';s.render.threads=12


def frame_bounds(o_coll):
    bpy.context.view_layer.update()
    dg=bpy.context.evaluated_depsgraph_get()
    points=[]
    for o in o_coll.all_objects:
        if o.type not in ('MESH','CURVE'):continue
        e=o.evaluated_get(dg)
        if o.type=='CURVE':
            converted=e.to_mesh()
            points.extend(e.matrix_world @ v.co for v in converted.vertices)
            e.to_mesh_clear()
        else:
            points.extend(e.matrix_world @ Vector(v) for v in e.bound_box)
    lo=Vector([min(p[i] for p in points) for i in range(3)])
    hi=Vector([max(p[i] for p in points) for i in range(3)])
    return lo,hi


def place_part_origins(o_coll):
    """Keep part transforms local without moving visible geometry or control pivots."""
    for o in o_coll.all_objects:
        if o.type != 'MESH' or not o.data.vertices:
            continue
        c = sum((v.co for v in o.data.vertices), Vector((0,0,0))) / len(o.data.vertices)
        o.data.transform(Matrix.Translation(-c))
        o.location += o.matrix_basis.to_3x3() @ c


def main():
    bpy.ops.wm.read_factory_settings(use_empty=True)
    s=bpy.context.scene
    s.name='ASSET | Inspection'
    rootcol=g.group('SCV-07 | Mobile Service Chassis',s.collection)
    rootcol.asset_mark()
    rootcol.asset_data.description='Rebuilt SCV: oxide red hull, open pilot well, paired power nacelles, asymmetrical hydraulic tools.'
    for name in ('Mech','Hard surface','Industrial'):
        rootcol.asset_data.tags.new(name)
    g.scope(rootcol,None)
    g.ROOT=g.empty('CTRL / SCV master',size=.27)
    g.ROOT['Coordinates']='Right-handed; +Z up; faces -Y; left = +X; neutral maximum size = 2.'
    g.scope(rootcol,g.ROOT)
    normalization=g.empty('REF / Normalized reference space',size=.16)
    g.scope(rootcol,normalization);g.MAP=g.empty('REF / Material reference origin',size=.09)
    g.palette()
    for name,func in [('01 | Pilot capsule and power pack',body.build),
                      ('02 | Right shoulder and excavation tool',lambda: arms.build(-1)),
                      ('03 | Left shoulder and clamp',lambda: arms.build(1)),
                      ('04 | Right suspension and foot',lambda: legs.build(-1)),
                      ('05 | Left suspension and foot',lambda: legs.build(1))]:
        col=g.group(name,rootcol)
        g.scope(col,normalization)
        func()
    for key,value in g.C.items():
        o=value[0] if isinstance(value,tuple) else value
        o['Control ID']=key
        if isinstance(value,tuple): o['Swing axis']=list(value[1])
    place_part_origins(rootcol)
    lo,hi=frame_bounds(rootcol);center=(lo+hi)/2;scale=2/max(hi-lo)
    normalization.scale=(scale,)*3;normalization.location=-center*scale
    print('SCV normalized bounds:',*[list(p) for p in frame_bounds(rootcol)],'parts:',len(rootcol.all_objects))
    p=g.group('Studio | Not part of asset',s.collection)
    world(s,'Orthographic reference studio',(.16,.18,.22,1),.65)
    spec=json.loads((DEST/'media/reference_spec/scene_setup.json').read_text(encoding='utf-8'))
    for l in spec['lights']:
        area(p,l['name'],l['location'],l['target'],l['energy'],l['size'],l['color'])
    view(s,p,(-3.3,-5.7,2.45),(0,-.02,0),2.54)
    cam_data=json.loads((DEST/'media/reference_spec/cameras.json').read_text(encoding='utf-8'))
    refcol=g.group('Reference | Six matching orthographic cameras',s.collection)
    for item in cam_data['views']:
        name='REF / '+item['id'].upper()
        d=bpy.data.cameras.new(name);o=bpy.data.objects.new(name,d);refcol.objects.link(o)
        d.type='ORTHO';d.ortho_scale=cam_data['orthographic_scale']
        d.clip_start=item['clip_start'];d.clip_end=item['clip_end']
        o.matrix_world=Matrix(item['camera_to_world'])
        o.hide_set(True)
    render_settings(s,1280,1280);s.render.film_transparent=True
    s.render.image_settings.color_mode='RGBA'
    s.render.filepath='//asset_inspection.png'
    for screen in bpy.data.screens:
        for ar in screen.areas:
            if ar.type=='VIEW_3D':
                sp=ar.spaces.active
                sp.region_3d.view_rotation=Quaternion(s.camera.rotation_euler.to_quaternion())
                sp.region_3d.view_distance=3.8
                sp.region_3d.view_location=(0,0,0)
                sp.shading.color_type='MATERIAL';sp.shading.show_cavity=True
                sp.overlay.show_extras=False;sp.overlay.show_floor=False
                sp.overlay.show_axis_x=False;sp.overlay.show_axis_y=False
    bpy.context.preferences.filepaths.save_version=0
    bpy.ops.wm.save_as_mainfile(filepath=str(DEST/'asset.blend'))


if __name__=='__main__': main()
