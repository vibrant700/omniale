from . import core as g
from .core import *


def build():
    box('Pilot capsule / rear pressure bulkhead',(0,.21,.225),(.287,.315,.51),'darkred',.036)
    prism('Pelvis / folded primary casting',[(-.25,.18),(-.23,-.117),(-.136,-.247),(.136,-.247),(.23,-.117),(.25,.18)],
          'Y',.012,.466,'darkred',.015)
    box('Pelvis / lower front housing',(0,-.015,-.098),(.215,.20,.192),'gun',.015)
    for s in (-1,1):
        x=s*.245
        tube('Hip crossmember',(.13*s,.247,-.152),(.36*s,.247,-.152),.098,'gun')
        ring('Hip swivel wear band',(.345*s,.247,-.152),(s,0,0),.105,.08,.025,'steel')
        beam('Primary upright',(.244*s,.177,-.205),(.227*s,.18,.731),.115,.177,'gun',.015)
        # Armor towers lean back toward the top, exposing the seated pilot.
        poly=[(-.083,.0),(-.075,.393),(.008,.474),(.054,.788),(.13,.796),(.375,.75),
              (.363,.49),(.456,.388),(.415,.024),(.24,-.006)]
        prism('Shoulder tower / welded armor',poly,'X',min(.139*s,.353*s),max(.139*s,.353*s),'red',.018)
        inner=.175*s
        beam('Inboard backbone',(inner,-.08,.042),(inner,.007,.444),.047,.061,'darkred')
        beam('Tower side seam',(s*.35,-.07,.042),(s*.334,-.076,.417),.028,.04,'red2')
        # Face frame and recessed radiator.
        aa=V((s*.229,-.074,.456)); bb=V((s*.219,.026,.767))
        d=(bb-aa).normalized(); nh=V((0,-d.z,d.y)); side=V((1,0,0))
        r=Matrix((side,-nh,d)).transposed()
        box('Heat exchanger / red surround',(aa+bb)/2,(.144,.034,.333),'red2',.010,r)
        box('Heat exchanger / black recess',(aa+bb)/2+nh*.021,(.111,.016,.307),'dark',.004,r)
        for i in range(22):
            q=aa.lerp(bb,(i+.68)/23)+nh*.032
            box('Recessed radiator blade %02d'%i,q,(.103,.016,.0065),'gun' if i%3 else 'steel',.0013,r)
        for k in (-1,1):
            beam('Heat exchanger / frame wear edge',aa+side*k*.071+nh*.023,bb+side*k*.069+nh*.023,.012,.014,'gun',.002)
        for i in (.05,.91):
            for k in (-1,1):
                bolt('Radiator panel screw',aa.lerp(bb,i)+side*k*.061+nh*.023,nh,.0053)
        box('Chest / face instrument bay',(x,-.092,.228),(.177,.059,.436),'darkred',.011)
        for k in (-1,1):
            box('Chest / tall enamel cheek',(x+k*.073,-.107,.242),(.031,.06,.407),'red2',.005)
        box('Chest / black faceplate cutout',(x,-.129,.267),(.111,.011,.145),'dark',.003)
        box('Chest / upper quick-change cover',(x,-.152,.342),(.102,.028,.138),'red2',.007,
            Matrix.Rotation(-.06,3,'X'))
        for dx,z in [(-.037,.395),(.036,.395),(-.038,.29),(.037,.29)]:
            bolt('Cover screw',(x+dx,-.17,z),r=.006)
        if s==1: decal('Lead tower / 07',(x,-.1705,.344),(.068,0,0),(0,0,.067),'digits')
        else: decal('Aux tower / inspection legend',(x,-.1705,.344),(.069,0,0),(0,0,.07),'service')
        box('Chest / folded mid rail',(x,-.154,.197),(.13,.064,.035),'red',.006)
        box('Chest / enamel toe plate',(x,-.169,.143),(.114,.057,.059),'red2',.006, -.25)
        box('Chest / lamp socket',(x,-.159,.075),(.133,.051,.077),'gun',.012)
        for j in (-1,0,1):
            box('Floodlight / ivory diffuser',(x+j*.035,-.188,.082),(.029,.014,.049),'ivory',.005)
        for k in (-1,1):
            bolt('Light mount screw',(x+k*.067,-.175,.069),r=.005)
        # Rear tower face and hinge housings.
        beam('Tower / rear cladding',(.215*s,.396,.398),(.199*s,.365,.751),.105,.065,'red2',.010)
        for z,y in [(.447,.429),(.557,.414),(.706,.405)]:
            for dx in (-.035,.036): bolt('Tower cladding / rivet',(s*.204+dx,y,z),(0,1,0),.006)
        tube('Rear tower / ceramic cap',(.241*s,.398,.6),(.241*s,.454,.6),.032,'gun')
        tube('Rear tower / cap face',(.241*s,.451,.6),(.241*s,.462,.6),.025,'steel')
        beam('Radiator top guard',(.155*s,.087,.787),(.155*s,.366,.771),.016,.020,'steel',.003)
        beam('Radiator top guard',(.283*s,.087,.793),(.299*s,.351,.755),.016,.020,'gun',.003)
        for y,z in [(.093,.788),(.26,.773)]:
            beam('Welded tower lifting tab',(s*.226,y,z),(s*.225,y+.025,z+.029),.018,.010,'steel',.0016)
        beam('Tower side / conduit rail',(.348*s,.035,.456),(.32*s,.086,.758),.027,.034,'steel',.004)
        for y,z in [(.08,.785),(.18,.78),(.315,.752)]:
            box('Tower crown / segmented service lug',(s*.247,y,z),(.079,.042,.018),'red2',.003,-.16)
            bolt('Tower crown / lug stud',(s*.243,y,z+.011),(0,.15,1),.006)
        hose('Tower crown / offset conduit bridge',[(s*.327,.024,.654),(s*.359,.11,.691),
             (s*.358,.277,.655),(s*.327,.344,.622)],.008,'steel')
        hose('External chest cable',[(.166*s,-.174,.083),(.169*s,-.183,.208),(.165*s,-.163,.30),(.161*s,-.126,.426)],.010,'dark',.07,True)
        tube('Canopy trunnion',(s*.122,-.015,.441),(s*.166,-.015,.441),.041,'gun')
        hydraulic('Canopy lift ram',(s*.142,-.062,.126),(s*.141,-.284,.478),.016,'darkred')
        hydraulic('Canopy support',(s*.144,.008,.274),(s*.143,-.15,.445),.012,'gun')

    # Open canopy with the distinctive ochre axial panels.
    oldcol,oldpar=g.COL,g.PAR
    canopy=empty('CTRL / Canopy', (0,-.025,.495))
    g.C['canopy']=canopy
    scope(oldcol,canopy)
    axis=V((0,-.866,-.50))
    up=V((0,-.5,.866))
    mid=V((0,-.205,.525))
    angles=[.09,.49,.90,1.22,1.56,1.90,2.24,2.65,3.05]
    ribs=[(-.159,.097,.116),(-.113,.124,.148),(-.055,.128,.148),(.083,.135,.141),(.145,.119,.119),(.174,.112,.108)]
    vv=[mid+axis*t+V((cos(a)*r,0,0))+up*(sin(a)*h) for t,r,h in ribs for a in angles]
    k=len(angles)
    ff=[(i*k+j,i*k+j+1,(i+1)*k+j+1,(i+1)*k+j) for i in range(len(ribs)-1) for j in range(k-1)]
    if (vv[ff[4][1]]-vv[ff[4][0]]).cross(vv[ff[4][3]]-vv[ff[4][0]]).dot(up)<0:
        ff=[tuple(reversed(f)) for f in ff]
    o=mesh('Canopy / segmented arched enamel',vv,ff,'orange',.003)
    o.data.materials.append(M['red2'])
    for p in o.data.polygons:
        if p.index // (k-1) in (1,4) or p.index%(k-1) in (0,k-2): p.material_index=1
    sol=o.modifiers.new('Pressed shell thickness','SOLIDIFY');sol.thickness=.009;sol.offset=-1
    for i in (0,1,4,5):
        hose('Canopy / raised arch flange',vv[i*k:(i+1)*k],.0052,'steel' if i in (0,5) else 'red2')
    for s in (-1,1):
        j=0 if s==1 else k-1
        hose('Canopy / side lock frame',[vv[i*k+j] for i in range(len(ribs))],.011,'darkred')
        rail=[vv[i*k+j] for i in range(1,len(ribs))]
        deep=[p+V((-s*.004,.009,-.074 if i<3 else -.053)) for i,p in enumerate(rail)]
        o=mesh('Canopy / hinged red side fairing',rail+deep,[(i,i+1,i+6,i+5) for i in range(4)],'red2',.003)
        o.modifiers.new('Fairing wall','SOLIDIFY').thickness=.008
        hose('Canopy / fairing folded edge',deep,.004,'gun')
        for i in (1,3,5):
            bolt('Canopy rim rivet',vv[i*k+j],(s,0,.6),.0058,'chrome')
    # Mark follows the curvature instead of hovering over the shell.
    av=[]; uv=[]
    for i in range(5):
        t=-.052+i*.032
        for j in range(7):
            a=1.06+j*.168
            av.append(mid+axis*t+V((cos(a)*.132,0,0))+up*(sin(a)*(.151-(t+.052)*.064)))
            uv.append((1-j/6,i/4))
    af=[(i*7+j,i*7+j+1,(i+1)*7+j+1,(i+1)*7+j) for i in range(4) for j in range(6)]
    mesh('Canopy / worn direction chevron',av,af,'canopy',uv=uv)
    for i in range(6):
        box('Canopy underside ribs',mid+axis*(-.09+i*.045)+up*.030,(.19,.012,.016),'darkred',.002,-.52)
    scope(oldcol,oldpar)

    # Instrument well, restraints and hoses are visible through the opening.
    box('Cockpit / deep liner',(0,.029,.281),(.233,.133,.379),'dark',.019)
    box('Cockpit / seat back',(0,-.047,.334),(.145,.052,.214),'seat',.019,-.17)
    box('Cockpit / headrest',(0,-.044,.455),(.105,.06,.058),'seat',.014,-.17)
    box('Cockpit / seat squab',(0,-.11,.217),(.159,.154,.042),'seat',.015)
    for i in range(5):
        box('Seat / horizontal stitched rib',(0,-.073+.016*(i/5),.256+i*.028),(.113,.007,.007),'rubber',.002)
    for s in (-1,1):
        x=s*.091
        beam('Pilot arm rest',(s*.099,-.035,.267),(s*.1,-.179,.212),.032,.040,'gun')
        tube('Main pilot lever',(x,-.174,.143),(x,-.223,.236),.010,'steel')
        tube('Main pilot grip',(x-s*.020,-.224,.239),(x+s*.010,-.224,.239),.011,'rubber')
        hose('Pilot harness',[(s*.046,-.066,.422),(s*.047,-.096,.375),(s*.044,-.111,.288),(s*.030,-.125,.246)],
             .006,'copper')
        box('Cockpit / breaker panel',(s*.075,-.182,.093),(.038,.066,.11),'darkred',.007,.16)
        for j in range(3):
            bolt('Pilot toggle',(s*.071,-.216,.064+j*.023),r=.0058,mat='chrome')
    box('Pilot console bridge',(0,-.199,.108),(.137,.075,.091),'red',.009,-.25)
    box('Console / armored instrument screen',(0,-.226,.16),(.071,.070,.01),'gun',.004,-.25)
    box('Console / blue-green display',(0,-.227,.167),(.048,.041,.005),'glass',.003,-.25)
    for i in range(3):
        box('Console / amber status',(i*.016-.016,-.244,.171),(.007,.006,.003),'lamp',.0005,-.25)
    box('Footwell / kick plate',(0,-.11,.031),(.198,.23,.08),'gun',.012)
    for s in (-1,1):
        for j in range(3):
            box('Footwell / pedal tread',(s*.052,-.20+j*.027,.075),(.045,.008,.009),'steel',.001)
    sillpoly=[(-.137,.018),(-.12,-.055),(-.074,-.081),(0,-.092),(.074,-.081),(.12,-.055),(.137,.018),
              (.101,.018),(.089,-.037),(.056,-.057),(0,-.065),(-.056,-.057),(-.089,-.037),(-.101,.018)]
    prism('Cockpit / horseshoe egress sill',sillpoly,'Y',-.278,-.133,'red2',.006)
    hose('Cockpit / ochre sill strike',[(-.123,-.278,-.007),(-.081,-.282,-.051),(0,-.282,-.070),
                                      (.081,-.282,-.051),(.123,-.278,-.007)],.012,'orange')
    cloth()
    reactor()


def cloth():
    # Falling pleats, narrowing to an irregular fork at the bottom.
    vs=[]; uv=[]
    for i in range(23):
        t=i/22
        w=.117*(1-.71*t**1.35)
        for j in range(29):
            u=j/28; a=u*2-1
            z=-.103-.469*t+(.041*a*a+.010*sin(u*102)+.007*cos(u*183))*t**7
            x=w*a+.013*sin(t*3.6)
            y=-.229+.048*t+.012*sin(a*14+t*9)*(.96-t*.50)+.026*a*a
            vs.append((x,y,z));uv.append((u,1-t))
    ff=[]
    for i in range(22):
        for j in range(28):
            if i==21 and (j%7 in (0,1) or j in (13,14)): continue
            k=i*29+j;ff.append((k,k+29,k+30,k+1))
    o=mesh('Livery / hanging service pennant',vs,ff,'cloth',uv=uv)
    for f in o.data.polygons:f.use_smooth=True
    o.modifiers.new('Woven thickness','SOLIDIFY').thickness=.0015
    for s in (-1,1):
        tube('Pennant eye pin',(s*.122,-.223,-.092),(s*.122,-.247,-.092),.009,'steel')
        hose('Pennant hanger',[(s*.122,-.241,-.087),(s*.111,-.247,-.13),(s*.117,-.218,-.185)],.004,'copper')


def reactor():
    box('Power pack / rear cross case',(0,.429,.266),(.507,.233,.375),'darkred',.032)
    box('Power pack / central keystone',(0,.516,.35),(.163,.184,.243),'red2',.025)
    prism('Power pack / ribbed central outlet',[(-.067,.305),(.067,.305),(.058,.188),(.042,.163),(-.048,.163),(-.06,.185)],
          'Y',.606,.638,'gun',.004)
    for i in range(16):
        z=.172+i*.0077
        box('Central outlet / zinc blade',(0,.642,z),(.097+.0016*i,.017,.0037),'steel',.001)
    for s in (-1,1):
        x=s*.213
        z=.296
        shell('Reactor / cast red nacelle',(x,0,z),
              [(.355,.102,.106),(.405,.120,.120),(.483,.118,.119),(.548,.137,.134),(.687,.137,.139),
               (.755,.13,.132),(.775,.117,.117)],(1,0,0),(0,0,1),(0,1,0),'red',48,.005,False)
        for i in range(7):
            theta=i*2*pi/7+.04
            o=shell('Reactor / exposed steel stave',(x,0,z),
                    [(.581,.132,.13),(.645,.141,.143),(.728,.137,.139),(.775,.12,.12)],
                    (1,0,0),(0,0,1),(0,1,0),'steel',8,.002,False,(theta,theta+.64))
            o.modifiers.new('Stave thickness','SOLIDIFY').thickness=.005
        for y,r in [(.514,.122),(.57,.139),(.765,.131)]:
            ring('Reactor / circumferential band',(x,y,z),(0,1,0),r,r-.013,.018,'darkred' if y<.7 else 'steel',48)
        shell('Reactor / recessed bell',(x,0,z),
              [(.759,.126,.126),(.797,.119,.119),(.804,.105,.105),(.792,.090,.090),(.738,.066,.066),
               (.701,.034,.034)],(1,0,0),(0,0,1),(0,1,0),'gun',48,.002)
        ring('Reactor / bright lip',(x,.802,z),(0,1,0),.115,.107,.012,'steel',48)
        for i in range(24):
            th=i*pi/12
            tube('Bell / drilled cooling port',(x+.099*cos(th),.8,z+.099*sin(th)),
                 (x+.099*cos(th),.803,z+.099*sin(th)),.0038,'dark',verts=10,w=.0005)
        tube('Reactor / internal boss',(x,.704,z),(x,.773,z),.048,'dark',r2=.043)
        tube('Reactor / unlit ceramic core',(x,.767,z),(x,.789,z),.031,'ivory',r2=.028)
        for y,z2 in [(.45,.17),(.515,.16),(.437,.416)]:
            bolt('Nacelle stud',(x+s*.11,y,z2),(s,0,0),.008)
        hydraulic('Rear diagonal buffer',(s*.105,.402,.429),(s*.174,.5,.664),.029,'darkred')
    # Faceted spherical power coupler high on the back.
    a=(0,.508,.512); b=(0,.627,.593); a,b,u,v,d=frame(a,b)
    shell('Rear coupler / faceted housing',a,[(-.04,.059,.059),(.007,.101,.098),(.086,.106,.099),
          (.154,.069,.068),(.188,.037,.037)],u,v,d,'red2',10,.005)
    for i in range(5):
        th=i*pi*2/5
        q=a+d*.085+(u*cos(th)+v*sin(th))*.098
        beam('Coupler / steel cage',q-d*.02,q+d*.059,.014,.012,'steel',.002,th)
    poly=[(-.061,.503),(-.044,.553),(.028,.568),(.061,.515),(.007,.47)]
    prism('Coupler / pentagonal alloy socket',poly,'Y',.675,.716,'dark',.005)
    prism('Coupler / pentagonal inset',[(x*.83,.52+(z-.52)*.8) for x,z in poly],'Y',.714,.724,'gun',.003)
    bolt('Coupler / service stud',(0,.713,.608),(0,1,0),.012,'chrome')
    for s in (-1,1):
        hose('Return cable / tower to pelvis',[(s*.348,.411,.325),(s*.407,.511,.23),(s*.38,.637,.03),
             (s*.302,.606,-.097),(s*.114,.492,-.166)],.011,'dark',.09,True)
