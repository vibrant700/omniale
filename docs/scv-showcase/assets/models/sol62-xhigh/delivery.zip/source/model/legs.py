from .core import *


def build(s):
    x=.328*s
    # Short upper links descend into the pronounced backward knee.
    poly=[(-.081,.013),(.2,.037),(.456,-.058),(.64,-.267),(.66,-.387),(.524,-.477),
          (.346,-.44),(.199,-.28),(-.057,-.233)]
    prism('Thigh / four-bar armor casting',poly,'X',x-.114,x+.114,'darkred',.02)
    c=(x,.527,-.37)
    tube('Knee / main axle',(x-.15,c[1],c[2]),(x+.15,c[1],c[2]),.126,'gun')
    for k in (-1,1):
        side=x+k*.152
        ring('Knee / stepped swivel cover',(side,c[1],c[2]),(1,0,0),.104,.073,.026,'red')
        tube('Knee / pivot disc',(side,c[1],c[2]),(side+.018*k,c[1],c[2]),.061,'steel')
        tube('Knee / central insert',(side+.013*k,c[1],c[2]),(side+.021*k,c[1],c[2]),.033,'dark')
        hydraulic('Knee / visible actuator',(x+k*.116,.39,-.225),(x+k*.143,.053,-.689),.033,'dark')
        hose('Knee / return loom',[(x+k*.13,.37,-.22),(x+k*.159,.46,-.33),(x+k*.162,.537,-.52),
                                  (x+k*.105,.412,-.641)],.009,'dark',.1,True)
    panel=[(x-.114,-.012),(x-.073,.026),(x+.075,.026),(x+.115,.001),(x+.099,-.218),
           (x+.075,-.254),(x-.095,-.245)]
    prism('Thigh / red front shin plate',panel,'Y',-.106,-.034,'red2',.012)
    beam('Thigh / lower nickel rim',(x-.082,-.107,-.245),(x+.082,-.107,-.245),.015,.009,'gun',.003)
    decal('Thigh / field serial',(x,-.107,-.088),(.098,0,0),(0,0,.088),'serial')
    for dx,z in [(-.084,-.02),(.084,-.02),(-.077,-.219),(.077,-.219)]:
        bolt('Thigh armor / pan head',(x+dx,-.107,z),r=.008)
    for k in (-1,1):
        hydraulic('Shin / forward exposed shock',(x+k*.055,-.051,-.246),
                  (x+k*.065,-.006,-.575),.030,'gun')
        ring('Shin / accordion boot ring',(x+k*.058,-.035,-.337),(0,-.13,1),.031,.025,.015,'rubber')
        for i in range(4):
            ring('Shin / boot rib',(x+k*.058,-.033,-.345-i*.011),(0,-.13,1),.030,.023,.006,'rubber')
        hose('Shin / service line',[(x+k*.102,-.061,-.205),(x+k*.109,-.079,-.34),
             (x+k*.095,-.059,-.502),(x+k*.068,-.015,-.56)],.009,'dark',.07)
    box('Shin / central exposed piston mount',(x,.006,-.423),(.127,.102,.052),'darkred',.007)
    for i in range(4):
        box('Rear thigh / red cross lamination',(x,.47+i*.013,-.106-i*.058),(.187,.23,.032),'red2',.006)
    for k in (-1,1):
        box('Rear thigh / zinc clip',(x+k*.052,.605,-.204),(.044,.031,.088),'steel',.004,.20)
        bolt('Rear thigh / panel screw',(x+k*.052,.626,-.198),(0,1,0),.008)

    # The calf is an inclined cage with paired, rearward stabilizer rams.
    aa=V((x,.123,-.711)); bb=V((x,.564,-.501))
    d=(bb-aa).normalized(); v=V((0,-d.z,d.y))
    r=Matrix((V((1,0,0)),v,-d)).transposed()
    box('Calf / canted central sled',(aa+bb)/2,(.224,.129,(bb-aa).length),'darkred',.023,r)
    for k in (-1,1):
        az=aa+V((k*.127,0,0)); bz=V((x+k*.134,.907,-.383))
        hydraulic('Calf / trailing stabilizer',az,bz,.041,'gun')
        tube('Stabilizer / heel bumper',bz-d*.023,bz+d*.006,.044,'red2')
        tube('Stabilizer / end cap',bz,bz+d*.012,.035,'steel')
        for f in (.20,.29,.42,.57,.69):
            q=az.lerp(bb+V((k*.127,0,0)),f)
            ring('Calf / curved red frame rib',q,d,.055,.039,.024,'red2')
        hydraulic('Rear suspension / near-vertical spring strut',(x+k*.128,.531,-.604),
                  (x+k*.127,.56,-.367),.026,'gun')
        bolt('Suspension / rear bright pin',(x+k*.127,.589,-.367),(0,1,0),.028,'chrome',False)
        hose('Calf / braided pigtail',[(bz.x,.745,-.452),(bz.x+k*.024,.784,-.489),(bz.x+k*.032,.815,-.501),
                                     (bz.x+k*.045,.827,-.47)],.007,'dark',.07,True)
    for i in range(2):
        o=aa.lerp(bb,.57+i*.29)-v*.065
        q=o+V((0,.075,-.115))
        tube('Calf / lower shock reservoir',o,q,.062,'gun')
        ring('Calf / reservoir red collar',q,(0,.53,-.85),.065,.050,.017,'red2')
        ring('Calf / machined end ring',q+V((0,.005,-.007)),(0,.53,-.85),.055,.042,.012,'steel')
        tube('Calf / inset end plug',q+V((0,.005,-.007)),q+V((0,.01,-.017)),.027,'dark')
    for i in range(3):
        p=aa.lerp(bb,.14+i*.105)-v*.08
        box('Calf / underslung step plate',p,(.19,.025,.041),'steel',.004,r)
        for k in (-1,1):
            bolt('Calf / step fastener',p+V((k*.076,0,-.016)),(0,.40,-1),.006)

    # Load-bearing feet, curved red sabatons and exposed chevron treads.
    sole=[(-.139,-.811),(-.096,-.766),(-.029,-.729),(.119,-.728),(.23,-.761),
          (.312,-.772),(.358,-.818),(-.107,-.822)]
    prism('Foot / welded side profile',sole,'X',x-.150,x+.150,'dark',.009)
    for k in (-1,1):
        tube('Ankle / shaft bearing',(x+k*.125,.239,-.741),(x+k*.156,.239,-.741),.053,'steel')
        tube('Ankle / inset hub',(x+k*.151,.239,-.741),(x+k*.165,.239,-.741),.034,'dark')
        tube('Toe / rocker disc',(x+k*.133,.036,-.772),(x+k*.16,.036,-.772),.043,'gun')
        bolt('Toe / deep center',(x+k*.162,.036,-.771),(k,0,0),.022,'gun',False)
    for j in range(4):
        yy=-.105+j*.102
        for k in (-1,1):
            box('Foot / segmented ground pad',(x+k*.054,yy,-.811),(.098,.078,.029),'steel',.005)
            box('Foot / traction rib',(x+k*.057,yy+.012,-.825),(.087,.022,.003),'dark',.001)
    for k in (-1,1):
        beam('Foot / sole rail',(x+k*.126,-.113,-.798),(x+k*.126,.331,-.798),.038,.040,'steel')
        box('Foot / toe block',(x+k*.102,-.098,-.782),(.056,.082,.071),'gun',.005)
    hood=shell('Foot / pressed arch shield',(x,0,-.726),
         [(-.115,.149,.081),(-.079,.147,.127),(-.011,.137,.169),(.083,.121,.198),(.139,.095,.185)],
         (1,0,0),(0,0,1),(0,1,0),'red2',16,.003,False,(.04,pi-.04))
    hood.modifiers.new('Steel plate wall','SOLIDIFY').thickness=.010
    for i in (0,1):
        a=[(x+.147*cos(j*pi/13),-.115+i*.022,-.726+(.083+.023*i)*sin(j*pi/13)) for j in range(14)]
        hose('Foot / scrape-polished leading edge',a,.0045,'steel' if not i else 'red')
    box('Toe / red inset step',(x,-.118,-.736),(.176,.045,.036),'red',.006,-.19)
    beam('Toe / lower zinc shelf',(x-.08,-.129,-.753),(x+.08,-.129,-.753),.014,.022,'steel',.003)
    for k in (-1,1):
        bolt('Toe hood rivet',(x+k*.064,-.094,-.635),(k*.36,-.75,.56),.007)
        prism('Toe / triangular strike plate',[(x+k*.108,-.049),(x+k*.193,.015),(x+k*.117,.026)],
              'Z',-.718,-.708,'steel',.001)
