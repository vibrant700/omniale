import math
from math import sin, cos, pi
from pathlib import Path
import random

import bpy
from mathutils import Vector, Matrix

V = Vector
M = {}
C = {}
COL = None
PAR = None
ROOT = None
MAP = None
ART = Path(__file__).resolve().parents[2] / 'media' / 'decals'


def scope(col, parent):
    global COL, PAR
    COL, PAR = col, parent


def group(name, parent):
    c = bpy.data.collections.new(name)
    parent.children.link(c)
    return c


def attach(o, mat=None, parent=True):
    for c in list(o.users_collection):
        c.objects.unlink(o)
    COL.objects.link(o)
    if mat is not None:
        o.data.materials.append(M[mat] if isinstance(mat, str) else mat)
    if PAR and parent:
        mx = o.matrix_world.copy()
        o.parent = PAR
        o.matrix_world = mx
    return o


def empty(name, loc=(0, 0, 0), size=.12):
    o = bpy.data.objects.new(name, None)
    o.location = loc
    o.empty_display_type = 'PLAIN_AXES'
    o.empty_display_size = size
    COL.objects.link(o)
    if PAR:
        o.parent = PAR
        o.matrix_parent_inverse = PAR.matrix_world.inverted()
    bpy.context.view_layer.update()
    return o


def bevel(o, w, segments=3):
    if w:
        m = o.modifiers.new('Machined edge radius', 'BEVEL')
        m.width, m.segments = w, segments
        m.affect = 'EDGES'
        m.harden_normals = True
        n = o.modifiers.new('Corner-weighted normals', 'WEIGHTED_NORMAL')
        n.keep_sharp = True
        for p in o.data.polygons:
            p.use_smooth = True
    return o


def mesh(name, vs, fs, mat, w=0, uv=None):
    me = bpy.data.meshes.new(name)
    me.from_pydata(vs, [], fs)
    me.update()
    o = bpy.data.objects.new(name, me)
    attach(o, mat)
    if uv:
        layer = me.uv_layers.new()
        for p in me.polygons:
            for li, vi in zip(p.loop_indices, p.vertices):
                layer.data[li].uv = uv[vi]
    return bevel(o, w)


def box(n, p, size, mat, w=.007, rot=None):
    px, py, pz = p
    a, b, c = (d/2 for d in size)
    verts = [(-a,-b,-c),(a,-b,-c),(a,b,-c),(-a,b,-c),
             (-a,-b,c),(a,-b,c),(a,b,c),(-a,b,c)]
    if rot is not None:
        R = rot if isinstance(rot, Matrix) else Matrix.Rotation(rot, 3, 'X')
        verts = [R @ V(v) for v in verts]
    return mesh(n, [(px+x,py+y,pz+z) for x,y,z in verts],
                [(3,2,1,0),(0,1,5,4),(1,2,6,5),(2,3,7,6),(3,0,4,7),(4,5,6,7)], mat,w)


def prism(n, poly, axis, low, high, mat, w=.004):
    indices = {'X':(1,2,0),'Y':(0,2,1),'Z':(0,1,2)}[axis]
    vs = []
    for d in (low, high):
        for u,v in poly:
            xyz = [0,0,0]
            for i,t in zip(indices,(u,v,d)):
                xyz[i] = t
            vs.append(xyz)
    k=len(poly)
    signed = sum(poly[i][0]*poly[(i+1)%k][1]-poly[i][1]*poly[(i+1)%k][0] for i in range(k))
    fs = [tuple(reversed(range(k))),tuple(range(k,2*k))]
    fs += [(i,(i+1)%k,(i+1)%k+k,i+k) for i in range(k)]
    if signed * (-1 if axis=='Y' else 1) < 0:
        fs = [tuple(reversed(f)) for f in fs]
    return mesh(n,vs,fs,mat,w)


def shell(n, c, rings, radial_u, radial_v, axis, mat, segments=32, w=.002, caps=True, span=(0,2*pi)):
    c, u, v, a = map(V,(c,radial_u,radial_v,axis))
    span0, span1 = span
    closed = abs(span1-span0-2*pi) < 1e-5
    k = segments if closed else segments+1
    vs = [c+a*d+u*(r*cos(span0+(span1-span0)*i/segments))+v*(t*sin(span0+(span1-span0)*i/segments))
          for d,r,t in rings for i in range(k)]
    f = [(j*k+i,j*k+(i+1)%k,(j+1)*k+(i+1)%k,(j+1)*k+i)
         for j in range(len(rings)-1) for i in range(segments)]
    if caps and closed:
        f += [tuple(reversed(range(k))), tuple(range((len(rings)-1)*k,len(rings)*k))]
    if u.cross(v).dot(a) < 0:
        f = [tuple(reversed(x)) for x in f]
    o=mesh(n,vs,f,mat,w)
    for p in o.data.polygons:
        p.use_smooth = len(p.vertices)==4
    return o


def frame(a,b):
    a,b=V(a),V(b)
    d=(b-a).normalized()
    u=d.cross(V((0,0,1) if abs(d.z)<.85 else (0,1,0))).normalized()
    v=d.cross(u)
    return a,b,u,v,d


def tube(n,a,b,r,mat,r2=None,verts=24,w=.002):
    a,b,u,v,d=frame(a,b)
    r2=r if r2 is None else r2
    return shell(n,a,[(0,r,r),((b-a).length,r2,r2)],u,v,d,mat,verts,w)


def ring(n,c,d,ro,ri,depth,mat,segments=32):
    _,_,u,v,a = frame(c,V(c)+V(d))
    e=depth/2
    return shell(n,c,[(-e,ri,ri),(-e,ro,ro),(e,ro,ro),(e,ri,ri),(-e,ri,ri)],u,v,a,mat,segments,.0013,False)


def bolt(n,p,d=(0,-1,0),r=.009,mat='steel',slot=True):
    p,d=V(p),V(d).normalized()
    tube(n+' / seat',p-d*.001,p+d*.003,r*1.29,'dark',verts=16,w=.0008)
    tube(n,p+d*.002,p+d*.008,r,mat,verts=6,w=.0011)
    if slot and r>=.009:
        tube(n+' / recess',p+d*.0078,p+d*.0085,r*.32,'dark',verts=8,w=0)


def beam(n,a,b,width,depth,mat,w=.004,roll=0):
    a,b,u,v,d=frame(a,b)
    r=Matrix((u,v,d)).transposed() @ Matrix.Rotation(roll,3,'Z')
    return box(n,(a+b)*.5,(width,depth,(b-a).length),mat,w,r)


def hydraulic(n,a,b,r,paint='gun'):
    a,b=V(a),V(b)
    d=b-a
    tube(n+' / jacket',a,a+d*.58,r,paint,r*.91)
    tube(n+' / heel gland',a-d*.02,a+d*.10,r*1.13,'dark')
    tube(n+' / wiper',a+d*.5,a+d*.62,r*1.05,'steel')
    tube(n+' / chrome rod',a+d*.56,b,r*.54,'chrome')
    tube(n+' / rod end',a+d*.92,b,r*.83,'gun')


def spline(points, stages=8):
    points=[V(p) for p in points]
    path=[]
    for i in range(len(points)-1):
        p0,p1,p2,p3=(points[max(0,i-1)],points[i],points[i+1],points[min(len(points)-1,i+2)])
        for j in range(stages):
            t=j/stages
            path.append(.5*((2*p1)+(-p0+p2)*t+(2*p0-5*p1+4*p2-p3)*t*t+(-p0+3*p1-3*p2+p3)*t**3))
    return path+[points[-1]]


def hose(n,points,r,mat='rubber',corr=0, braid=False):
    path=spline(points,16 if corr else 8)
    dist=0
    vs=[]
    k=12
    dirs=[]
    for i,p in enumerate(path):
        before,after=path[max(i-1,0)],path[min(i+1,len(path)-1)]
        _,_,u,v,d=frame(before,after)
        if dirs:
            old=dirs[-1]
            u=(old-d*old.dot(d)).normalized()
            v=d.cross(u)
            dist+=(p-path[i-1]).length
        dirs.append(u)
        rr=r*(1+corr*cos(dist*2*pi/(r*.43)))
        vs+= [p+rr*(u*cos(2*pi*j/k)+v*sin(2*pi*j/k)) for j in range(k)]
    fs=[(i*k+j,i*k+(j+1)%k,(i+1)*k+(j+1)%k,(i+1)*k+j)
        for i in range(len(path)-1) for j in range(k)]
    o=mesh(n,vs,fs,mat)
    for f in o.data.polygons: f.use_smooth=True
    if braid:
        twist=[]
        dist=0
        for i,(p,u) in enumerate(zip(path,dirs)):
            if i: dist+=(p-path[i-1]).length
            d=(path[min(i+1,len(path)-1)]-path[max(i-1,0)]).normalized()
            v=d.cross(u)
            theta=dist*2*pi/(r*3.5)
            twist.append(p+(u*cos(theta)+v*sin(theta))*r*.97)
        cv=bpy.data.curves.new(n+' / trace','CURVE')
        cv.dimensions='3D';cv.bevel_depth=r*.125;cv.bevel_resolution=1
        s=cv.splines.new('POLY');s.points.add(len(twist)-1)
        for p,q in zip(s.points,twist):p.co=(*q,1)
        attach(bpy.data.objects.new(cv.name,cv),'copper')
    return o


def decal(n,center,u,v,art):
    p,u,v=map(V,(center,u,v))
    return mesh(n,[p-u/2-v/2,p+u/2-v/2,p+u/2+v/2,p-u/2+v/2],[(0,1,2,3)],
                M[art],uv=[(0,0),(1,0),(1,1),(0,1)])


def srgb(v):
    return v/12.92 if v<.04045 else ((v+.055)/1.055)**2.4


def color(h):
    h=h.strip('#')
    return tuple(srgb(int(h[i:i+2],16)/255) for i in (0,2,4))+(1,)


def material(key,n,hexcolor,dark,rough,metal,wear=0,scratch=1):
    m=bpy.data.materials.new(n);m.diffuse_color=color(hexcolor);m.use_nodes=True
    M[key]=m
    nt=m.node_tree; p=nt.nodes.get('Principled BSDF')
    p.inputs['Metallic'].default_value=metal
    p.inputs['Roughness'].default_value=rough
    p.inputs['Coat Weight'].default_value=.16 if wear else .06
    p.inputs['Coat Roughness'].default_value=.32
    def node(t,label,x,y):
        a=nt.nodes.new(t);a.label=label;a.location=(x,y);return a
    link=nt.links.new
    tex=node('ShaderNodeTexCoord','Shared asset space',-1000,380);tex.object=MAP
    co=tex.outputs['Object']
    def noise(scale,detail,x,y,socket=co):
        d=node('ShaderNodeTexNoise','',x,y);d.inputs['Scale'].default_value=scale
        d.inputs['Detail'].default_value=detail;link(socket,d.inputs['Vector']);return d.outputs['Fac']
    def ramp(sock,items,x,y,name):
        d=node('ShaderNodeValToRGB',name,x,y); a=d.color_ramp
        for j,(pos,col) in enumerate(items):
            e=a.elements[j] if j<2 else a.elements.new(pos)
            e.position=pos;e.color=col if isinstance(col,tuple) else (col,col,col,1)
        link(sock,d.inputs[0]);return d.outputs['Color']
    def op(a,b,func,x,y):
        d=node('ShaderNodeMath',func,x,y);d.operation=func
        for i,t in enumerate((a,b)):
            if isinstance(t,(int,float)):d.inputs[i].default_value=t
            else:link(t,d.inputs[i])
        return d.outputs[0]
    broad=noise(12,4,-785,520)
    flake=noise(135,2,-785,210)
    vec=node('ShaderNodeVectorMath','Directional abrasion',-790,-90);vec.operation='MULTIPLY'
    vec.inputs[1].default_value=(3,1,.32);link(co,vec.inputs[0])
    score=noise(125,2,-580,-100,vec.outputs[0])
    score=ramp(score,[(.65,0),(.76,.92)],-370,-110,'Hairline scratches')
    shade=ramp(broad,[(.22,color(dark)),(.72,color(hexcolor))],-545,530,'Paint variation / grime')
    final=shade
    fine=op(flake,.52,'MULTIPLY',-185,-190)
    fine=op(fine,score,'SUBTRACT',15,-160)
    if wear:
        flecks=ramp(flake,[(.62,0),(.76,.60*wear)],-550,205,'Chips in coating')
        edge=node('ShaderNodeBevel','Rounded wear probe',-790,-440);edge.samples=3;edge.inputs['Radius'].default_value=.016
        geom=node('ShaderNodeNewGeometry','Unperturbed surface',-790,-580)
        cmp=node('ShaderNodeVectorMath','Edge deviation',-580,-420);cmp.operation='DISTANCE'
        link(edge.outputs[0],cmp.inputs[0]);link(geom.outputs['Normal'],cmp.inputs[1])
        mask=op(cmp.outputs['Value'],broad,'MULTIPLY',-410,-405)
        mask=ramp(mask,[(.027,0),(.215,.94*wear)],-220,-403,'Polished edges')
        mask=op(mask,flecks,'MAXIMUM',0,275)
        mask=op(mask,op(score,.35*wear,'MULTIPLY',-120,24),'MAXIMUM',180,280)
        blend=node('ShaderNodeMixRGB','Exposed steel under lacquer',370,515);link(mask,blend.inputs[0]);link(shade,blend.inputs[1])
        blend.inputs[2].default_value=color('777877');final=blend.outputs[0]
        link(op(op(mask,(.83-metal),'MULTIPLY',390,170),metal,'ADD',570,170),p.inputs['Metallic'])
    rough_c=ramp(broad,[(.24,max(.05,rough-.13)),(.77,min(.96,rough+.21))],210,15,'Uneven surface sheen')
    link(rough_c,p.inputs['Roughness'])
    bump=node('ShaderNodeBump','Coating microrelief',535,-130)
    bump.inputs['Strength'].default_value=.19*scratch
    bump.inputs['Distance'].default_value=.0026
    link(fine,bump.inputs['Height']);link(bump.outputs['Normal'],p.inputs['Normal'])
    link(final,p.inputs['Base Color']);p.location=(790,480);nt.nodes.get('Material Output').location=(1090,480)
    return m


def image_shader(key,filename,base=None):
    img=bpy.data.images.load(str(ART / filename),check_existing=True)
    img.pack()
    img.filepath='//media/decals/'+filename
    m=bpy.data.materials.new('UV / '+key);m.use_nodes=True;M[key]=m
    nt=m.node_tree; bs=nt.nodes.get('Principled BSDF'); tex=nt.nodes.new('ShaderNodeTexImage')
    tex.image=img;tex.location=(-590,260)
    bs.inputs['Roughness'].default_value=.66
    if base is None:
        nt.links.new(tex.outputs['Color'],bs.inputs['Base Color'])
        nt.links.new(tex.outputs['Alpha'],bs.inputs['Alpha'])
        bs.inputs['Metallic'].default_value=.18
    else:
        mix=nt.nodes.new('ShaderNodeMixRGB');mix.inputs[1].default_value=color(base)
        nt.links.new(tex.outputs['Alpha'],mix.inputs[0]);nt.links.new(tex.outputs['Color'],mix.inputs[2])
        nt.links.new(mix.outputs[0],bs.inputs['Base Color'])
        bs.inputs['Roughness'].default_value=.89
        bs.inputs['Sheen Weight'].default_value=.30
        noise=nt.nodes.new('ShaderNodeTexNoise');noise.inputs['Scale'].default_value=350
        bu=nt.nodes.new('ShaderNodeBump');bu.inputs['Distance'].default_value=.006
        nt.links.new(noise.outputs['Fac'],bu.inputs['Height']);nt.links.new(bu.outputs[0],bs.inputs['Normal'])
    return m


def palette():
    material('red','01 | Oxide red / chipped baked enamel','a53226','451d19',.42,.32,.94)
    material('red2','02 | Vermilion / maintenance panels','bb4031','642219',.37,.29,.96)
    material('darkred','03 | Maroon / steel chassis','62291f','2a1616',.46,.42,.76)
    material('orange','04 | Safety ochre / canopy','d5993c','99531e',.38,.34,.77)
    material('ivory','05 | Warm zinc / identification','e4d6aa','8d7b58',.49,.38,.68)
    material('gun','06 | Blued / phosphate steel','4e5456','25282b',.42,.79,0)
    material('dark','07 | Carbon-black alloy','28292a','101217',.48,.62)
    material('steel','08 | Cast and brushed steel','999d9d','525354',.35,.85)
    material('chrome','09 | Hard chrome / ram shafts','c0c6c9','777f83',.21,.93,0,.45)
    material('edge','10 | Ground tool steel','bec0be','6c7276',.32,.89)
    material('rubber','11 | Oiled rubber / flexible loom','303132','14151a',.62,.10)
    material('copper','12 | Oxidized cable braid','7d674b','2c2421',.52,.76)
    material('seat','13 | Woven cockpit liner','403833','1c1818',.81,.02)
    material('glass','14 | Smoked ceramic optics','36494c','142127',.22,.52,0,.33)
    for key,h,power in [('lamp','f0bc67',2),('pilot','ad3921',1.6),('cool','84c1c5',1.4)]:
        m=bpy.data.materials.new('Signal / '+key);m.use_nodes=True;M[key]=m;m.diffuse_color=color(h)
        p=m.node_tree.nodes.get('Principled BSDF');p.inputs['Base Color'].default_value=color(h)
        p.inputs['Emission Color'].default_value=color(h);p.inputs['Emission Strength'].default_value=power
        p.inputs['Roughness'].default_value=.31
    for key in ('serial','caution','canopy','service','digits','cloth'):
        image_shader(key,key+'.png','382d28' if key=='cloth' else None)
