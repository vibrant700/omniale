from . import core as g
from .core import *


def build(s):
    cp=(s*.574,.202,.305)
    tube('Shoulder / exposed cross axle',(s*.338,.204,.284),(s*.617,.204,.307),.078,'chrome',r2=.105)
    tube('Shoulder / hydraulic articulation',(s*.437,.204,.29),(s*.511,.204,.305),.104,'gun',r2=.103)
    a,b,u,v,d=frame((s*.496,.202,.275),(s*.658,.202,.327))
    shell('Shoulder / stepped trunnion housing',a,[(0,.117,.117),(.023,.143,.143),
          (.048,.152,.152),(.142,.145,.145),(.171,.128,.128),(.195,.118,.118)],u,v,d,'gun',40,.005)
    for f,rc in [(.02,.137),(.061,.152),(.143,.146),(.173,.133)]:
        ring('Shoulder / retainer band',a+d*f,d,rc+.003,rc-.014,.013,'steel')
    for i in range(12):
        th=i*pi/6
        q=a+d*.094+.148*(u*cos(th)+v*sin(th))
        beam('Shoulder / cylindrical cast segment',q-d*.026,q+d*.026,.054,.012,'gun',.003,th)
        bolt('Shoulder / flange bolts',a+d*.033+.123*(u*cos(th)+v*sin(th)),-d,.006)

    pa=V((s*.587,.205,.331)); pb=V((s*.779,.377,.035))
    beam('Upper link / heavy alloy cradle',pa,pb,.124,.105,'gun',.012,1.57)
    for k in (-1,1):
        shift=V((0,.055*k,0))
        beam('Upper link / red fork strap',pa+shift,pb+shift,.073,.039,'red',.009,.5)
        hydraulic('Upper link / exposed ram',pa+shift+V((s*.028,-.022,-.021)),
                  pb+shift+V((s*.028,-.036,-.011)),.023,'dark')
    c=V((s*.771,.377,.035))
    tube('Elbow / axle pin',c-V((.106,0,0)),c+V((.106,0,0)),.073,'dark')
    ring('Elbow / red cast cap',c+V((s*.09,0,0)),(s,0,0),.078,.049,.041,'red2')
    tube('Elbow / recessed lug',c+V((s*.09,0,0)),c+V((s*.123,0,0)),.04,'steel')
    # Large shoulder guards lean away from the pilot toward the elbow.
    def axyz(y,z,t=0):
        return (s*(.825-.40*(z-.16)+t),y,z)
    def sidepanel(n,poly,t1,t2,mat,r=.004):
        k=len(poly)
        return mesh(n,[axyz(y,z,t) for t in (t1,t2) for y,z in poly],
                    [tuple(reversed(range(k))),tuple(range(k,2*k))]+
                    [(i,(i+1)%k,(i+1)%k+k,i+k) for i in range(k)],mat,r)
    p=[(-.035,.586),(.081,.686),(.207,.729 if s<0 else .698),(.341,.651),(.364,.47),
       (.312,.406),(.437,.275),(.426,.208),(.355,.158),(.269,.161),(.185,.257),(.153,.336),(.035,.395),(-.012,.477)]
    guard=sidepanel('Shoulder guard / thick die casting',p,-.023,.023,'red2',.010)
    # Recalculate normals for mirrored castings.
    import bmesh
    for o in [guard]:
        bm=bmesh.new();bm.from_mesh(o.data);bmesh.ops.recalc_face_normals(bm,faces=bm.faces);bm.to_mesh(o.data);bm.free()
    qi=[(.007,.57),(.1,.653),(.206,.683),(.305,.63),(.313,.476),(.273,.411),(.331,.301),
        (.296,.256),(.231,.281),(.178,.365),(.063,.415),(.025,.452)]
    inset=sidepanel('Shoulder guard / gray laminated insert',qi,.021,.046,'gun',.008)
    bm=bmesh.new();bm.from_mesh(inset.data);bmesh.ops.recalc_face_normals(bm,faces=bm.faces);bm.to_mesh(inset.data);bm.free()
    for i,q in enumerate(p[0:6]):
        j=(i+1)%len(p)
        if i not in (1,4):beam('Shoulder guard / strike trim',axyz(*q,.031),axyz(*p[j],.031),.014,.019,'steel',.003)
    for y,z in [(.048,.462),(.095,.566),(.234,.564),(.231,.377),(.293,.291),(.361,.232)]:
        bolt('Shoulder guard / flush rivet',axyz(y,z,.05),(s,0,.35),.011)
    for z in (.545,.604):
        hose('Shoulder / external bowed cross strap',[axyz(y,z+w,.075+off) for y,w,off in
             [(-.015,-.021,-.025),(.066,.015,.003),(.19,.036,.018),(.30,.019,.008),(.391,-.018,-.035)]],.015,'dark')
        beam('Shoulder / strap end cap',axyz(.045,z+.006,.09),axyz(.113,z+.025,.104),.044,.028,'red',.005)
    if s<0:
        beam('Right shoulder / diagonal wrench brace',axyz(.073,.762,.067),axyz(.30,.475,.08),.047,.027,'dark',.006)
        for y,z in [(.044,.746),(.108,.745),(.29,.49)]:
            beam('Right shoulder / projecting tab',axyz(y,z,.023),axyz(y-.03,z+.044,.077),.024,.014,'gun',.003)
    else:
        for y,z in [(.1,.604),(.18,.652),(.239,.586)]:
            tube('Left shoulder / spool bank',axyz(y,z,.036),axyz(y,z,.118),.031,'gun')
            tube('Left shoulder / plated spool cap',axyz(y,z,.106),axyz(y,z,.124),.023,'steel')
    tube('Guard toe / articulating hinge',axyz(.348,.208,.002),axyz(.348,.208,.07),.054,'dark')
    ring('Guard toe / disc face',axyz(.348,.208,.074),(s,0,.30),.046,.034,.015,'steel')
    bolt('Guard toe / circular center',axyz(.348,.208,.083),(s,0,.27),.023,'gun',False)
    tool(s,c)
    # Hoses hug the underside and arc across the back as in the orthographic views.
    hose('Main return / corrugated hydraulic trunk',[(s*.054,.61,.085),(s*.083,.698,-.002),(s*.352,.664,-.076),
          (s*.541,.674,-.165),(s*.684,.576,-.345),(s*.801,.353,-.295)],.038 if s<0 else .031,'rubber',.11)
    hose('Pressure line / wire-bound loom',[(s*.317,.63,.14),(s*.438,.697,.052),(s*.641,.566,-.072),
          (s*.780,.391,-.191),(s*.835,.188,-.175)],.015,'dark',.08,True)
    hose('Tool feed / elbow bypass',[(s*.53,.337,.235),(s*.578,.472,.115),(s*.633,.521,-.023),
          (s*.765,.434,-.115),(s*.907 if s<0 else s*.837,.226,-.142)],.010,'dark',.09,True)
    for d,r in [(V((s*.054,.611,.085)),.046),(V((s*.801,.353,-.295)),.046)]:
        ring('Hydraulics / metal ferrule',d,(0,1,0),r,r-.011,.03,'gun')


def tool(s,c):
    # Local +W advances down and forward from the elbow.
    p=V((s*.767,-.098,-.166) if s<0 else (s*.750,-.066,-.166))
    d=V((s*.159,-.936,-.311) if s<0 else (s*.198,-.875,-.443)).normalized()
    u=(V((1,0,0))-d*d.x).normalized()
    v=d.cross(u)
    r=Matrix((u,v,d)).transposed()
    def q(x,y,z):return p+x*u+y*v+z*d
    def bx(n,x,y,z,sx,sy,sz,m,w=.005):return box(n,q(x,y,z),(sx,sy,sz),m,w,r)
    if s<0:
        w=.155; front=.555; rear=-.30; casing=.443
    else:
        w=.120; front=.347; rear=-.27; casing=.374
    tube('Tool / elbow receiver',q(0,0,rear),q(0,0,rear+.22),w*.63,'red')
    hydraulic('Tool / main upper connecting link',c,q(0,0,rear+.19),w*.41,'red')
    for k in (-1,1):
        hydraulic('Tool / external chromed thrust piston',c+V((k*.053,-.006,-.102)),q(k*.072,-.045,.105),w*.28,'dark')
    bx('Tool / graphite inner frame',0,0,.02,w*1.83,w*1.67,casing,'gun',.020)
    bx('Tool / broad enamel mantle',0,.01,.063,w*1.96,w*1.83,casing-.025,'red2',.026)
    for k in (-1,1):
        bx('Tool / bolted side rail',k*w*.88,.045,.028,.044,.252,casing+.07,'red',.014)
        bx('Tool / armor seam channel',k*w*1.038,.027,.049,.010,.119,casing-.12,'darkred',.004)
        for t in (-.10,.07,.198):
            bolt('Tool / side flange bolt',q(k*w*1.06,.018,t),k*u,.010)
        for t in (-.09,.183):
            bolt('Tool / mantle cover screw',q(k*w*.67,w*.96,t),v,.009)
        hydraulic('Tool / longitudinal compression jack',q(k*w*.75,w*.77,-.195),q(k*w*.75,w*.77,.255),.025,'red')
        hose('Tool / black rail cable',[q(k*w*.99,-.017,-.145),q(k*w*1.21,.025,-.09),
             q(k*w*1.22,.03,.143),q(k*w*.98,.029,.21)],.007,'gun')
        for t in (-.04,.09):
            bx('Tool / rigid side gusset',k*w*1.041,.048,t,.023,.109,.027,'steel',.003)
    bx('Tool / top dark inset',0,w*.96,.029,w*1.03,.016,.165,'darkred',.005)
    bx('Tool / top zinc cassette',0,w*1.027,.02,w*.57,.021,.077,'steel',.005)
    decal('Tool / hydraulic warning',q(0,w*.957,.164),u*w*1.48,-d*.074,'caution')
    if s<0:
        for k in (-1,1):
            bx('Tool / folded access cover',k*w*1.027,-.045,.139,.022,.169,.156,'red2',.006)
            decal('Tool / side service ticket',q(k*w*1.111,-.048,.143),d*.110,v*.116,'service')
            beam('Tool / diagonal cover rib',q(k*w*1.11,-.105,.125),q(k*w*1.11,.012,.183),.010,.008,'steel',.002)
            hose('Tool / bent handle',[q(k*w*1.07,-.097,-.091),q(k*w*1.29,-.085,-.060),
                 q(k*w*1.29,.074,-.053),q(k*w*1.079,.106,-.081)],.009,'steel')
        for dx in (-.07,.07):
            bx('Tool / face red crest',dx,0,.278,.132,.25,.036,'red2',.009)
        ring('Tool / sealed main bearing',q(0,.011,.297),d,.123,.103,.037,'steel')
        shell('Tool / terraced face socket',q(0,.011,.29),
              [(-.024,.114,.114),(.011,.108,.108),(.025,.091,.091),(-.017,.045,.045)],
              u,v,d,'dark',40,.002,False)
        for i in range(18):
            a=i*pi/9
            q0=q(.054*cos(a),.011+.054*sin(a),.294)
            q1=q(.095*cos(a+.19),.011+.095*sin(a+.19),.304)
            beam('Tool / bell radial web',q0,q1,.008,.009,'gun',.0015)
        tube('Tool / main spindle',q(0,.011,.274),q(0,.011,.344),.055,'gun',r2=.043)
        tube('Tool / spindle cap',q(0,.011,.338),q(0,.011,.363),.039,'chrome',verts=10)
    else:
        for k in (-1,1):
            hose('Clamp / heavy side protection bail',[q(k*.102,-.086,-.096),q(k*.143,-.112,.025),
                 q(k*.155,-.112,.219),q(k*.125,-.075,.316),q(k*.106,.012,.32)],.013,'gun')
            bx('Clamp / cheek casting',k*.109,-.039,.16,.040,.133,.201,'darkred',.01)
            hydraulic('Clamp / oblique locking ram',q(k*.125,.033,-.133),q(k*.128,-.093,.237),.016,'gun')
        bx('Clamp / head cross casting',0,.006,.247,.229,.225,.121,'red2',.017)
        bx('Clamp / dark steel frontal bridge',0,.014,.30,.195,.175,.056,'gun',.012)
        for k in (-1,1):
            hydraulic('Clamp / paired jaw actuator',q(k*.063,-.032,.05),q(k*.063,-.032,.329),.026,'gun')
            bx('Clamp / exposed jaw guide',k*.066,.069,.301,.061,.097,.086,'dark',.005)
            bolt('Clamp / guide retention',q(k*.075,.125,.277),v,.010)
    old_col,old_par=g.COL,g.PAR
    for k in (-1,1):
        start=.288 if s<0 else .298
        wx=(.069 if s<0 else .059)*k
        ctrl=empty('CTRL / Jaw '+('A' if k<0 else 'B'),q(wx,0,start),.055)
        g.C['jaw'+str(s)+str(k)]=(ctrl,v.copy()*k)
        scope(old_col,ctrl)
        length=(.535 if s<0 else .391)-(0 if k<0 else .039)
        # Unequal forged fingers, swept to their sharpened industrial wear surfaces.
        if s<0:
            sections=[(0,.074,.104,.005),(.078,.062,.099,.004),(.219,.057,.073,-.002),
                      (.385,.057,.037,-.004),(length-.042,.042,.018,-.015),(length,.012,.009,-.035)]
        else:
            sections=[(0,.039,.065,.005),(.086,.036,.05,.014),(.206,.032,.038,.009),
                      (length-.039,.026,.026,.001),(length,.008,.010,-.010)]
        vv=[]
        for t,ww,hh,xsh in sections:
            xx=wx+k*xsh
            yy=(.042 if s<0 else .029)*k + t*(.044 if s<0 else -.010)
            vv.extend([q(xx-ww*.50,yy-hh*.50,start+t),q(xx+ww*.50,yy-hh*.50,start+t),
                       q(xx+ww*.54,yy+hh*.20,start+t),q(xx+ww*.31,yy+hh*.59,start+t),
                       q(xx-ww*.35,yy+hh*.56,start+t),q(xx-ww*.57,yy+hh*.14,start+t)])
        ff=[tuple(reversed(range(6))),tuple(range(len(vv)-6,len(vv)))]
        ff.extend([(i*6+j,i*6+(j+1)%6,(i+1)*6+(j+1)%6,(i+1)*6+j)
                   for i in range(len(sections)-1) for j in range(6)])
        o=mesh('Tool steel / forged '+('excavator tine' if s<0 else 'clamp finger'),vv,ff,'gun',.0024)
        o.data.materials.append(M['edge'])
        for f in o.data.polygons:
            if f.index>=2 and (f.index-2)%6 in (2,3,4):f.material_index=1
        hose('Jaw / longitudinal wear ridge',[vv[i*6+4] for i in range(len(sections))],.0032,'steel')
        if s>0:
            for i in range(6):
                t=.065+i*.045
                if t<length-.022:
                    bx('Clamp / milled grip tooth',wx-k*.018,.021*k,t+start,.014,.040,.024,'edge',.002)
        for j in range(2):
            bolt('Jaw / retaining plug',q(wx,(.104 if s<0 else .065)+.008,start+.037+j*.046),v,.008)
        scope(old_col,old_par)
    if s<0:
        beam('Tool / central separator guide',q(0,-.018,.344),q(0,-.035,.735),.022,.023,'edge',.003)
