"""Build a self-contained picture scene and editable sequencer mix from asset.blend."""
import math
import sys
from pathlib import Path

import bpy
from mathutils import Vector, Quaternion

HERE=Path(__file__).resolve().parent
ROOT=HERE.parent
sys.path.insert(0,str(HERE))
from build_asset import area, render_settings, world
from model import core as g

FPS=24
LAST=686
ASPECT=16/9
V=Vector


def stage(s):
    col=g.group('STAGE | Service bay and inspection deck',s.collection)
    g.scope(col,None)
    g.MAP=None
    g.material('floor','Deck / dark manganese aggregate','2b363b','212b30',.75,.17,0,.21)
    g.material('base','Dais / ceramic-black alloy','222c2f','161b1d',.42,.63,0,.45)
    g.material('trim','Dais / machine cut aluminum','7e8b89','3a4544',.36,.82,0,.4)
    g.material('mark','Dais / scraped amber line','b1905b','504130',.59,.35,0,.4)
    g.material('keyline','Bay / aged zinc line','6a7a78','303d40',.6,.43,0,.43)
    g.box('Bay / seamless ground',(0,0,-1.045),(200,200,.12),'floor',.003)
    g.tube('Dais / lower skirt',(0,0,-.985),(0,0,-.897),1.364,'base',r2=1.417,verts=128,w=.006)
    g.tube('Dais / inspection deck',(0,0,-.914),(0,0,-.851),1.414,'base',r2=1.389,verts=128,w=.009)
    g.ring('Dais / exposed circumference',(0,0,-.917),(0,0,1),1.415,1.402,.010,'trim',128)
    g.ring('Dais / top engraving',(0,0,-.8501),(0,0,1),1.335,1.330,.002,'keyline',128)
    g.ring('Dais / inner engraving',(0,0,-.8505),(0,0,1),1.283,1.280,.002,'keyline',128)
    for k in range(72):
        a=k*math.tau/72; u=V((math.cos(a),math.sin(a),0))
        p=V((0,0,-.848))
        g.beam('Deck / indexed tick',p+u*(1.245 if k%6==0 else 1.267),p+u*1.279,
               .003,.005 if k%6==0 else .003,'mark' if k%3==0 else 'keyline',.001)
    for k in range(8):
        a=k*math.tau/8; u=V((math.cos(a),math.sin(a),0));t=V((-u.y,u.x,0))
        p=V((0,0,-.853))
        for j in range(3):
            dx=t*(j-1)*.023
            g.beam('Dais / installation datum',p+u*1.347+dx,p+u*1.377+dx+t*.014,.006,.012,'mark',.001)
    for x in (-2.12,2.12):
        g.box('Bay / long guide channel',(x,0,-.984),(.039,10,.005),'base',.002)
        g.box('Bay / zinc line',(x+.045,0,-.983),(.008,10,.003),'keyline',.001)
    for y in (-2.04,2.04):
        for x in (-1.57,1.57):
            g.box('Bay / painted docking bracket',(x,y,-.984),(.36,.025,.003),'mark',.001)
            g.box('Bay / painted docking bracket',(x+(1 if x>0 else -1)*.167,y+(.08 if y<0 else -.08),-.984),
                  (.023,.174,.003),'mark',.001)
    # An offset pool of cool light separates the warm body from the steel bay.
    lc=g.group('LIGHT | Bay practicals and softboxes',s.collection)
    world(s,'Service bay ambient',(.105,.154,.183,1),.42)
    area(lc,'Key / 4300K overhead',(-3.2,-4.1,4.6),(0,0,0),585,3.3,(1,.865,.73),'RECTANGLE',2.55)
    area(lc,'Key / silk in front',(2.4,-3.4,2.45),(0,-.1,.1),230,2.85,(.78,.88,1),'RECTANGLE',2.35)
    rim=area(lc,'Rim / north softbox',(1.6,3.6,3.1),(0,0,.2),600,2.9,(.48,.73,.91),'RECTANGLE',1.9)
    area(lc,'Rim / raised milk strip',(-2.4,2.45,1.53),(0,0,.19),255,2.1,(1,.81,.60),'RECTANGLE',.78)
    area(lc,'Top / giant bounce',(0,.35,4.1),(0,0,0),190,2.6,(.92,.96,1))
    area(lc,'Foot / low edge',(-2.55,-1.5,.69),(0,0,-.53),70,1.9,(.74,.86,1),'RECTANGLE',.55)
    # A brief edge-light swell lands with the main audio drop.
    for f,power in [(1,600),(455,600),(466,475),(469,950),(474,820),(489,655),(505,600),(LAST,600)]:
        rim.data.energy=power;rim.data.keyframe_insert('energy',frame=f)
    return lc


def material(n, rgb, level=1):
    m=bpy.data.materials.new('Type / '+n);m.use_nodes=True
    nt=m.node_tree;nt.nodes.clear()
    out=nt.nodes.new('ShaderNodeOutputMaterial');sh=nt.nodes.new('ShaderNodeEmission')
    sh.inputs[0].default_value=(*rgb,1);sh.inputs[1].default_value=level
    nt.links.new(sh.outputs[0],out.inputs['Surface'])
    m.diffuse_color=(*rgb,1)
    return m


def graphic_rays(o):
    for k in ('visible_shadow','visible_diffuse','visible_glossy','visible_transmission',
              'visible_volume_scatter'):
        setattr(o,k,False)
    o.hide_select=False


class Graphic:
    def __init__(self,cam,col,fonts,inks):
        self.cam,self.col,self.fonts,self.inks=cam,col,fonts,inks
        self.dist=.19
        self.width=(cam.data.ortho_scale if cam.data.type=='ORTHO' else
                    self.dist*cam.data.sensor_width/cam.data.lens)
        self.height=self.width/ASPECT
        self.rig=bpy.data.objects.new('GFX / '+cam.name,None)
        col.objects.link(self.rig);self.rig.parent=cam
        self.rig.empty_display_size=.014
        # The graphic is camera-relative, with no parallax or contribution to lighting.
        self.rig.location=(0,0,-self.dist)

    def pos(self,x,y):
        return (self.width*(x-.5),self.height*(y-.5),0)

    def obj(self,name,data,mat,parent=None):
        o=bpy.data.objects.new(name,data);self.col.objects.link(o);o.parent=parent or self.rig
        if mat:data.materials.append(self.inks[mat])
        graphic_rays(o);return o

    def poly(self,n,points,ink,z=-.0004,parent=None):
        vs=[(*self.pos(x,y)[:2],z) for x,y in points]
        m=bpy.data.meshes.new(n);m.from_pydata(vs,[],[tuple(range(len(vs)))]);m.update()
        return self.obj(n,m,ink,parent)

    def rect(self,n,x,y,w,h,ink,z=-.0004,parent=None):
        return self.poly(n,[(x,y),(x+w,y),(x+w,y+h),(x,y+h)],ink,z,parent)

    def text(self,n,body,x,y,size,font='mono',ink='cream',align='LEFT',parent=None):
        data=bpy.data.curves.new(n,'FONT');data.body=body;data.font=self.fonts[font]
        data.align_x=align;data.size=self.height*size;data.space_character=1.08 if font=='mono' else 1.0
        o=self.obj(n,data,ink,parent);o.location=self.pos(x,y);return o

    def surround(self,idx,mode,close,normal):
        self.rect('Upper rule',.043,.936,.028,.0025,'amber')
        self.text('Project label','FIELD SYSTEMS   /   ASSET 07',.043,.953,.019)
        self.text('View label',mode,.957,.953,.019,'mono','quiet','RIGHT')
        self.rect('Lower rule',.043,.060,.914,.0014,'mid')
        for j in range(10):
            self.rect('Chapter tick',.043+j*.012,.037,.007,.004,'amber' if j+1==idx else 'mid')
        self.text('Footer / reading index',f'{idx:02} / 10',.173,.032,.017,'mono','quiet')
        self.text('Footer / asset class','SCV   /   MOBILE SERVICE CHASSIS',.957,.032,.018,'mono','quiet','RIGHT')
        if close:
            self.text('Technical view',normal,.956,.118,.016,'mono','quiet','RIGHT')
            self.rect('Technical-rule',.927,.105,.029,.003,'amber')

    def hero(self,sub,final=False):
        self.text('Title / eyebrow','SERVICE CHASSIS   /   FIELD SERIES',.045,.622,.02,'mono','amber')
        self.text('Title / SCV','SCV',.040,.457,.218,'bold','cream')
        self.rect('Title / divider',.048,.402,.239,.002,'mid')
        self.text('Title / chassis number','07',.046,.302,.117,'bold','amber')
        self.text('Title / chassis descriptor',sub,.132,.346,.024,'mono','quiet')
        for j in range(4):
            x=.046+j*.012
            self.poly('Title / industrial chevron',[(x,.271),(x+.006,.271),(x+.015,.29),(x+.009,.29)],'mid')

    def technical(self,index,title,descriptor):
        self.rect('Module slug',.043,.229,.031,.029,'amber')
        self.text('Module index',f'{index:02}',.047,.235,.023,'mono','black')
        self.text('Module / name',title,.042,.154,.058,'bold')
        self.text('Module / descriptor',descriptor,.044,.114,.021,'mono','quiet')

    def reticle(self,x,y,w=.039,h=.045):
        for sx in (-1,1):
            for sy in (-1,1):
                xx=x+sx*w;yy=y+sy*h
                self.rect('Reticle / horizontal',xx-(.011 if sx>0 else 0),yy,.011,.0015,'mid')
                self.rect('Reticle / vertical',xx,yy-(.017 if sy>0 else 0),.0011,.017,'mid')

    def last(self):
        self.text('End / small print','FIELD SYSTEMS     /     ASSET RECORD',.5,.622,.024,'mono','amber','CENTER')
        self.text('End / logotype','SCV–07',.5,.442,.172,'bold','cream','CENTER')
        self.rect('End / rule',.38,.390,.24,.0023,'amber')
        self.text('End / signoff','MOBILE SERVICE CHASSIS',.5,.328,.024,'mono','quiet','CENTER')
        self.text('End / footer','3D ASSET SHOWCASE     /     01',.5,.101,.018,'mono','quiet','CENTER')
        self.rect('End / plate',-.01,-.01,1.02,1.02,'black',-.0011)
        for j in range(4):
            self.rect('End / top small tick',.045+j*.013,.928,.007,.003,'mid')
            self.rect('End / bottom small tick',.91+j*.013,.067,.007,.003,'mid')


def pose(center,az,el,dist,screenx,screeny,lens,ortho=None):
    phi,theta=math.radians(az),math.radians(el)
    delta=V((math.sin(phi)*math.cos(theta),-math.cos(phi)*math.cos(theta),math.sin(theta)))*dist
    rot=(-delta).to_track_quat('-Z','Y')
    # Off-axis framing without changing the optical perspective.
    ww=ortho or (dist*36/lens)
    shift=rot@V((-(screenx-.5)*ww,-(screeny-.5)*ww/ASPECT,0))
    return V(center)+delta+shift,rot


def picture(s):
    s.name='01 | PICTURE'
    s['Notes']='Camera cuts are timeline markers. Camera graphics are individual editable text & mesh objects.'
    s.frame_start=1;s.frame_end=LAST;s.render.fps=FPS
    render_settings(s,1920,1080)
    s.cycles.samples=18;s.cycles.adaptive_threshold=.045
    s.cycles.use_light_tree=True;s.cycles.max_bounces=5;s.cycles.diffuse_bounces=2
    s.render.film_transparent=False;s.render.use_sequencer=False
    s.render.use_persistent_data=True
    s.render.filepath='//renders/picture_'
    for col in list(s.collection.children):
        if col.name.startswith(('Studio','Reference')):bpy.data.collections.remove(col,do_unlink=True)
    stage(s)
    cams=g.group('SHOT | Cameras and cuts',s.collection)
    gfx=g.group('GFX | Editable screen graphics',s.collection)
    fonts={}
    for key,n in {'mono':'DejaVuSansMono','bold':'DejaVuSans-Bold'}.items():
        f=bpy.data.fonts.load(str(ROOT/'media'/'fonts'/(n+'.ttf')));f.pack()
        f.filepath='//media/fonts/'+n+'.ttf';fonts[key]=f
    inks={n:material(n,c) for n,c in [
        ('cream',(.87,.92,.90)),('amber',(.93,.54,.19)),('quiet',(.43,.58,.58)),
        ('mid',(.132,.244,.265)),('black',(.010,.020,.023))]}
    # Frame starts follow the supplied music: 120 BPM, then 128 and 136 BPM.
    # Each pose = subject center, azimuth, elevation, distance, screen X, screen Y.
    shots=[
      (1,'Arrival','ESTABLISHING  /  BAY 07',48,
       ((0,-.075,.005),-40,13,5.46,.682,.520),((0,-.075,.005),-16,16,5.14,.682,.510),
       'hero','MOBILE SERVICE\nCHASSIS'),
      (97,'Pilot well','MODULE  /  01',61,
       ((0,-.185,.465),19,21,2.12,.625,.57),((0,-.174,.448),-4,23,1.96,.634,.57),
       'PILOT WELL','01   /   CANOPY & CONTROLS'),
      (157,'Excavation tool','MODULE  /  02',51,
       ((-.81,-.285,-.245),-58,20,2.56,.612,.55),((-.81,-.300,-.252),-78,29,2.41,.603,.56),
       'EXCAVATION TOOL','02   /   RIGHT-SIDE HYDRAULIC DRIVE'),
      (217,'Twin clamp','MODULE  /  03',53,
       ((.77,-.21,-.207),52,15,2.49,.645,.605),((.78,-.254,-.238),79,32,2.42,.632,.602),
       'TWIN CLAMP','03   /   LEFT-SIDE ARTICULATION'),
      (289,'Power pack','MODULE  /  04',57,
       ((0,.56,.265),163,10,2.81,.609,.564),((0,.605,.279),183,17,2.60,.602,.557),
       'POWER PACK','04   /   PAIRED NACELLES'),
      (334,'Load frame','MODULE  /  05',58,
       ((-.115,.19,-.59),-132,8.5,2.63,.617,.514),((-.1,.22,-.605),-115,11,2.38,.632,.54),
       'LOAD FRAME','05   /   SUSPENSION & TOE SHIELDS'),
      (379,'Top register','SURVEY  /  TOP',44,
       ((0,0,-.04),169,77,4.9,.605,.514),((0,0,-.035),187,89,4.9,.605,.514),
       'TOP REGISTER','06   /   ASYMMETRIC TOOL LAYOUT'),
      (424,'Front register','SURVEY  /  FRONT',49,
       ((0,-.055,-.04),-.2,6,5.26,.597,.51),((0,-.055,-.04),.8,5,5.12,.597,.51),
       'FRONT REGISTER','07   /   CHASSIS PROFILE'),
      (469,'Orbit','FIELD INSPECTION  /  ORBIT',50,
       ((0,.025,-.02),142,23,5.84,.502,.508),((0,-.01,-.02),53,16,5.24,.532,.519),
       'orbit',''),
      (554,'Final pose','SERVICE BAY  /  HERO',53,
       ((0,-.045,-.025),29,14,5.69,.676,.517),((0,-.045,-.025),-9,11,5.51,.675,.511),
       'hero','FIELD UNIT\nASSET RECORD'),
      (648,'End title','',50,
       ((0,0,0),5,10,7,.5,.5),((0,0,0),5,10,7,.5,.5),
       'end',''),
    ]
    for j,(start,name,mode,lens,p0,p1,kind,subtitle) in enumerate(shots):
        end=(shots[j+1][0]-1 if j<len(shots)-1 else LAST)
        ortho=4.27 if j==6 else 4.03 if j==7 else None
        n=f'{j+1:02d} / {name}'
        data=bpy.data.cameras.new(n);data.lens=lens;data.clip_start=.04;data.sensor_fit='HORIZONTAL'
        if ortho:data.type='ORTHO';data.ortho_scale=ortho
        cam=bpy.data.objects.new(n,data);cams.objects.link(cam);cam.rotation_mode='QUATERNION'
        marker=s.timeline_markers.new(n,frame=start);marker.camera=cam
        prev=None
        for k in range(5):
            t=k/4
            if j in (0,8,9): t=.5-.5*math.cos(math.pi*t)
            p=tuple((V(a).lerp(V(b),t) if isinstance(a,tuple) else a+(b-a)*t) for a,b in zip(p0,p1))
            cam.location,quat=pose(*p,lens,ortho)
            if prev and prev.dot(quat)<0:quat.negate()
            cam.rotation_quaternion=quat;prev=quat.copy()
            f=round(start+(end-start)*k/4)
            cam.keyframe_insert('location',frame=f);cam.keyframe_insert('rotation_quaternion',frame=f)
        gc=g.group(f'{j+1:02d} | {name} / type',gfx)
        overlay=Graphic(cam,gc,fonts,inks)
        if kind=='end':overlay.last()
        else:
            overlay.surround(j+1,mode,1<=j<=7,'SCV-07  :  '+f'{j:02d}')
            if kind=='hero':overlay.hero(subtitle,j==9)
            elif kind=='orbit':
                overlay.text('Orbit title','FULL CHASSIS',.043,.110,.037,'bold')
                overlay.text('Orbit subtitle','INSPECTION PASS',.043,.082,.017,'mono','amber')
            else:overlay.technical(j,kind,subtitle)
            if j in (6,7):
                overlay.reticle(.602,.518,.258,.390)
        # Non-active graphics otherwise occupy other shot frusta in world space.
        for o in gc.objects:
            if o.type=='EMPTY':continue
            for f,hidden in ((1,start!=1),(max(1,start-1),start!=1),(start,False),
                             (end,False),(min(LAST,end+1),end!=LAST)):
                o.hide_render=hidden;o.keyframe_insert('hide_render',frame=f)
                o.hide_viewport=hidden;o.keyframe_insert('hide_viewport',frame=f)
    for o in s.objects:
        key=o.get('Control ID','')
        if key.startswith('jaw1'):
            o.rotation_mode='QUATERNION'
            ax=V(o['Swing axis']).normalized()
            for f,deg in [(1,0),(217,0),(238,10),(251,11),(270,-4),(280,-4),(288,0),(LAST,0)]:
                o.rotation_quaternion=Quaternion(ax,math.radians(deg));o.keyframe_insert('rotation_quaternion',frame=f)
        if key.startswith('jaw-1'):
            o.rotation_mode='QUATERNION';ax=V(o['Swing axis']).normalized()
            for f,deg in [(1,0),(157,0),(184,7),(199,7),(214,0),(LAST,0)]:
                o.rotation_quaternion=Quaternion(ax,math.radians(deg));o.keyframe_insert('rotation_quaternion',frame=f)
        if key=='canopy':
            for f,deg in [(1,0),(100,0),(117,-3.2),(142,-3.2),(156,0),(LAST,0)]:
                o.rotation_euler.x=math.radians(deg);o.keyframe_insert('rotation_euler',frame=f)
    s.frame_set(1)
    return shots


def edit(s, shots):
    e=bpy.data.scenes.new('02 | EDIT & MIX')
    e.frame_start=1;e.frame_end=LAST;e.render.fps=FPS
    e.render.resolution_x=1920;e.render.resolution_y=1080
    e.render.resolution_percentage=100
    e.sync_mode='AUDIO_SYNC'
    ed=e.sequence_editor_create()
    vis=ed.strips.new_scene('PICTURE | Camera edit',s,1,1)
    vis.scene_input='CAMERA'
    def snd(name,filename,start,ch,gain,points=None):
        a=ed.strips.new_sound(name,str(ROOT/'media'/'audio'/filename),ch,start)
        a.sound.filepath='//media/audio/'+filename
        a.volume=gain
        if points:
            for f,coef in points:
                a.volume=gain*coef;a.keyframe_insert('volume',frame=f)
        return a
    music=snd('MUS / Industrial Pulse','industrial_pulse.wav',1,2,.69,
              [(1,.06),(12,1),(446,1),(461,.79),(476,1),(638,1),(651,.71),(667,.42),(686,0)])
    music.frame_final_end=LAST+1
    for f,ch,vol in [(82,3,.34),(201,3,.29),(318,3,.28),(363,3,.27),(538,3,.36),(631,3,.27)]:
        snd('FX / Air sweep','whoosh.wav',f,ch,vol)
    for f,ch,vol in [(97,4,.31),(157,4,.32),(268,4,.23),(289,4,.31),(424,4,.33),(469,4,.45),(648,4,.32)]:
        snd('FX / Impact','hit.wav',f,ch,vol)
    for f,ch,vol in [(1,5,.23),(451,5,.44),(633,5,.29)]:
        snd('FX / Sub drop','drop.wav',f,ch,vol)
    for row in shots:e.timeline_markers.new(row[1],frame=row[0])
    e.timeline_markers.new('MUSIC / MAIN DROP',frame=469)
    e['Notes']='Edit audio here. The base picture is the camera scene strip. source/export.py renders that scene and mixes this timeline.'
    e.frame_set(1)
    return e


def main():
    s=bpy.context.scene
    shots=picture(s)
    e=edit(s,shots)
    # Save into 3D camera view by default; the second scene is the audio timeline.
    bpy.context.window.scene=s
    for screen in bpy.data.screens:
        for ar in screen.areas:
            if ar.type=='VIEW_3D':
                sp=ar.spaces.active
                sp.region_3d.view_perspective='CAMERA';sp.region_3d.view_camera_zoom=9
                sp.overlay.show_overlays=False
                sp.shading.color_type='MATERIAL';sp.shading.show_cavity=True
    bpy.context.preferences.filepaths.save_version=0
    bpy.ops.wm.save_as_mainfile(filepath=str(ROOT/'showcase.blend'))


if __name__=='__main__':main()
