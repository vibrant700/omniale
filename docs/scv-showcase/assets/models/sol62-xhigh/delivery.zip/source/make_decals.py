"""Generate the original packed markings; requires Pillow (not needed for export)."""
from pathlib import Path
from random import Random
import math
from PIL import Image, ImageDraw, ImageFont

root = Path(__file__).resolve().parents[1]
out = root / 'media' / 'decals'
out.mkdir(parents=True, exist_ok=True)
fontroot = root / 'media' / 'fonts'
def font(name,sz): return ImageFont.truetype(str(fontroot / ('DejaVu'+name+'.ttf')),sz)

cream='#e1d6b7'
oxide='#c64932'
steel='#a3aca9'
def surface():
    im=Image.new('RGBA',(1024,1024))
    return im,ImageDraw.Draw(im)
def finish(im,name,seed=18):
    rnd=Random(seed)
    alpha=im.getchannel('A')
    d=ImageDraw.Draw(alpha)
    for _ in range(1900):
        x,y = rnd.randrange(1024),rnd.randrange(1024)
        d.ellipse((x,y,x+rnd.randrange(1,10),y+rnd.randrange(1,5)),fill=rnd.choice((0,0,16,54)))
    im.putalpha(alpha)
    im.save(out / (name+'.png'),optimize=True)

im,d=surface()
d.rectangle((78,115,940,870),outline=cream,width=16)
d.text((115,148),'SCV',font=font('Sans-Bold',245),fill=cream)
d.line((115,458,905,458),fill=cream,width=8)
d.text((115,493),'07',font=font('SansMono-Bold',242),fill=cream)
d.text((450,583),'MV / 07',font=font('SansMono',70),fill=cream)
d.text((450,676),'SERVICE',font=font('SansMono',65),fill=cream)
finish(im,'serial')

im,d=surface()
for i in range(7):
    x=67+i*139
    d.polygon([(x,202),(x+82,202),(x-2,513),(x-84,513)],fill=cream)
d.line((29,555,969,555),width=10,fill=cream)
d.text((32,612),'KEEP CLEAR',font=font('SansMono-Bold',149),fill=cream)
d.text((35,809),'HYD // 08',font=font('SansMono',93),fill=cream)
finish(im,'caution',7)

im,d=surface()
d.polygon([(512,55),(888,383),(778,383),(778,823),(657,823),(512,928),(367,823),(246,823),(246,383),(136,383)],fill=cream)
d.polygon([(512,227),(687,406),(624,406),(624,734),(512,823),(400,734),(400,406),(337,406)],fill='#d9c08d')
finish(im,'canopy',14)

im,d=surface()
d.line((64,164,960,164),fill=cream,width=21)
d.text((60,212),'LIFT POINT',font=font('SansMono-Bold',145),fill=cream)
d.text((60,420),'FIELD SYSTEMS',font=font('SansMono',108),fill=cream)
d.text((62,603),'NO STEP / 07',font=font('SansMono',95),fill=cream)
d.line((65,790,963,790),fill=cream,width=12)
for i in range(20):
    d.rectangle((71+44*i,818,83+44*i+(i%3)*6,934),fill=steel)
finish(im,'service',21)

im,d=surface()
d.text((12,125),'07',font=font('Sans-Bold',700),fill=cream)
finish(im,'digits',51)

im,d=surface()
for a,b in [(6,171),(184,350)]:
    d.arc((215,180,810,649),a,b,fill=oxide,width=23)
d.polygon([(279,400),(394,340),(501,444),(583,378),(737,322),(790,418),(567,568),(461,554)],fill=oxide)
d.line((284,420,452,544),fill='#8f2f25',width=13)
d.line((568,662,713,604),fill=oxide,width=9)
finish(im,'cloth',33)
