"""Render PICTURE, mix EDIT & MIX, and encode a browser-compatible MP4."""
import argparse
import os
from pathlib import Path
import shutil
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[1]
SCRIPT = Path(__file__).resolve()


def worker(args):
    import bpy

    e = bpy.data.scenes['02 | EDIT & MIX']
    s = bpy.data.scenes['01 | PICTURE']
    args.work.mkdir(parents=True, exist_ok=True)
    if e.render.fps != s.render.fps or e.render.fps_base != s.render.fps_base:
        raise ValueError('PICTURE and EDIT & MIX must use the same frame rate.')
    lo, hi = args.frames or (e.frame_start, e.frame_end)
    if not s.frame_start <= lo <= hi <= s.frame_end:
        raise ValueError('The requested range must be inside the PICTURE scene.')
    if args.mix:
        bpy.context.window.scene = e
        e.frame_start, e.frame_end = lo, hi
        e.frame_set(lo)
        bpy.ops.sound.mixdown(filepath=str(args.work / 'mix.wav'), check_existing=False,
                              container='WAV', codec='PCM', format='S24', mixrate=48000,
                              channels='STEREO')
    (args.work / 'render.info').write_text(f'{lo}\n{hi}\n{s.render.fps / s.render.fps_base:.10g}\n')
    if args.picture:
        bpy.context.window.scene = s
        backend = args.device or 'CPU'
        if backend != 'CPU':
            p = bpy.context.preferences.addons['cycles'].preferences
            p.compute_device_type = backend
            p.get_devices()
            enabled = []
            for d in p.devices:
                d.use = d.type == backend
                if d.use:
                    enabled.append(d.name)
            if not enabled:
                raise RuntimeError(f'No {backend} device found. Try --device CPU.')
            print(f'Cycles {backend}: {", ".join(enabled)}', flush=True)
        s.cycles.device = 'CPU' if backend == 'CPU' else 'GPU'
        if backend != 'CPU':
            s.cycles.denoising_use_gpu = True
            s.cycles.denoising_quality = 'BALANCED'
            s.cycles.denoising_prefilter = 'FAST'
        s.frame_start, s.frame_end = lo, hi
        s.frame_step = 1
        s.render.image_settings.file_format = 'PNG'
        s.render.image_settings.color_mode = 'RGB'
        s.render.image_settings.color_depth = '8'
        s.render.image_settings.compression = 12
        s.render.use_sequencer = False
        s.render.use_overwrite = not args.resume
        s.render.use_file_extension = True
        s.render.filepath = str(args.work / 'picture_####')
        if args.scale is not None:
            s.render.resolution_percentage = args.scale
        if args.samples is not None:
            s.cycles.samples = args.samples
        bpy.ops.render.render(animation=True)


def parse(argv):
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--blend', type=Path, default=ROOT / 'showcase.blend')
    ap.add_argument('--blender', default=os.environ.get('BLENDER', 'blender'))
    ap.add_argument('--ffmpeg', default=os.environ.get('FFMPEG', 'ffmpeg'))
    ap.add_argument('--work', type=Path, default=ROOT / 'renders')
    ap.add_argument('--output', type=Path, default=ROOT / 'showcase_reexport.mp4')
    ap.add_argument('--device', choices=('CPU', 'CUDA', 'OPTIX', 'HIP', 'METAL', 'ONEAPI'), default='CPU')
    ap.add_argument('--frames', nargs=2, type=int, metavar=('START', 'END'))
    ap.add_argument('--scale', type=int, choices=range(10, 101), metavar='10-100')
    ap.add_argument('--samples', type=int)
    ap.add_argument('--resume', action='store_true', help='Keep existing PNGs in this cache; only for an unchanged picture.')
    ap.add_argument('--audio-only', action='store_true', help='Re-mix sound and reuse the existing PNGs.')
    ap.add_argument('--render-only', action='store_true', help='Create PNGs and WAV, without encoding.')
    ap.add_argument('--worker', action='store_true', help=argparse.SUPPRESS)
    a = ap.parse_args(argv)
    a.blend = a.blend.resolve()
    a.work = a.work.resolve()
    a.output = a.output.resolve()
    a.picture = not a.audio_only
    a.mix = True
    return a


def main():
    if '--worker' in sys.argv:
        worker(parse(sys.argv[sys.argv.index('--') + 1:]))
        return
    a = parse(sys.argv[1:])
    if not a.blend.is_file():
        raise SystemExit(f'Blender project not found: {a.blend}')
    if not shutil.which(a.blender):
        raise SystemExit('Blender not found. Supply --blender /path/to/blender.')
    if not a.render_only and not shutil.which(a.ffmpeg):
        raise SystemExit('FFmpeg not found. Supply --ffmpeg /path/to/ffmpeg.')
    extra = []
    if a.frames:
        extra += ['--frames', *map(str, a.frames)]
    for key in ('scale', 'samples'):
        val = getattr(a, key)
        if val is not None:
            extra += ['--' + key, str(val)]
    for key in ('resume', 'audio_only'):
        if getattr(a, key):
            extra += ['--' + key.replace('_', '-')]
    subprocess.run([a.blender, '-b', str(a.blend), '--python-exit-code', '1',
                    '--python', str(SCRIPT), '--', '--worker', '--work', str(a.work),
                    '--device', a.device, *extra], check=True)
    if a.render_only:
        return
    start, end, fps = (a.work / 'render.info').read_text().splitlines()
    expected = range(int(start), int(end) + 1)
    missing = [i for i in expected if not (a.work / f'picture_{i:04d}.png').is_file()]
    if missing:
        raise SystemExit(f'Missing {len(missing)} picture frames, first missing: {missing[0]}')
    a.output.parent.mkdir(parents=True, exist_ok=True)
    subprocess.run([a.ffmpeg, '-hide_banner', '-y', '-framerate', fps, '-start_number', start,
                    '-i', str(a.work / 'picture_%04d.png'), '-i', str(a.work / 'mix.wav'),
                    '-map', '0:v:0', '-map', '1:a:0', '-t', f'{len(expected)/float(fps):.9f}',
                    '-vf', 'scale=in_range=pc:out_range=tv:out_color_matrix=bt709,format=yuv420p',
                    '-c:v', 'libx264', '-crf', '17', '-preset', 'slow', '-profile:v', 'high',
                    '-colorspace', 'bt709', '-color_primaries', 'bt709', '-color_trc', 'bt709',
                    '-color_range', 'tv', '-c:a', 'aac', '-b:a', '256k', '-ar', '48000',
                    '-movflags', '+faststart', '-metadata', 'title=SCV-07 | Mobile Service Chassis',
                    str(a.output)], check=True)


if __name__ == '__main__':
    main()
