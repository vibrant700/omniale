"""Embed a custom thumbnail for the SCV collection in an existing asset.blend."""
from pathlib import Path
import sys

import bpy

args = sys.argv[sys.argv.index('--') + 1:] if '--' in sys.argv else []
if len(args) != 1 or not Path(args[0]).is_file():
    raise SystemExit('Usage: blender -b asset.blend --python source/set_asset_preview.py -- preview.png')

collection = bpy.data.collections['SCV-07 | Mobile Service Chassis']
with bpy.context.temp_override(id=collection):
    bpy.ops.ed.lib_id_load_custom_preview(filepath=str(Path(args[0]).resolve()))

bpy.context.preferences.filepaths.save_version = 0
bpy.ops.wm.save_as_mainfile(filepath=bpy.data.filepath)
