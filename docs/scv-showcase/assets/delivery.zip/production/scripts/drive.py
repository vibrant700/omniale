reset()
for side,leg in [(-1,'R'),(1,'L')]:
    group('06'+leg+' /  WALKING GEAR     •     '+leg)
    X=411+side*110
    local((X,0,0))
    joint('Pelvis bearing',(-side*62,432,428),(side*26,432,428),32)
    yz('Femur / bifurcated web',-28,28,[(403,408),(452,405),(595,493),(605,540),(574,555),(534,529),(478,478),(424,473),(397,448)],'ox',3)
    for t in [-1,1]:
        yz('Femur cheek forging',t*26,t*34,[(424,418),(454,422),(580,500),(592,527),(573,543),(551,528),(534,505),(452,454),(425,455)],'red',2.6)
        piston('Leg extension ram',(t*37,448,438),(t*37,571,521),8.5)
        cyl('Pivot / femur',(t*32,441,435),(t*39,441,435),10,'steel')
        cable('Articulated oil line',[(t*34,439,424),(t*48,454,436),(t*48,531,472),(t*42,594,501),(t*33,599,521)],3.2)
    # Curved knee-shield over the forward-facing hip carrier.
    def fender(name,stations,m):
        v=[]; f=[];na=16
        for y,z,w,amp in stations:
            for i in range(na+1):
                a=pi*(i/na-.5)
                v.append((w*sin(a),y,z-amp*cos(a)))
        for j in range(len(stations)-1):
            for i in range(na):f.append((j*(na+1)+i,j*(na+1)+i+1,(j+1)*(na+1)+i+1,(j+1)*(na+1)+i))
        o=mesh(name,v,f,m,0,True)
        md=o.modifiers.new('Plate gauge','SOLIDIFY');md.thickness=2*S
        md=o.modifiers.new('Deburred edges','BEVEL');md.width=.75*S;md.segments=2
    fender('Coxal shield',[(339,483,33,9),(345,449,33,32),(366,422,34,31),(390,422,34,35),(454,436,32,35),(472,444,30,23)],'red')
    # Layered spring cradle beneath the forward knee cover.
    shaped('Hip forward carrier',[(349,0,466,56,40,9),(374,0,461,65,72,10),(420,0,447,58,78,10)],'blued',2.3)
    for q in [-1,1]:
        a=(q*21,359,478);b=(q*21,499,542)
        turned('Load spring / transverse damper',a,b,[(0,8),(.09,9),(.14,7),(.8,7),(.84,9),(.96,9),(1,7)],'steel')
        for tt in [.24,.34,.44,.54,.64,.74]:band('Damper boot',a,b,tt,tt+.054,9,'rubber')
        for yy,zz in [(350,456),(356,436)]:bolt((q*20,yy,zz),r=2.2)
    mark('Hip / station','07',(0,347,465),(1,0,0),(0,0,-1),9)
    fender('Retaining arch',[(393,421,35,35),(399,421,35,35)],'steel')
    for t in [-1,1]:
        cyl('Shield rivet',(t*21,362,398),(t*21,359,395),3,'silver',12)
        yz('Floating link',t*33,t*39,[(384,401),(408,401),(453,428),(446,453),(421,463),(383,443)],'ox',2)
        bolt((t*39,405,424),(t,0,0),4)
    joint('Hock transverse axle',(-48,578,530),(48,578,530),34)
    for t in [-1,1]:
        cyl('Hock flange',(t*45,578,530),(t*50,578,530),22,'ox')
        bolt((t*50,578,530),(t,0,0),7)
    yz('Splayed lower yoke',-29,29,[(593,537),(601,566),(572,598),(450,646),(403,643),(390,623),(405,602),(533,556),(557,533)],'red',3.5)
    for t in [-1,1]:
        # Overrun dampers extend well behind the foot in profile.
        a=(t*41,430,631);b=(t*45,710,529)
        turned('Recoil cylinder',a,b,[(0,12),(.035,16),(.12,16),(.15,20),(.46,20),(.49,18),(.51,17),(.55,17),(.57,14),(.61,14)],'red')
        band('Sliding barrel',a,b,.58,.98,12,'silver')
        for q in [.20,.31,.45]:band('Barrel wrap',a,b,q,q+.038,20.6,'blued')
        band('Rear ferrule',a,b,.937,.966,15,'red')
        band('Piston eye',a,b,.97,1,14,'steel')
        cable('Damper return loop',[(t*41,547,597),(t*52,577,605),(t*53,630,574),(t*47,674,555)],2.4,'blued')
        for y,z in [(547,629),(605,608)]:
            cyl('Grease cup',(t*16,y-4,z-9),(t*16,y+3,z+9),11,'blued')
    joint('Ankle / forward trunnion',(-45,420,631),(45,420,631),26)
    # Separate ground pads with raised arches and segmented traction blocks.
    for t in [-1,1]:
        yz('Toe rocker',t*5,t*42,[(345,675),(376,652),(397,650),(410,640),(438,641),(457,660),(453,676),(419,682),(356,682)],'steel',2)
        yz('Heel rocker',t*7,t*41,[(446,671),(469,649),(483,639),(505,644),(536,679),(531,683),(465,683)],'blued',2)
        for yy in [357,380,407,431,468,491,514]:
            box('Replaceable tread',(t*24,yy,682),(36,18,6),'rubber',1.3)
        for y,z,r in [(405,664,13),(482,653,18),(506,674,9)]:
            cyl('Rocker journal',(t*38,y,z),(t*44,y,z),r,'silver')
            cyl('Journal plug',(t*44,y,z),(t*45,y,z),r*.68,'dark')
    fender('Armoured metatarsal',[(355,652,50,15),(372,638,46,37),(410,622,45,53),(431,616,43,48),(463,607,38,31)],'red')
    fender('Toe shield / stainless lip',[(352,653,51,16),(358,651,50,18)],'silver')
    shaped('Toe diaphragm',[(358,0,651,87,13,5),(367,0,643,85,24,6),(408,0,633,72,53,9)],'blued',1.5)
    shaped('Toe bearing crossbar',[(355,0,650,57,9,3),(363,0,650,62,12,3)],'red')
    for xx in [-25,-10,10,25]:
        box('Grip insert',(xx,363,674),(8,13,9),'rubber',1.4)
    for q in [-1,1]:
        cyl('Toe post',(q*36,365,657),(q*36,365,668),4,'silver')
    for t in [-1,1]:
        cyl('Shield keeper',(t*18,373,606),(t*18,371,603),3.7,'silver',12)
        cable('Ankle hose',[(t*36,494,588),(t*60,471,578),(t*61,445,594),(t*49,411,617)],3.9)
    reset()
