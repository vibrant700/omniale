reset()
group('01  /  TORSO     •     cast frame')
cx=411
shaped('Main transverse casting',[(388,cx,403,178,65,13),(424,cx,390,209,105,16),(538,cx,370,202,102,15),(565,cx,360,185,70,15)],'ox',3)
shaped('Reactor backplane',[(447,cx,303,178,184,14),(526,cx,301,179,182,14),(579,cx,295,163,126,18)],'red',3)
for s in [-1,1]:
    x=cx+s*85
    shaped('Chassis lower bearer',[(380,x,376,62,22,5),(402,x,376,68,24,5),(550,x,367,61,22,5)],'blued')
    for z in [316,331,346]:
        box('Cast lateral rib',(cx+s*101,488,z),(9,106,5),'ox')
    cable('Outboard guard',[(cx+s*107,398,371),(cx+s*119,401,352),(cx+s*117,540,332),(cx+s*104,560,337)],2.6,'steel')

group('02  /  COOLING     •     paired louvre stacks')
for s in [-1,1]:
    # Build each radiator around an inclined, tapered manifold.
    x=cx+s*79
    def tower(z,w,d,fy,off=0):
        c=4.0;a=w/2; x0=x+off*s
        return [(x0+i,fy+j,z) for i,j in [(-a+c,0),(a-c,0),(a,c),(a,d-c),(a-c,d),(-a+c,d),(-a,d-c),(-a,c)]]
    loft('Radiator tower / cast jacket',[tower(380,76,135,388,8),tower(247,69,140,384,5),tower(132,47,98,417,-5)],'red',2.5)
    def fplane(z):return 384+(247-z)*33/115
    def xc(z):return x+(5-(247-z)*10/115)*s
    vs=[]
    for z,w in [(136,40),(242,53)]:
        for shift in [0,2]:
            for sign in [-1,1]:vs.append((xc(z)+sign*w/2,fplane(z)-1.2+shift,z))
    mesh('Louvre recess',vs,[(0,1,5,4),(2,3,7,6),(0,2,3,1),(4,6,7,5),(0,4,6,2),(1,3,7,5)],'dark',.5)
    for k in range(15):
        z=141+k*6.68; w=33+(z-136)*.117
        y=fplane(z)-1.7
        yz('Inclined cooling blade',xc(z)-w/2,xc(z)+w/2,[(y,z),(y-4,z+2.8),(y-3.8,z+4),(y+.5,z+1.7)],'steel',.35)
    for t in [-1,1]:
        pts=[(xc(z)+t*w/2,fplane(z)-2,z) for z,w in [(134,46),(188,52),(244,59)]]
        cable('Radiator lip',pts,2.1,'red')
    for yy in [430,483]:
        box('Header ear',(x-s*5,yy,129),(35,8,10),'steel',1.7)
        for dx in [-13,13]:box('Hoist lug',(x-s*5+dx,yy,125),(6,11,14),'steel',2)
    # Removable front access doors, bars, latches and lamp guards
    shaped('Heat exchanger pedestal',[(380,x+s*6,314,65,139,5),(400,x+s*6,314,69,145,7),(524,x+s*6,318,63,125,7)],'red',2)
    box('Inset door gasket',(x+s*6,378.6,281),(47,3,64),'dark',2.2)
    box('Inspection door',(x+s*6,375.4,279),(41,5,54),'lightred',2.4)
    box('Door handle',(x+s*6,370.5,302),(27,5,4),'steel',.9)
    mark('Stencil / cooling column','HX  /  '+('L' if s>0 else 'R'),(x+s*6,372.6,280),(1,0,0),(0,0,-1),7)
    for dx in [-15,15]:
        for z in [257,298]:bolt((x+s*6+dx,372.6,z),r=1.6)
    for z in [326,348]:
        box('Press formed cross rib',(x+s*6,374,z),(54,13,13),'red',1.8)
    box('Running lamp socket',(x+s*6,381,369),(45,9,23),'blued',3)
    box('Opal service lamp',(x+s*6,375,369),(32,4,16),'ivory',2)
    for dx in [-11,11]:box('Lamp cage',(x+s*6+dx,372.2,369),(2.4,3.8,21),'steel',.7)
    for yy in [419,503]:
        bx=x+s*36
        yz('Lift point strap',bx,bx+s*5,[(yy-9,174),(yy-6,164),(yy+7,162),(yy+10,197),(yy+4,201),(yy-4,188)],'steel')
        bolt((bx+s*4,yy,174),(s,0,0))
    for yy in [414,451,491]:
        box('Side service panel',(x+s*39,yy,295),(6,30,68),'ox')
        for j in range(4):box('Stamped gill',(x+s*43,yy,275+j*8),(3,23,3),'steel',.65)

group('03  /  OPERATOR     •     open station')
# Tub floor drops under the pilot and rises at the front.
shaped('Pilot tub / keel',[(269,cx,425,64,19,6),(292,cx,422,84,35,9),(341,cx,422,96,51,10),(414,cx,391,92,81,12),(449,cx,377,76,84,9)],'red',2)
shaped('Cockpit sill, ochre',[(269,cx,419,64,8,3),(282,cx,422,76,7,3),(309,cx,431,85,9,3)],'orange',1.1)
for s in [-1,1]:
    xx=cx+s*40
    yz('Tub coaming',xx,xx+s*5,[(273,413),(342,375),(384,354),(424,353),(418,369),(310,425),(278,430)],'red',1.5)
    cable('Polished sill trim',[(xx,273,412),(xx,335,383),(xx,384,356),(xx,413,351)],1.7,'silver')
    piston('Canopy lifter',(xx+s*2,369,368),(xx+s*2,330,280),3.6)
    cyl('Canopy stay',(xx,331,281),(xx,378,244),2.0,'silver')
    joint('Hood pivot',(xx-s*4,375,239),(xx+s*6,375,239),8)
    cable('Cockpit rear cage',[(xx,392,348),(xx,399,260),(xx,392,225),(xx-s*10,382,215)],3.6,'blued')
shaped('Seat pedestal',[(344,cx,351,53,21,3),(390,cx,344,55,25,5)],'blued')
shaped('Operator seat pan',[(340,cx,332,52,9,3),(358,cx,338,56,13,5),(387,cx,331,52,17,5)],'seat',2)
shaped('Suspended seat back',[(377,cx,290,47,70,9),(388,cx,286,54,80,11),(397,cx,286,48,74,9)],'seat',3)
box('Head restraint',(cx,390,244),(32,14,19),'seat',5)
for s in [-1,1]:
    cable('Bolster piping',[(cx+s*22,376,319),(cx+s*22,377,293),(cx+s*19,383,263)],2,'ox')
    cable('Control stalk',[(cx+s*27,357,352),(cx+s*28,345,339),(cx+s*24,340,323)],2.5,'steel')
    cyl('Grip',(cx+s*24,340,325),(cx+s*24,339,316),3.7,'rubber')
    powered='cyan' if s>0 else 'amber'
    box('Side console',(cx+s*30,358,345),(14,33,12),'blued',2.2)
    for j in range(3):box('Status key',(cx+s*30,347+5*j,338.5),(6,2.6,1.3),powered,.25)
    yz('Foot pedal',cx+s*15-6,cx+s*15+6,[(300,401),(312,383),(315,386),(305,406)],'steel')
    # Stitched two-point restraints and cast buckle, following the seat.
    cable('Shoulder restraint',[(cx+s*15,382,258),(cx+s*13,375,271),(cx+s*10,374,299),(cx+s*5,368,323)],3.1,'rubber')
    box('Harness adjuster',(cx+s*13,372.5,278),(8,3,6),'brass',.7)
    for z in [277,288,299,310]:
        box('Seat rib',(cx,376.0,z),(16,2.4,3.3),'seat',1.1)
    yz('Suspension scissors',cx+s*18-2,cx+s*18+2,[(342,348),(351,346),(382,380),(376,383)],'steel')
    yz('Suspension scissors',cx+s*18-2,cx+s*18+2,[(376,346),(382,348),(351,381),(344,380)],'blued')
    piston('Pedal servo',(cx+s*15,331,397),(cx+s*15,314,382),3.1)
box('Instrument binnacle',(cx,335,360),(41,14,17),'blued',2.2)
box('Dashboard / MFD bezel',(cx-5,327.7,358),(22,2.5,10),'dark',1.1)
for j in range(3):
    box('Phosphor trace',(cx-10+j,326.25,355+j*2.4),(10+j*1.8,.65,.8),'cyan',.2)
for dx in [10,15]:cyl('Panel telltale',(cx+dx,327.7,357),(cx+dx,326.4,357),1.6,'amber',16,.2)
cyl('Instrument support',(cx,340,386),(cx,338,363),6,'steel')
for y,z in [(314,406),(323,404),(332,402),(341,399)]:
    box('Footwell nonslip slat',(cx,y,z),(46,3,2.5),'blued',.4)
# Compound-curved canopy shell, hollow underneath. The star is draped on the actual crown.
def hood(t,a,offset=0):
    # t along the roof; a from port to starboard in radians
    ar=abs(sin(a)); widening=1+.045*sin(t*pi)
    return (cx+(41+offset)*sin(a)*widening,264+119*t+46*ar**2*(1-t)-7*ar*t,
            195-32*sin(pi*t*.85)+58*ar**2+15*ar**4-offset*cos(a))
def roofpatch(name,t0,t1,a0,a1,m,oset=.0,nt=11,na=16,solid=0):
    vs=[hood(t0+(t1-t0)*j/nt,a0+(a1-a0)*i/na,oset) for j in range(nt+1) for i in range(na+1)]
    fs=[(j*(na+1)+i,j*(na+1)+i+1,(j+1)*(na+1)+i+1,(j+1)*(na+1)+i) for j in range(nt) for i in range(na)]
    o=mesh(name,vs,fs,m,0,True)
    if solid:
        md=o.modifiers.new('Rolled thickness','SOLIDIFY');md.thickness=solid*S
    return o
roofpatch('Canopy / pressed amber alloy',0,1,-1.53,1.53,'orange',solid=2)
for s in [-1,1]:
    roofpatch('Canopy side wrap',0,1,s*1.07,s*1.54,'red',.8)
    roofpatch('Flank pinstripe',0,1,s*.99,s*1.025,'ivory',1)
    cable('Rolled hem',[hood(t,s*1.51,1.1) for t in [0,.2,.5,.8,1]],1.8,'steel')
    for t in [.06,.36,.65,.92]:bolt(hood(t,s*1.2,1.5),(s,0,0),1.6)
for t in [.025,.59,.95]:
    cable('Roof hoop',[hood(t,-1.51+i*3.02/12,1.4) for i in range(13)],1.8,'silver' if t<.03 else 'red')
star=[]
for i in range(10):
    ang=i*pi/5-pi/2;r=1 if i%2==0 else .44
    star.append((.32+.215*r*sin(ang),r*.62*cos(ang)))
for i in range(10):
    t1,a1=star[i];t2,a2=star[(i+1)%10]
    # Tessellate the emblem so it follows the compound curvature.
    N=6;vs=[];fs=[]
    for j in range(N+1):
        for k in range(N+1-j):
            t=.32+(t1-.32)*j/N+(t2-.32)*k/N
            a=a1*j/N+a2*k/N
            vs.append(hood(t,a,1.25))
    ids=lambda j,k:j*(N+1)-j*(j-1)//2+k
    for j in range(N):
        for k in range(N-j):
            fs.append((ids(j,k),ids(j+1,k),ids(j,k+1)))
            if j+k<N-1:fs.append((ids(j+1,k),ids(j+1,k+1),ids(j,k+1)))
    mesh('Canopy / service star',vs,fs,'ivory')

group('04  /  APRON     •     recovery pennant')
# Sculpted folds in the triangular hanging splash guard.
vs=[];faces=[]
for j in range(17):
    v=j/16
    for i in range(13):
        u=i/6-1
        vs.append((cx+u*(47*(1-v)**.76+1),298+33*v+7*abs(u)**2-3.5*cos(8*u+3*v)*(1-v),437+162*v+10*(1-u*u)*(1-v)))
for j in range(16):
    for i in range(12):faces.append((13*j+i,13*j+i+1,13*j+i+14,13*j+i+13))
ap=mesh('Woven splash apron',vs,faces,'cloth',0,True)
md=ap.modifiers.new('Double faced textile','SOLIDIFY');md.thickness=.003
def flagpos(dx,z):
    v=(z-446)/156;u=dx/(47*(1-v)**.76+1)
    return (cx+dx,296+33*v+7*abs(u)**2-3.5*cos(8*u+3*v)*(1-v),z)
ring=[flagpos(23*cos(a*2*pi/48),498+23*sin(a*2*pi/48)) for a in range(48)]
cable('Screenprint / roundel',ring,1.55,'lightred',True)
for k in [-1,1]:
    mesh('Fleet chevron',[flagpos(k*x,z) for x,z in [(0,502),(22,485),(21,499),(0,515)]],[(0,1,2,3)],'lightred')
for s in [-1,1]:bolt((cx+s*39,301,440),r=3)

group('05  /  POWERPACK     •     twin impellers')
shaped('Rear yoke',[(538,cx,312,188,92,14),(574,cx,307,202,96,12),(598,cx,310,174,94,16)],'red',3)
for s in [-1,1]:
    x=cx+s*73;a=(x,553,300);b=(x,670,300)
    turned('Turbocompressor / cast bell',a,b,[(0,41),(.07,48),(.21,48),(.24,43),(.35,43),(.38,46),(.78,47),(.88,45),(.95,41),(1,40),(1,33),(.79,31)],'red',48,1)
    turned('Outlet / bright rim',a,b,[(.933,41),(.95,42),(.99,42),(1.01,40),(1.01,34),(.96,33)],'silver',48,.45)
    band('Sealing band',a,b,.276,.31,44,'steel')
    # Fan scroll sunk behind the outlet ring.
    cyl('Exhaust throat',(x,636,300),(x,641,300),33,'dark')
    basecol=col
    col=bpy.data.collections.new('MOTION • Rotor '+('L' if s>0 else 'R'));basecol.children.link(col)
    col['pivot']=list(wp((x,646,300)))
    for j in range(15):
        theta=j*2*pi/15
        def rot(rad,angle,yy):
            return (x+rad*cos(theta+angle),yy,300+rad*sin(theta+angle))
        mesh('Swept compressor vane',[rot(10,0,653),rot(31,.03,646),rot(32,.27,648),rot(13,.38,655)],[(0,1,2,3)],'steel')
    turned('Compressor hub',(x,640,300),(x,658,300),[(0,13),(.68,14),(1,10)],'silver')
    col=basecol
    for j in range(12):
        a0=j*2*pi/12;bolt((x+37*cos(a0),669,300+37*sin(a0)),(0,1,0),1.4)
    for j in range(6):
        a0=j*2*pi/6
        def outer(y,r,da):return (x+r*cos(a0+da),y,300+r*sin(a0+da))
        vs=[outer(y,r,da) for y,r in [(602,46),(617,49),(649,49),(657,44)] for da in [-.33,.33]]
        mesh('Heat shield segment',vs,[(0,1,3,2),(2,3,5,4),(4,5,7,6)],'steel',0,True)
    turned('Angled breather',(cx+s*42,524,228),(cx+s*62,561,170),[(0,11),(.10,13),(.18,11),(.73,11),(.76,12),(.98,12),(1,10),(1,7),(.80,7)],'steel')
    cable('Bleed line',[(x+s*32,566,320),(x+s*41,561,342),(x+s*47,511,367)],3,'blued')
shaped('Spine cowl',[(548,cx,225,47,49,7),(599,cx,209,74,71,14),(639,cx,201,68,58,16),(650,cx,198,44,36,10)],'red',2.2)
shaped('Spine endcap',[(638,cx,202,57,47,12),(652,cx,201,41,34,9)],'blued')
box('Rear oil cooler',(cx,601,311),(48,9,58),'dark',7)
for z in range(290,334,4):box('Oil cooler fin',(cx,606,z),(37-abs(z-312)*.27,6,2),'silver',.65)
mark('Service stencil','FILL    07',(cx,583,251),(1,0,0),(0,1,0),6)
