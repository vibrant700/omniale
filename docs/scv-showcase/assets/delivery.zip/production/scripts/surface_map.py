"""Author a periodic workshop wear mask; white = exposed primer / metal."""
from pathlib import Path
import random, math
import numpy as np
from PIL import Image, ImageDraw

def generate(path):
    n=1024
    rng=random.Random(7027)
    arr=np.zeros((n,n),np.float32)
    for j,amp in [(8,.36),(32,.28),(128,.18),(256,.10),(1024,.08)]:
        a=np.random.default_rng(j+19).uniform(0,255,(j,j)).astype('uint8')
        a=np.pad(a,((1,1),(1,1)),mode='wrap')
        w=n//j
        layer=Image.fromarray(a).resize(((j+2)*w,(j+2)*w),Image.Resampling.BICUBIC)
        arr+=amp*np.asarray(layer)[w:w+n,w:w+n]
    im=Image.fromarray(np.clip((arr-165)*9,0,255).astype('uint8'))
    dr=ImageDraw.Draw(im)
    for i in range(130):
        x,y=rng.randrange(n),rng.randrange(n)
        l=rng.uniform(5,70); theta=rng.uniform(-.45,.45)+(0 if i%3 else 1.7)
        for k in range(rng.randrange(1,5)):
            x+=rng.uniform(-4,4); y+=rng.uniform(1,5)
            t=l*rng.uniform(.35,1)
            for dx in [-n,0,n]:
                for dy in [-n,0,n]:
                    dr.line((x+dx,y+dy,x+dx+t*math.cos(theta),y+dy+t*math.sin(theta)),fill=rng.randrange(65,230),width=rng.choice([1,1,2]))
    im.save(path)

if __name__=='__main__':
    generate(Path(__file__).resolve().parents[1]/'media'/'wear_field.png')
