"""Run inside Blender after opening photography.blend. GPU auto selection."""
import os,bpy
from pathlib import Path
s=bpy.context.scene
p=bpy.context.preferences.addons['cycles'].preferences
try:
    p.compute_device_type='CUDA';p.refresh_devices()
    for dev in p.devices:dev.use=dev.type=='CUDA'
    s.cycles.device='GPU' if any(d.use for d in p.devices) else 'CPU'
except (TypeError,RuntimeError):s.cycles.device='CPU'
out=Path(os.environ.get('SCV_FRAMES',bpy.path.abspath('//renders')));out.mkdir(parents=True,exist_ok=True)
s.render.resolution_percentage=int(os.environ.get('SCV_SCALE',s.render.resolution_percentage))
s.cycles.samples=int(os.environ.get('SCV_SAMPLES',s.cycles.samples))
frames=os.environ.get('SCV_STILLS','')
if frames:
    indices=map(int,frames.split(','))
else:
    s.frame_start=int(os.environ.get('SCV_FIRST',s.frame_start));s.frame_end=int(os.environ.get('SCV_LAST',s.frame_end))
    s.render.filepath=str(out/'SCV_');s.render.use_overwrite=os.environ.get('SCV_RESUME','0')!='1'
    bpy.ops.render.render(animation=True)
    indices=[]
for i in indices:
    path=out/f'SCV_{i:04}.png'
    if not frames and path.exists() and os.environ.get('SCV_RESUME','0')=='1':continue
    s.frame_set(i);s.render.filepath=str(path)
    bpy.ops.render.render(write_still=True)
