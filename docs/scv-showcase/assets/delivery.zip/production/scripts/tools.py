for s,arm in [(-1,'R'),(1,'L')]:
    reset()
    group('07'+arm+' /  SHOULDER     •     '+arm)
    x=lambda o:411+s*o
    a=(x(116),463,314);b=(x(227),468,270)
    turned('Shoulder • bell axle',a,b,[(0,35),(.13,33),(.21,25),(.32,22),(.46,22),(.56,30),(.63,42),(.90,42),(.94,33),(1,32)],'steel',48)
    for t,r in [(.13,32),(.52,31),(.65,43),(.81,43),(.89,42)]:
        band('Bearing ring',a,b,t,t+.032,r,'silver' if t!=.81 else 'blued')
    # Independent armour leaf over the shoulder; its outer face is not vertical.
    ex=Vector((s*.947,0,-.32));ey=Vector((0,1,0));ez=Vector((s*.32,0,.947))
    local((x(209),472,153),ex,ey,ez)
    profile=[(-54,4),(-30,-1),(27,9),(47,27),(63,72),(46,99),(29,125),(40,180),(15,225),(-7,213),(-21,147),(-64,126),(-72,71)]
    yz('Pauldron / main plate',-6,8,profile,'red',3.4)
    yz('Pauldron / reinforced face',8,11,[(-47,12),(-29,7),(23,17),(42,34),(54,70),(35,99),(17,125),(28,175),(14,203),(1,192),(-10,140),(-53,117),(-60,69)],'steel',2)
    yz('Raised shoulder cap',11,15,[(-44,18),(-28,13),(20,23),(37,36),(43,57),(-49,53)],'red',1.8)
    yz('Forked bearing lug',11,23,[(-49,73),(-36,71),(3,109),(33,73),(42,79),(19,126),(24,172),(13,191),(-2,175),(-8,127)],'blued',2)
    for y,z,r in [(-39,30,3),(26,36,3),(-46,102,3),(7,128,8),(15,174,10)]:
        cyl('Shoulder face / boss',(16,y,z),(26,y,z),r*1.45,'steel')
        bolt((26,y,z),(1,0,0),r*.65)
    for k in range(2 if s>0 else 3):
        yy=-30+23*k
        a=(24,yy,90);b=(30,yy+45,-19 if k==0 else -7)
        turned('Rack / stowed service bar',a,b,[(0,3),(.62,3),(.64,5),(.92,5),(1,3.5)],'silver' if k==1 else 'blued',12)
    for h in [49,72]:
        cable('Tool rack / tension band',[(12,-61,h+9),(27,-43,h),(32,0,h-3),(27,40,h+3),(11,53,h+14)],3.5,'rubber')
    reset()
    a=(x(202),462,291);b=(x(216),530,392)
    joint('Upper arm shoulder eye',(x(172),462,291),(x(223),462,291),27)
    for dx in [-17,17]:
        piston('Lift cylinder',(x(202)+dx,453,302),(x(216)+dx,508,402),10)
    turned('Brachial link',a,b,[(0,19),(.16,19),(.25,14),(.70,14),(.84,21),(1,21)],'blued')
    joint('Elbow', (x(188),529,390),(x(242),529,390),28)
    cyl('Elbow lock',(x(234),529,390),(x(249),529,390),24,'red')
    bolt((x(249),529,390),(s,0,0),9)
    cable('Cable • shoulder motor',[(x(228),459,310),(x(250),468,344),(x(253),485,376),(x(237),514,402)],4.2)
    group('08'+arm+' /  END EFFECTOR     •     '+('wide grapple' if s<0 else 'rail fork'))
    broad=s<0
    front=Vector((139,266,503) if broad else (669,330,499))
    rear=Vector((191,458,432) if broad else (635,455,445))
    ey=(rear-front).normalized()
    ex=ey.cross(Vector((0,0,1))).normalized()
    ez=ex.cross(ey).normalized()
    local(front,ex,ey,ez)
    W=102 if broad else 74;L=(rear-front).length
    # Tool cassette gussets, separated cover leaves and plated working flange.
    shaped('Actuator cassette',[(0,0,0,W-8,124 if broad else 108,15),(13,0,0,W,130 if broad else 112,15),(.72*L,0,0,W-4,118 if broad else 112,13),(L,0,0,W-16,83,15)],'red',2.7)
    shaped('Front working flange',[(-6,0,0,W-6,122 if broad else 108,15),(1,0,0,W+2,126 if broad else 113,16),(8,0,0,W,125 if broad else 112,16)],'steel',1.5)
    if broad:
        turned('Tool throat', (0,-1,3),(0,-12,3),[(0,43),(.32,43),(.42,41),(1,41),(1,34),(.60,34)],'silver',40)
        cyl('Socket / dark recess',(0,-8,3),(0,-9,3),34,'dark')
        for j in range(14):
            a=j*2*pi/14
            cyl('Socket rib',(14*cos(a),-13,3+14*sin(a)),(33*cos(a+.14),-12,3+33*sin(a+.14)),1.4,'steel',8,.1)
        turned('Central tool quill',(0,-9,3),(0,-76,3),[(0,15),(.2,15),(.23,12),(.49,12),(.51,14),(.66,14),(.76,8),(1,6)],'silver')
        for t in [-1,1]:
            cyl('Top roller rail',(t*42,-4,-53),(t*42,L*.9,-49),10,'red')
            cyl('Rail cap',(t*42,-7,-53),(t*42,-4,-53),9.6,'silver')
        # Side plates on the actuator leave narrow dark joints between red panels.
        for t in [-1,1]:
            yz('Service door / gasket',t*(W/2-1),t*(W/2+1.5),[(30,-40),(146,-40),(161,-22),(154,30),(31,30)],'dark')
            yz('Service door / panel',t*(W/2+1),t*(W/2+5),[(34,-37),(145,-37),(156,-22),(150,26),(34,26)],'lightred',1.7)
            for yy,zz in [(43,-29),(140,-29),(43,18),(142,17)]:bolt((t*(W/2+5),yy,zz),(t,0,0),2)
            for j in range(3):
                yz('Pressed cooling slot',t*(W/2+5),t*(W/2+7),[(50+j*16,8),(56+j*16,8),(68+j*16,-14),(63+j*16,-14)],'blued',.4)
        shaped('Spreader spine',[(14,0,-60,40,11,3),(32,0,-64,44,10,3),(140,0,-60,43,12,3),(165,0,-56,33,8,3)],'ox')
        # Raised manufacturer's plate and fasteners on the spine's level face.
        box('Grapple / identification plate',(0,89,-68),(34,91,4),'red',1.5)
        mark('Top stencil','GR / 03',(0,89,-70.1),(0,-1,0),(1,0,0),13)
        for xx in [-12,12]:
            for yy in [50,129]:bolt((xx,yy,-70),(0,0,-1),1.7)
        for q in [-1,1]:
            for yy in [21,148]:band('Rail collar',(q*42,-4,-53),(q*42,L*.9,-49),yy/(L*.9),(yy+5)/(L*.9),11,'blued')
            piston('Flank actuator',(q*52,136,41),(q*52,25,40),6)
        # Three forged prongs. Blades have an actual ridge and tapered cutting edges.
        for j,(xx,zz,wd,ln) in enumerate([(-32,43,32,175),(32,43,32,167),(0,-35,9,182)]):
            basecol=col
            col=bpy.data.collections.new('MOTION • Tine '+str(j+1));basecol.children.link(col)
            col['pivot']=list(wp((xx,4,zz)))
            rings=[]
            for yy,w,h,dz,spread in [(14,wd,24,0,0),(-18,wd,25,0,1),(-75,wd*.83,22,2,4),(-ln+32,wd*.64,16,5,6),(-ln+12,wd*.40,10,8,7),(-ln,wd*.06,2,11,7)]:
                xc=xx+(1 if xx>0 else -1 if xx<0 else 0)*spread
                rings.append([(xc-w*.5,yy,zz+dz+h*.2),(xc-w*.24,yy,zz+dz-h*.5),(xc+w*.45,yy,zz+dz-h*.4),(xc+w*.5,yy,zz+dz+h*.4),(xc-w*.23,yy,zz+dz+h*.51)])
            loft('Forged grapple tine / %02d'%(j+1),rings,'silver' if j!=2 else 'steel',1.3)
            box('Blade heel',(xx,-1,zz),(wd+8,24,30),'blued',3)
            for yy in [-24,-62,-99]:bolt((xx,yy,zz-10),(0,0,-1),2.3)
            col=basecol
    else:
        for t in [-1,1]:
            yz('Open rail cheek',t*24,t*35,[(-15,-56),(16,-63),(100,-57),(131,-34),(124,35),(79,53),(11,58),(-23,34)],'red',2)
            yz('Grapple guide',t*27,t*36,[(-25,-40),(8,-39),(81,-30),(72,-13),(4,-18),(-42,-14)],'blued',2)
            piston('Linear carriage',(t*16,63,17),(t*17,-38,16),9)
            # Slender outer blades slide independently, as on the reference's narrow arm.
            w=9 if t==1 else 12
            rings=[]
            for yy,dx,zz,h,ww in [(9,0,-7,54,w+3),(-22,0,-5,45,w),(-92,2,-3,32,w),(-140 if t==1 else -157,4,0,20,w*.78),(-155 if t==1 else -179,6,5,3,w*.24)]:
                xx=t*(22+dx)
                rings.append([(xx-ww/2,yy,zz-h*.40),(xx+ww*.2,yy,zz-h*.50),(xx+ww/2,yy,zz-h*.3),(xx+ww*.28,yy,zz+h*.5),(xx-ww*.25,yy,zz+h*.4)])
            loft('Rail fork / working tine',rings,'steel' if t>0 else 'silver',.8)
            for yy in [-12,-40,-72,-100]:bolt((t*26,yy,-8),(t,0,0),2.4)
        box('Floating carriage',(0,50,-52),(43,63,15),'lightred',4)
        for t in [-1,1]:
            yz('Cassette motor access',t*37,t*40,[(15,-40),(58,-41),(73,-31),(70,18),(18,18)],'ox',1.5)
            for z in [-26,-18,-10,-2]:box('Motor / vent',(t*41,40,z),(3,33,3),'steel',.7)
            for yy in [18,64]:bolt((t*41,yy,12),(t,0,0),2.6)
        for dx in [-15,15]:bolt((dx,33,-60),(0,0,-1),2.5)
        mark('Carriage print','J-02',(0,57,-60),(1,0,0),(0,1,0),9)
    for t in [-1,1]:
        cabx=t*(W/2+2)
        cable('Loop handle',[(cabx,20,26),(cabx+t*7,26,48),(cabx+t*9,84,49),(cabx+t*8,96,32)],2.8,'steel')
        box('Belly rib',(t*(W/2-7),85,54),(9,109,10),'ox',2)
    # Connect cassette to elbow with side pivots, chrome rams and a central load member.
    reset()
    for dx in [-17,17]:
        piston('Tool crowd cylinder',rear+Vector((dx,-12,19)),Vector((x(216)+dx,532,402)),10)
    cyl('Tool root / axle',rear-Vector((32,0,0)),rear+Vector((32,0,0)),26,'red')
    group('09'+arm+' /  UMBILICAL     •     '+arm)
    pts=[(x(22),599,360),(x(40),625,392),(x(163),626,430),(x(229),586,484),(x(260),553,510),(x(273),506,492),(rear.x+s*18,rear.y+5,rear.z+31)]
    cable('High-flow flexible trunk',pts,10.2)
    # Bellows ribs along the free, curved span, following the evaluated Bezier.
    pathobj=next(reversed(col.objects.values()))
    from mathutils.geometry import interpolate_bezier
    bez=pathobj.data.splines[0].bezier_points
    ptsW=[]
    for k in range(len(bez)-1):
        ptsW+=list(interpolate_bezier(bez[k].co,bez[k].handle_right,bez[k+1].handle_left,bez[k+1].co,19))[:-1]
    ptsW.append(bez[-1].co.copy())
    def pix(v):return Vector((v.x/S+400,v.y/S+400,400-v.z/S))
    pp=[pix(v) for v in ptsW];arc=0;dist=0
    for a,b in zip(pp,pp[1:]):
        length=(b-a).length
        if length<.001:continue
        while dist<=arc+length:
            d=(b-a).normalized();p=a+d*(dist-arc)
            cyl('Conduit / spiral rib',p-d*.60,p+d*.60,10.6,'blued',20,.13)
            dist+=7.5
        arc+=length
    for j in range(2):
        cable('Auxiliary harness',[(x(92),569,345+j*7),(x(135),596,377+j*8),(x(197),565,403+j*7),(x(246),530,428+j*9),(rear.x+s*31,rear.y,rear.z-8+j*7)],3.1-j*.65)
    for p,q in [(pts[0],pts[1]),(pts[-1],pts[-2])]:
        a=Vector(p);b=Vector(q);d=(b-a).normalized()
        turned('Conduit union',a-d*2,a+d*14,[(0,13),(.14,14),(.38,14),(.41,12),(.70,12),(.78,13),(1,13)],'steel',12)
reset()
