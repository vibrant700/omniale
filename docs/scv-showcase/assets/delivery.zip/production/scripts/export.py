"""Portable output helper. No external Python packages required."""
import argparse,subprocess,os,tempfile,shutil
from pathlib import Path
P=Path(__file__).resolve().parents[1]
ap=argparse.ArgumentParser(description='Render the edited SCV project; keep the .blend files as source of truth.')
ap.add_argument('step',choices=['camera','assemble','film','all'])
ap.add_argument('--frames',type=Path,help='PNG cache folder (required for assemble)')
ap.add_argument('--blender',default=os.environ.get('BLENDER','blender'))
ap.add_argument('--ffmpeg',default=os.environ.get('FFMPEG','ffmpeg'))
ap.add_argument('--output',type=Path,default=P.parent/'showcase.mp4')
args=ap.parse_args()
def run(v,**kw):subprocess.run([str(x) for x in v],check=True,**kw)
if args.step=='assemble' and not args.frames:ap.error('assemble needs --frames PATH')
with tempfile.TemporaryDirectory(prefix='scv-export-') as td:
    cache=(args.frames or (P/'renders' if args.step=='camera' else Path(td)/'frames')).resolve()
    if args.step in ['camera','all']:
        env=os.environ.copy();env['SCV_FRAMES']=str(cache)
        run([args.blender,'-b',P/'photography.blend','--python-exit-code','1','-P',P/'scripts'/'render_plates.py'],env=env)
    if args.step in ['all','camera','assemble']:
        master=P/'media'/'photography.mp4'
        # Force keyframes at edits. Source master is deliberately cleaner than the web copy.
        run([args.ffmpeg,'-y','-hide_banner','-loglevel','warning','-framerate','24','-start_number','1','-i',cache/'SCV_%04d.png',
             '-c:v','libx264','-preset','fast','-crf','12','-pix_fmt','yuv420p','-colorspace','bt709','-color_primaries','bt709',
             '-color_trc','bt709','-vf','scale=out_color_matrix=bt709','-force_key_frames','0,4,8,12,15.791667,19.541667',
             '-movflags','+faststart',master])
    if args.step in ['film','all']:
        # Export the *saved edit*, including any revised cuts, gains or title positions.
        raw=Path(td)/'render.mp4'
        env=os.environ.copy();env['SCV_OUTPUT']=str(raw)
        run([args.blender,'-b',P/'edit.blend','--python-exit-code','1','--python-expr',
             "import bpy,os; s=bpy.context.scene; s.render.filepath=os.environ['SCV_OUTPUT']; bpy.ops.render.render(animation=True)"],env=env)
        mov=raw if raw.exists() else next(Path(td).glob('render*.mp4'))
        run([args.ffmpeg,'-y','-hide_banner','-loglevel','warning','-i',mov,'-map','0:v:0','-map','0:a:0','-c','copy','-movflags','+faststart',args.output.resolve()])
