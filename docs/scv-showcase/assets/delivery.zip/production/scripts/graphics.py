"""Typeset the transparent film plates. Only needed to change their artwork."""
from pathlib import Path
import os,math
from PIL import Image,ImageDraw,ImageFont
import numpy as np

P=Path(__file__).resolve().parents[1]
D=P/'graphics'
F=Path(os.environ.get('SCV_FONTS','/usr/share/fonts/truetype/dejavu'))
W,H=1600,900
cream='#f1eee5';muted='#cdd1c9';orange='#ffc16b';ink='#192022'
def font(size,kind='sans'):
    return ImageFont.truetype(str(F/('DejaVu'+{'sans':'Sans','bold':'Sans-Bold','mono':'SansMono','serif':'Serif'}[kind]+'.ttf')),size)
def new():
    global im,dr
    im=Image.new('RGBA',(W,H));dr=ImageDraw.Draw(im)
def text(x,y,txt,size,fill=cream,kind='sans',anchor='la'):
    dr.text((x,y),txt,font=font(size,kind),fill=fill,anchor=anchor)
def line(x1,y1,x2,y2,c,w=1):dr.line((x1,y1,x2,y2),fill=c,width=w)
def sym(x,y,sz,col):
    for i in [0,1,2]:
        a=x+i*sz*.38
        dr.polygon([(a,y+sz*.7),(a+sz*.31,y),(a+sz*.57,y),(a+sz*.26,y+sz*.7)],fill=col)
def header(x,y,txt='MACHINE REGISTER'):
    sym(x,y+1,23,orange)
    text(x+45,y-4,txt,20,cream,'bold')
def scrim(intensity=180):
    global im,dr
    x=np.arange(W)[None,:]; y=np.arange(H)[:,None]
    a=np.maximum(0,1-(x/760)**1.7)*intensity
    a=np.broadcast_to(a,(H,W)).astype('uint8')
    im=Image.new('RGBA',(W,H),(11,18,18,0));im.putalpha(Image.fromarray(a));dr=ImageDraw.Draw(im)
def save(fn):im.save(D/(fn+'.png'))
new();scrim(148)
header(76,64)
text(76,102,'INDUSTRIAL SERIES     /     NO. 007',16,muted,'mono')
line(76,307,124,307,orange,4)
text(76,343,'SCV',150,cream,'bold',anchor='lt')
text(83,481,'Field service walker',39,cream,'sans',anchor='lt')
text(85,555,'TYPE      /  BIPEDAL',18,muted,'mono')
text(85,589,'STUDY     /  ASSEMBLY & MOTION',18,muted,'mono')
line(78,791,410,791,'#b0b7ae',1)
text(80,811,'FIG. 01',17,orange,'mono')
text(407,811,'GENERAL ARRANGEMENT',17,cream,'mono','ra')
save('01_registration')

details=[
 ('02_tooling', '02','TOOLING','Grapple cassette','Three articulated working tines'),
 ('03_station', '03','OPERATOR','Open station','Canopy, harness and instrument panel'),
 ('04_powerpack','04','POWER','Twin impellers','Rear manifold and flexible returns'),
 ('05_running_gear','05','DRIVE','Walking gear','Split rocker pads and recoil cylinders'),
 ('06_assembly','06','ASSEMBLY','Complete chassis','SCV  /  Front three-quarter study')]
for fn,num,sub,title,desc in details:
    new()
    # A small opaque caption slug keeps contrast stable over moving metal.
    # The cut corner, folio, and ruled track echo the front plate.
    x,y=63,715
    wd=max(395,int(font(19).getlength(desc))+52)
    dr.polygon([(x,y),(x+wd,y),(x+wd,y+121),(x+wd-12,y+133),(x,y+133)],fill=(17,24,25,237))
    line(x,y,x+65,y,orange,4)
    text(x+18,y+14,'FIG. '+num,16,orange,'mono')
    text(x+wd-17,y+15,sub,16,muted,'mono','ra')
    text(x+17,y+43,title,34,cream,'bold')
    text(x+19,y+93,desc,19,muted)
    save(fn)
new()
dr.polygon([(659,0),(765,0),(946,900),(840,900)],fill=(21,27,27,245))
dr.polygon([(762,0),(770,0),(951,900),(943,900)],fill=orange)
dr.polygon([(780,0),(782,0),(963,900),(961,900)],fill=cream)
save('shutter')

# Quiet end hold, with attribution readable before the final fade.
new()
dr.rectangle((0,0,W,H),fill=ink)
sym(76,65,24,orange);text(120,61,'MACHINE REGISTER',20,cream,'bold')
text(1525,65,'INDUSTRIAL SERIES   /   007',17,muted,'mono','ra')
line(76,118,1524,118,'#56605d')
text(76,298,'SCV',156,cream,'bold',anchor='lt')
text(80,468,'Field service walker',42,cream)
line(80,585,184,585,orange,3)
text(82,639,'REFERENCE MODEL',17,orange,'mono')
text(82,676,'JohnMesplay',34,cream,'sans')
text(82,739,'SCV   /   CC BY 4.0',19,muted,'mono')
# Right-hand colophon: a cropped engineering-section symbol.
for r in [160,164,208]:
    dr.ellipse((1255-r,422-r,1255+r,422+r),outline='#46514e',width=2)
for deg in range(0,360,10):
    a=math.radians(deg);r=212;d=18 if deg%30==0 else 7
    line(1255+r*math.cos(a),422+r*math.sin(a),1255+(r+d)*math.cos(a),422+(r+d)*math.sin(a),orange if deg%90==0 else '#5c6763',2)
text(1255,412,'07',100,cream,'bold','mm')
text(1255,500,'CATALOGUE NO.',16,muted,'mono','mm')
line(76,811,1524,811,'#56605d')
text(78,834,'ASSET STUDY',16,muted,'mono');text(1522,834,'END   /   06',16,orange,'mono','ra')
save('07_colophon')
