"""Assemble the calibrated survey renders made by render_survey.py."""
from pathlib import Path
import os
from PIL import Image,ImageFont,ImageDraw
P=Path(__file__).resolve().parents[1];src=Path(os.environ.get('SCV_SURVEY',P.parent/'survey'))
F=Path(os.environ.get('SCV_FONTS','/usr/share/fonts/truetype/dejavu'))
def font(size,face='Sans'):return ImageFont.truetype(str(F/('DejaVu'+face+'.ttf')),size)
im=Image.new('RGB',(1920,1560),'#e7e7df');d=ImageDraw.Draw(im)
ink='#1f2829';sub='#55615d';red='#9b342c';line='#afb8b1'
def tx(p,t,sz,cl=ink,face='Sans',anchor='la'):d.text(p,t,font=font(sz,face),fill=cl,anchor=anchor)
tx((64,36),'MACHINE REGISTER',24,ink,'Sans-Bold')
tx((1856,43),'INDUSTRIAL SERIES    /    PLATE 007',20,sub,'SansMono','ra')
d.line((64,92,1856,92),fill=ink,width=2)
tx((60,103),'SCV',104,ink,'Sans-Bold')
tx((340,138),'Orthographic survey',54)
tx((342,211),'FIELD SERVICE WALKER     /     SIX EXTERIOR VIEWS',18,sub,'SansMono')
G=[('front','Front', '−Y'),('back','Rear','+Y'),('top','Plan','+Z'),('left','Left','+X'),('right','Right','−X'),('bottom','Underside','−Z')]
for i,(v,title,axis) in enumerate(G):
    x=65+(i%3)*605;y=273+(i//3)*592
    d.line((x,y,x+580,y),fill=line,width=2)
    tx((x,y+11),f'0{i+1}',19,red,'SansMono')
    tx((x+58,y+3),title,31,ink,'Sans-Bold')
    tx((x+570,y+12),axis,19,sub,'SansMono','ra')
    a=Image.open(src/(v+'.png')).convert('RGBA').resize((536,536),Image.Resampling.LANCZOS)
    im.paste(a,(x+20,y+46),a)
d.line((64,1471,1856,1471),fill=ink,width=2)
tx((65,1493),'PROJECTION    ORTHOGRAPHIC   /   2.32 UNIT FIELD',17,sub,'SansMono')
tx((1855,1493),'Z UP     •     FRONT −Y     •     LEFT +X',17,sub,'SansMono','ra')
im.save(P.parent/'survey.jpg',quality=94,subsampling=0)
