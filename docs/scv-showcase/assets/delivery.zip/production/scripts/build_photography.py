"""Stage the linked model and author the six camera moves."""
import bpy, math
from pathlib import Path
from mathutils import Vector
from math import cos,sin,pi
P=Path(__file__).resolve().parents[1]
bpy.ops.wm.read_factory_settings(use_empty=True)
bpy.context.preferences.filepaths.save_version=0
s=bpy.context.scene;s.name='SCV  /  Photography'
with bpy.data.libraries.load(str(P.parent/'asset.blend'),link=True) as (src,dst):
    dst.collections=['SCV • Unit 07']
s.collection.children.link(dst.collections[0])
bpy.context.scene.world=bpy.data.worlds.new('Hangar ambient')
s.world.use_nodes=True
sw=s.world.node_tree
sw.nodes['Background'].inputs['Color'].default_value=(.155,.194,.21,1)
sw.nodes['Background'].inputs['Strength'].default_value=.42
def collection(name):
    global C
    C=bpy.data.collections.new(name);s.collection.children.link(C)
collection('MOTION  /  actuator test')
def find_layers(lc):
    yield lc
    for c in lc.children:yield from find_layers(c)
for lc in list(find_layers(bpy.context.view_layer.layer_collection)):
    part=lc.collection
    if not part.name.startswith('MOTION •'):continue
    pivot=Vector(part['pivot'])
    driver=bpy.data.objects.new(part.name.replace('MOTION •','Drive /'),None);C.objects.link(driver);driver.location=pivot
    driver.empty_display_size=.04
    for orig in part.objects:
        o=orig.copy();C.objects.link(o);o.parent=driver;o.location=orig.location-pivot
    lc.exclude=True
    if 'Rotor' in part.name:
        for f,v in [(1,0),(288,5),(379,10),(648,15)]:
            driver.rotation_euler.y=(1 if part.name.endswith('L') else -1)*v*2*pi
            driver.keyframe_insert(data_path='rotation_euler',frame=f)
    else:
        j=int(part.name[-1])-1
        for f,degrees in [(1,0),(98,0),(137,10),(157,10),(184,0),(648,0)]:
            driver.rotation_euler.z=math.radians(degrees)*[-1,1,0][j]
            driver.rotation_euler.x=math.radians(degrees)*[0,0,.84][j]
            driver.keyframe_insert(data_path='rotation_euler',frame=f)
collection('STAGE  /  rotary survey pad')
def paint(name,c,m,r):
    ma=bpy.data.materials.new(name);ma.diffuse_color=(*c,1);ma.use_nodes=True
    p=ma.node_tree.nodes['Principled BSDF'];p.inputs['Base Color'].default_value=(*c,1);p.inputs['Metallic'].default_value=m;p.inputs['Roughness'].default_value=r;return ma
floor=paint('Studio floor / carbon',(.015,.020,.022),.12,.69)
pad=paint('Survey plate / gunmetal',(.030,.039,.041),.45,.50)
ring=paint('Datum / oxidized alloy',(.093,.119,.12),.62,.42)
yellow=paint('Datum / signal brass',(.48,.239,.059),.56,.39)
def link(o):
    for c in list(o.users_collection):c.objects.unlink(o)
    C.objects.link(o);return o
def disk(name,r,h,z,ma,n=240):
    bpy.ops.mesh.primitive_cylinder_add(vertices=n,radius=r,depth=h,location=(0,0,z))
    o=link(bpy.context.object);o.name=name;o.data.materials.append(ma)
    b=o.modifiers.new('Fine edge','BEVEL');b.width=.004;b.segments=3
    o.modifiers.new('Normals','WEIGHTED_NORMAL')
    return o
ground=-.827
disk('Cyclorama floor',190,.06,ground-.066,floor)
# Curved cyc: the low camera never sees a horizon discontinuity.
prof=[(7.5,-.036),(9.2,.03),(10,.29),(10.7,.75),(11.16,1.41),(11.5,2.4),(11.62,3.4),(11.62,12)]
vs=[(r*cos(i*2*pi/128),r*sin(i*2*pi/128),ground+h) for r,h in prof for i in range(128)]
fs=[(j*128+i,j*128+(i+1)%128,(j+1)*128+(i+1)%128,(j+1)*128+i) for j in range(len(prof)-1) for i in range(128)]
me=bpy.data.meshes.new('Cyclorama sweep');me.from_pydata(vs,[],fs)
for f in me.polygons:f.use_smooth=True
ob=bpy.data.objects.new(me.name,me);C.objects.link(ob);me.materials.append(floor)
disk('Inspection turnplate',1.49,.034,ground-.017,pad)
def arc(name,r0,r1,a0,a1,ma,n=96,z=ground+.00045):
    vs=[(r*cos(a0+(a1-a0)*j/n),r*sin(a0+(a1-a0)*j/n),z) for j in range(n+1) for r in [r0,r1]]
    me=bpy.data.meshes.new(name);me.from_pydata(vs,[],[(2*i,2*i+1,2*i+3,2*i+2) for i in range(n)]);o=bpy.data.objects.new(name,me);C.objects.link(o);me.materials.append(ma)
for j in range(8):
    a=j*pi/4
    arc('Quadrant engraving',1.386,1.391,a+.025,a+pi/4-.025,ring,32)
    for k in range(3):
        arc('Painted alignment index',1.403,1.443 if k==0 else 1.425,a+.020*k,a+.020*k+.005,yellow if j%2==0 else ring,2)
arc('Perimeter inlay',1.47,1.473,0,2*pi,ring,256)
collection('LIGHTING  /  softboxes')
def aim(o,p):o.rotation_euler=(Vector(p)-o.location).to_track_quat('-Z','Y').to_euler()
def light(name,loc,target,energy,c,sx,sy):
    d=bpy.data.lights.new(name,'AREA');d.energy=energy;d.shape='RECTANGLE';d.size=sx;d.size_y=sy;d.color=c
    o=bpy.data.objects.new(name,d);C.objects.link(o);o.location=loc;aim(o,target)
light('01 | warm book light',(-3,-4,4.8),(0,0,.05),810,(1,.88,.77),4.1,3.1)
light('02 | port strip',(3.4,-1.8,2.6),(0,0,.2),470,(.73,.86,1),1.5,3.3)
light('03 | high edge',(-1.7,3.0,3.4),(0,0,.3),1040,(.78,.89,1),2.7,2.1)
light('04 | back strip',(2.1,2.1,1.4),(.1,.1,0),310,(1,.76,.52),.95,2.6)
light('05 | camera bounce',(0,-4,.3),(0,0,0),100,(.89,.94,1),3.2,.75)
light('06 | back wall wash',(0,3.4,4.5),(0,4,ground),145,(.55,.70,.72),5.5,4)
collection('CAMERAS  /  six studies')
# fr, to, name, look target A/B, bearing A/B, elevation A/B, distance A/B, lens, horizontal shift A/B
SHOTS=[
 (1,96,'01   Registration',(-.02,0,-.015),(-.02,0,-.025),-27,-15,12,9,6.35,6.17,60,-.175,-.165),
 (97,192,'02   Tool cassette',(-.67,-.43,-.25),(-.65,-.38,-.23),-69,-49,15,23,3.47,3.41,57,-.07,-.07),
 (193,288,'03   Operator station',(.028,-.085,.38),(.038,-.06,.47),10,-14,7,25,2.87,2.63,59,0,.025),
 (289,379,'04   Return manifold',(.025,.41,.065),(.025,.38,.13),162,200,12,19,3.64,3.39,56,0,.025),
 (380,469,'05   Walking gear',(.30,.30,-.53),(.24,.29,-.48),90,122,3,10,3.07,3.21,58,0,0),
 (470,648,'06   Assembly',(.02,0,-.015),(.02,0,-.03),47,9,17,7,6.36,6.53,61,.015,-.07)]
for fa,fb,name,ta,tb,aa,ab,ea,eb,da,db,lens,sa,sb in SHOTS:
    d=bpy.data.cameras.new(name);o=bpy.data.objects.new(name,d);C.objects.link(o)
    d.lens=lens;d.clip_start=.02;d.clip_end=500
    last=None
    for j in range(13):
        q=j/12
        f=round(fa+(fb-fa)*q)
        # Constant drift through edits with a gentle ease near the closing hold.
        t=q if fa<470 else 1-(1-q)**1.62
        a=math.radians(aa+(ab-aa)*t); e=math.radians(ea+(eb-ea)*t);dist=da+(db-da)*t
        target=Vector(ta).lerp(Vector(tb),t)
        o.location=target+dist*Vector((sin(a)*cos(e),-cos(a)*cos(e),sin(e)))
        r=(target-o.location).to_track_quat('-Z','Y').to_euler()
        if last:r.make_compatible(last)
        o.rotation_euler=r;last=r
        o.keyframe_insert(data_path='location',frame=f);o.keyframe_insert(data_path='rotation_euler',frame=f)
    for f,sh in [(fa,sa),(fb,sb)]:
        d.shift_x=sh;d.keyframe_insert(data_path='shift_x',frame=f)
    marker=s.timeline_markers.new(name,frame=fa);marker.camera=o
    if fa==1:s.camera=o
s.frame_start=1;s.frame_end=648;s.render.fps=24
s.render.resolution_x=1600;s.render.resolution_y=900;s.render.resolution_percentage=100
s.render.engine='CYCLES';s.cycles.device='GPU';s.cycles.samples=24;s.cycles.use_denoising=True
s.cycles.denoising_use_gpu=True;s.cycles.denoising_prefilter='FAST';s.cycles.denoising_quality='BALANCED'
s.cycles.max_bounces=5;s.cycles.diffuse_bounces=2;s.cycles.glossy_bounces=3
s.cycles.use_adaptive_sampling=True;s.cycles.adaptive_threshold=.08
s.render.use_persistent_data=True
s.view_settings.view_transform='AgX'
s.render.image_settings.file_format='PNG';s.render.image_settings.color_mode='RGB'
s.render.image_settings.compression=15
s.render.filepath='//renders/SCV_'
s.frame_set(1)
for screen in bpy.data.screens:
    for area in screen.areas:
        if area.type=='VIEW_3D':
            area.spaces.active.region_3d.view_perspective='CAMERA'
            area.spaces.active.shading.color_type='MATERIAL'
            area.spaces.active.overlay.show_overlays=False
for lib in bpy.data.libraries:lib.filepath='//../asset.blend'
bpy.ops.wm.save_as_mainfile(filepath=str(P/'photography.blend'),compress=True,relative_remap=False)
