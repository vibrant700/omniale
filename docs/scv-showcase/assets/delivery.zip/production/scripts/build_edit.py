"""Rebuild the editable VSE assembly from the clean camera master."""
from pathlib import Path
import bpy,os
P=Path(__file__).resolve().parents[1]
bpy.ops.wm.read_factory_settings(use_empty=True)
bpy.context.preferences.filepaths.save_version=0
s=bpy.context.scene;s.name='SCV  /  Picture & sound'
s.frame_start=1;s.frame_end=648;s.render.fps=24
s.render.resolution_x=1600;s.render.resolution_y=900;s.render.resolution_percentage=100
s.view_settings.view_transform='Standard'
s.sequencer_colorspace_settings.name='sRGB'
se=s.sequence_editor_create();strips=se.strips
plate=strips.new_movie('CAMERA MASTER  |  photography.blend',str(P/'media'/'photography.mp4'),1,1)
plate.filepath='//media/photography.mp4'
def key(o,prop,pairs):
    for f,v in pairs:setattr(o,prop,v);o.keyframe_insert(data_path=prop,frame=f)
def image(fn,name,ch,a,b):
    st=strips.new_image(name,str(P/'graphics'/(fn+'.png')),ch,a)
    st.directory='//graphics/'
    st.right_handle=b+1;st.blend_type='ALPHA_OVER'
    return st
def color(name,ch,a,b,col):
    st=strips.new_effect(name=name,type='COLOR',channel=ch,frame_start=a,length=b-a+1)
    st.color=col;st.blend_type='ALPHA_OVER';return st
op=image('01_registration','01   /   Registration',2,1,96)
key(op,'blend_alpha',[(1,0),(11,1),(88,1),(96,0)])
for fn,lab,a,b in [('02_tooling','Grapple cassette',100,188),('03_station','Open station',197,283),('04_powerpack','Twin impellers',293,375),('05_running_gear','Walking gear',384,465),('06_assembly','Complete chassis',479,575)]:
    st=image(fn,lab,2,a,b)
    key(st,'blend_alpha',[(a,0),(a+7,1),(b-6,1),(b,0)])
    key(st.transform,'offset_x',[(a,-19),(a+8,0)])
for f in [97,289]:
    st=image('shutter','Index sweep',3,f-5,f+5)
    key(st.transform,'offset_x',[(f-5,-1000),(f+5,1000)])
st=color('Opening exposure',4,1,10,(.005,.007,.007))
key(st,'blend_alpha',[(1,.89),(10,0)])
st=color('Re-index  /  assembly',3,465,475,(.008,.012,.013))
key(st,'blend_alpha',[(465,0),(469,.86),(475,0)])
st=image('07_colophon','Colophon   /   reference credit',2,594,648)
key(st,'blend_alpha',[(594,0),(605,1)])
st=color('Fade to black',4,637,648,(0,0,0))
key(st,'blend_alpha',[(637,0),(648,1)])

def sound(name,fn,ch,a,level):
    st=strips.new_sound(name,str(P/'media'/(fn+'.wav')),ch,a)
    st.sound.filepath='//media/'+fn+'.wav';st.volume=level
    return st
music=sound('MUSIC    /    Industrial pulse','industrial_pulse',5,1,.76)
music.right_handle=649
key(music,'volume',[(1,.30),(15,.76),(89,.76),(96,.56),(106,.76),(184,.76),(192,.62),(202,.76),
                    (282,.76),(289,.55),(301,.76),(372,.76),(380,.60),(393,.76),(457,.76),(468,.48),
                    (490,.78),(588,.78),(604,.63),(622,.58),(648,0)])
for f,lev in [(97,.40),(289,.34),(470,.31)]:
    sound('FX   /   sweep into %d'%f,'whoosh',6,f-16,lev)
for f,lev in [(97,.42),(193,.29),(380,.31)]:
    sound('FX   /   index contact %d'%f,'hit',7,f-1,lev)
sound('FX   /   assembly reveal','drop',8,466,.50)
for f,l in [(1,'01  |  Registration'),(97,'02  |  Tooling'),(193,'03  |  Operator'),(289,'04  |  Power'),(380,'05  |  Drive'),(470,'06  |  Assembly'),(594,'Colophon')]:
    s.timeline_markers.new(l,frame=f)
for i,label in enumerate(['Picture','Titles','Index sweeps','Exposures','Music','Air','Contact','Sub'],1):
    try:se.channels[i].name=label
    except (IndexError,KeyError):pass
for st in strips:st.select=False
se.active_strip=plate
s.render.use_sequencer=True
s.render.image_settings.media_type='VIDEO'
s.render.image_settings.file_format='FFMPEG'
s.render.ffmpeg.format='MPEG4';s.render.ffmpeg.codec='H264'
s.render.ffmpeg.constant_rate_factor='HIGH';s.render.ffmpeg.ffmpeg_preset='GOOD'
s.render.ffmpeg.audio_codec='AAC';s.render.ffmpeg.audio_bitrate=256
s.render.ffmpeg.audio_mixrate=48000;s.render.ffmpeg.audio_channels='STEREO'
s.render.ffmpeg.gopsize=24
s.render.filepath='//../showcase.mp4'
s.frame_set(37)
for a in bpy.context.screen.areas:
    if a.type=='VIEW_3D':
        a.type='SEQUENCE_EDITOR';a.spaces.active.view_type='SEQUENCER_PREVIEW'
bpy.ops.wm.save_as_mainfile(filepath=str(P/'edit.blend'),relative_remap=False,compress=True)
