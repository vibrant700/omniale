"""Render a six-sided inspection from the asset, without the film stage."""
import bpy,math,os
from pathlib import Path
from mathutils import Matrix,Vector
s=bpy.context.scene
p=bpy.context.preferences.addons['cycles'].preferences
try:
    p.compute_device_type='CUDA';p.refresh_devices()
    for d in p.devices:d.use=d.type=='CUDA'
    gpu=any(d.use for d in p.devices)
except RuntimeError:gpu=False
s.render.engine='CYCLES';s.cycles.device='GPU' if gpu else 'CPU'
s.cycles.samples=32;s.cycles.use_denoising=True;s.cycles.denoising_use_gpu=True
s.render.film_transparent=True;s.render.image_settings.color_mode='RGBA'
s.render.resolution_x=s.render.resolution_y=1000;s.render.resolution_percentage=100
s.world.use_nodes=True
s.world.node_tree.nodes['Background'].inputs[0].default_value=(.16,.18,.22,1)
s.world.node_tree.nodes['Background'].inputs[1].default_value=.65
for i,(v,size,pow) in enumerate([((-4,-6,7),4,1400),((5,-3,4),4,1000),((1,5,6),4,1600),((0,0,-5),4,600)]):
    d=bpy.data.lights.new('Softbox %d'%i,'AREA');d.energy=pow;d.shape='DISK';d.size=size
    ob=bpy.data.objects.new(d.name,d);s.collection.objects.link(ob);ob.location=v
    ob.rotation_euler=(-Vector(v)).to_track_quat('-Z','Y').to_euler()
cd=bpy.data.cameras.new('Survey');cd.type='ORTHO';cd.ortho_scale=2.32
cam=bpy.data.objects.new(cd.name,cd);s.collection.objects.link(cam);s.camera=cam
out=Path(os.environ.get('SCV_SURVEY',bpy.path.abspath('//survey')));out.mkdir(exist_ok=True,parents=True)
for name,v,up in [('front',(0,-8,0),(0,0,1)),('back',(0,8,0),(0,0,1)),('left',(8,0,0),(0,0,1)),('right',(-8,0,0),(0,0,1)),('top',(0,0,8),(0,-1,0)),('bottom',(0,0,-8),(0,-1,0))]:
    back=Vector(v).normalized();u=Vector(up);right=u.cross(back)
    cam.matrix_world=Matrix((right,u,back)).transposed().to_4x4();cam.location=v
    s.render.filepath=str(out/(name+'.png'));bpy.ops.render.render(write_still=True)
