"""Build the SCV in the calibrated 800-square orthographic drafting space."""
import bpy, bmesh, math, os, sys
from mathutils import Vector, Matrix
from pathlib import Path
from math import sin,cos,pi

HERE=Path(__file__).resolve().parent
PROD=HERE.parent
OUT=PROD.parent
bpy.ops.wm.read_factory_settings(use_empty=True)
bpy.context.preferences.filepaths.save_version=0
S=2.32/800
scene=bpy.context.scene
scene.name='SCV | Reusable assembly'
root=bpy.data.collections.new('SCV • Unit 07')
scene.collection.children.link(root)
root.asset_mark()
root.asset_data.description='SCV industrial service walker. Front -Y; left +X. Self-contained hard surface assembly.'
def group(name):
    global col
    col=bpy.data.collections.new(name)
    root.children.link(col)

def srgb(h):
    c=[int(h[i:i+2],16)/255 for i in (0,2,4)]
    return tuple(t/12.92 if t<=.04045 else ((t+.055)/1.055)**2.4 for t in c)+(1,)
M={}
wear=bpy.data.images.load(str(PROD/'media'/'wear_field.png'))
wear.name='SCV · workshop abrasions / tile 01'
wear.colorspace_settings.name='Non-Color'
wear.pack()
def mat(key,name,h,metal,rough,paint=False,emit=0):
    m=bpy.data.materials.new(name);M[key]=m
    m.diffuse_color=srgb(h); m.use_nodes=True
    nt=m.node_tree;n=nt.nodes;L=nt.links.new
    p=n.get('Principled BSDF')
    p.inputs['Base Color'].default_value=srgb(h)
    p.inputs['Metallic'].default_value=metal
    p.inputs['Roughness'].default_value=rough
    if emit:
        p.inputs['Emission Color'].default_value=srgb(h)
        p.inputs['Emission Strength'].default_value=emit
    if paint or key in ['steel','silver','edge','rubber','dark','blued']:
        tex=n.new('ShaderNodeTexCoord');tex.location=(-820,50)
        no=n.new('ShaderNodeTexNoise');no.location=(-610,-140)
        L(tex.outputs['Object'],no.inputs['Vector'])
        no.inputs['Scale'].default_value=220 if not paint else 140
        no.inputs['Detail'].default_value=3
        ramp=n.new('ShaderNodeValToRGB');ramp.location=(-380,-120)
        for e,pos,r in zip(ramp.color_ramp.elements,[.25,.75],[rough-.11,rough+.14]):
            e.position=pos; e.color=(r,r,r,1)
        L(no.outputs['Fac'],ramp.inputs[0]);L(ramp.outputs[0],p.inputs['Roughness'])
        bump=n.new('ShaderNodeBump');bump.location=(-110,-200)
        bump.inputs['Strength'].default_value=.15;bump.inputs['Distance'].default_value=.00065
        L(no.outputs['Fac'],bump.inputs['Height']);L(bump.outputs[0],p.inputs['Normal'])
        if paint or key=='edge':
            v=n.new('ShaderNodeVectorMath');v.operation='SCALE';v.location=(-610,190)
            L(tex.outputs['Object'],v.inputs[0]);v.inputs['Scale'].default_value=3.9
            ti=n.new('ShaderNodeTexImage');ti.image=wear;ti.projection='BOX';ti.projection_blend=.16;ti.location=(-400,220)
            L(v.outputs['Vector'],ti.inputs[0])
            mix=n.new('ShaderNodeMixRGB');mix.location=(-95,120)
            mix.inputs[1].default_value=srgb(h);mix.inputs[2].default_value=srgb('777b79')
            L(ti.outputs['Color'],mix.inputs[0]);L(mix.outputs[0],p.inputs['Base Color'])
    return m
mat('red','01 / Oxide vermilion · enamel','aa3228',.56,.35,True)
mat('lightred','02 / Signal red · service doors','cf4532',.46,.34,True)
mat('ox','03 / Dark garnet · castings','69241e',.68,.39,True)
mat('orange','04 / Marigold · canopy','ed9b32',.46,.32,True)
mat('ivory','05 / Mineral white · markings','e1dccc',.33,.44,True)
mat('steel','06 / Graphite steel · satin','4b5457',.85,.31)
mat('silver','07 / Honed alloy','a8b1b1',.91,.26)
mat('blued','08 / Oil-black fasteners','323d40',.81,.30)
mat('rubber','09 / Hose · vulcanized','24292a',.10,.51)
mat('dark','10 / Deep charcoal · wells','1d2223',.44,.4)
mat('edge','11 / Burnished enamel edges','7a6259',.78,.36)
mat('brass','12 / Brass fittings','ae8450',.81,.32)
mat('amber','13 / Inspection lamps','ffb03c',.22,.24,2.5)
mat('cyan','14 / Instrument phosphor','9fe4d9',.11,.26,1.8)
mat('seat','15 / Saddle vinyl','402723',.05,.52)
mat('cloth','16 / Apron · woven graphite','383c3a',.13,.77)
I=Matrix.Identity(4); frame=I.copy()
def wp(p):
    a=frame@Vector(p)
    return Vector(((a.x-400)*S,(a.y-400)*S,(400-a.z)*S))
def local(origin,ex=(1,0,0),ey=(0,1,0),ez=(0,0,1)):
    global frame
    frame=Matrix((Vector(ex),Vector(ey),Vector(ez))).transposed().to_4x4()
    frame.translation=Vector(origin)
def reset():
    global frame
    frame=I.copy()
def mesh(name,verts,faces,m,bev=0,smooth=False,edge=True):
    pts=[wp(v) for v in verts]
    c=sum(pts,Vector())/len(pts)
    me=bpy.data.meshes.new(name); me.from_pydata([p-c for p in pts],[],faces);me.update()
    bm=bmesh.new();bm.from_mesh(me);bmesh.ops.recalc_face_normals(bm,faces=bm.faces);bm.to_mesh(me);bm.free()
    o=bpy.data.objects.new(name,me);col.objects.link(o);o.location=c
    me.materials.append(M[m])
    if smooth:
        for f in me.polygons:f.use_smooth=True
        me.set_sharp_from_angle(angle=math.radians(36))
    if bev:
        b=o.modifiers.new('Machined corner radii','BEVEL');b.width=bev*S;b.segments=3;b.limit_method='ANGLE'
        if m in ['red','ox','lightred','orange'] and edge:
            me.materials.append(M['edge']);b.material=1
        b.harden_normals=True
        wn=o.modifiers.new('Face weighted normals','WEIGHTED_NORMAL');wn.keep_sharp=True;wn.weight=40
    return o
def loops(n,closed=True):
    return [(i,(i+1)%n,(i+1)%n+n,i+n) for i in range(n if closed else n-1)]
def box(name,p,d,m='red',b=1.2):
    x,y,z=p;w,h,k=[t/2 for t in d]
    vs=[(x+i*w,y+j*h,z+l*k) for l in [-1,1] for i,j in [(-1,-1),(1,-1),(1,1),(-1,1)]]
    return mesh(name,vs,[(0,1,2,3),(4,5,6,7)]+loops(4),m,b)
def yz(name,x1,x2,profile,m='red',b=1.6):
    n=len(profile)
    return mesh(name,[(x,y,z) for x in (x1,x2) for y,z in profile],[tuple(range(n)),tuple(range(n,2*n))]+loops(n),m,b)
def xz(name,y1,y2,profile,m='red',b=1.5):
    n=len(profile)
    return mesh(name,[(x,y,z) for y in (y1,y2) for x,z in profile],[tuple(range(n)),tuple(range(n,2*n))]+loops(n),m,b)
def loft(name,stations,m,b=1.5):
    n=len(stations[0]);k=len(stations)
    faces=[tuple(range(n)),tuple((k-1)*n+i for i in range(n))]
    for j in range(k-1):
        faces.extend([tuple(i+j*n for i in f) for f in loops(n)])
    return mesh(name,[p for ring in stations for p in ring],faces,m,b)
def shaped(name,rows,m,b=1.2):
    """(depth, center x, center z, width, height, corner) bulkhead stations."""
    stations=[]
    for y,x,z,w,h,c in rows:
        a=w/2;d=h/2
        stations.append([(x+i,y,z+j) for i,j in [(-a+c,-d),(a-c,-d),(a,-d+c),(a,d-c),(a-c,d),(-a+c,d),(-a,d-c),(-a,-d+c)]])
    return loft(name,stations,m,b)
def turned(name,a,b,profile,m='steel',n=32,bevel=.45):
    a=Vector(a);v=Vector(b)-a
    u=v.normalized().cross(Vector((0,0,1)) if abs(v.normalized().z)<.9 else Vector((0,1,0))).normalized()
    w=v.normalized().cross(u)
    rings=[[a+v*t+r*(u*cos(i*2*pi/n)+w*sin(i*2*pi/n)) for i in range(n)] for t,r in profile]
    k=len(rings)
    # A return profile describes a hollow rolled mouth. Never cap its bore.
    faces=[] if profile[-1][0]<max(t for t,r in profile) else [tuple(range(n)),tuple((k-1)*n+i for i in range(n))]
    for j in range(k-1):faces.extend([tuple(i+j*n for i in f) for f in loops(n)])
    return mesh(name,[p for ring in rings for p in ring],faces,m,bevel,True)
def cyl(name,a,b,r,m='steel',n=32,bevel=.55):
    return turned(name,a,b,[(0,r),(1,r)],m,n,bevel)
def band(name,a,b,t0,t1,r,m):
    a,b=Vector(a),Vector(b)
    return cyl(name,a.lerp(b,t0),a.lerp(b,t1),r,m)
def piston(name,a,b,r=8):
    a,b=Vector(a),Vector(b)
    turned(name+' · housing',a,a.lerp(b,.65),[(0,r*.8),(.06,r),(.14,r),(.16,r*.9),(.79,r*.9),(.82,r),(.94,r),(1,r*.75)],'ox')
    cyl(name+' · chrome rod',a.lerp(b,.62),b,r*.55,'silver')
    band(name+' · gland',a,b,.59,.66,r*.92,'blued')
def cable(name,pts,r,m='rubber',cyclic=False):
    cu=bpy.data.curves.new(name,'CURVE');cu.dimensions='3D';cu.resolution_u=12;cu.bevel_depth=r*S;cu.bevel_resolution=3
    s=cu.splines.new('BEZIER');s.bezier_points.add(len(pts)-1)
    for bp,pt in zip(s.bezier_points,pts):
        bp.co=wp(pt);bp.handle_left_type='AUTO';bp.handle_right_type='AUTO'
    s.use_cyclic_u=cyclic;cu.use_fill_caps=True
    obj=bpy.data.objects.new(name,cu);col.objects.link(obj);cu.materials.append(M[m])
    return obj
def bolt(p,axis=(0,-1,0),r=2.5):
    a=Vector(p);v=Vector(axis).normalized()
    cyl('Captive washer',a,a+v*1.1,r*1.28,'blued',16,.12)
    cyl('Hex head',a+v*.8,a+v*2.3,r,'silver',6,.22)
def joint(name,a,b,r):
    turned(name+' / spindle',a,b,[(0,.71*r),(.04,r*.85),(.12,r*.85),(.15,r),(.31,r),(.33,r*.93),(.69,r*.93),(.7,r),(.84,r),(.88,r*.79),(1,r*.67)],'steel')
    a,b=Vector(a),Vector(b);v=(b-a).normalized()
    cyl(name+' / retainer',b,b+v*2,r*.49,'dark')
    cyl(name+' / lock',b+v*2,b+v*3.6,r*.32,'silver',8)
def mark(name,body,p,right,up,size,m='ivory',align='CENTER'):
    p0=wp(p);r=(wp(Vector(p)+Vector(right))-p0).normalized();u=(wp(Vector(p)+Vector(up))-p0).normalized()
    n=r.cross(u).normalized();u=n.cross(r).normalized()
    cu=bpy.data.curves.new(name,'FONT');cu.body=body;cu.align_x=align;cu.align_y='CENTER';cu.size=size*S;cu.space_character=1.08
    obj=bpy.data.objects.new(name,cu);col.objects.link(obj)
    obj.matrix_world=Matrix((r,u,n)).transposed().to_4x4();obj.location=p0;cu.materials.append(M[m])
    return obj

# Modules share the drawing helpers above and have no external dependencies.
for module in ['hull','drive','tools']:
    exec(compile((HERE/(module+'.py')).read_text(),module+'.py','exec'),globals())
reset()
scene.world=bpy.data.worlds.new('Neutral environment')
scene.world.color=(.30,.30,.30)
for s in bpy.data.screens:
    for a in s.areas:
        if a.type=='VIEW_3D':
            sp=a.spaces.active;sp.overlay.show_overlays=False
            sp.shading.color_type='MATERIAL';sp.shading.light='STUDIO';sp.shading.show_cavity=True;sp.shading.cavity_type='WORLD'
            sp.region_3d.view_distance=3.5;sp.region_3d.view_rotation=Vector((-1.4,2.7,-1.0)).to_track_quat('-Z','Y');sp.region_3d.view_location=(0,0,0)
bpy.ops.wm.save_as_mainfile(filepath=str(OUT/'asset.blend'),compress=True)
print('SCV meshes and editable fittings:',len(root.all_objects))
