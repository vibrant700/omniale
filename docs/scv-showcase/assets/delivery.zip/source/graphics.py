"""Typeset five 16:9 register plates. Args: cache/triangles.npy (optional)."""
from pathlib import Path
import sys,math
import numpy as np
from PIL import Image,ImageFont,ImageDraw,ImageFilter
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'media'/'graphics';OUT.mkdir(exist_ok=True)
FONT=ROOT/'media'/'type'
def font(s,kind='R'):
    return ImageFont.truetype(str(FONT/({'R':'DejaVuSans','B':'DejaVuSans-Bold','M':'DejaVuSansMono','S':'DejaVuSerif'}[kind]+'.ttf')),s)
paper='#eeece4';ink='#202724';red='#ba3f27';dim='#5f6660';rule='#a5aaa0';white='#fffdf5'
if len(sys.argv)>1:
    from reproject import Raster
    tri=np.load(sys.argv[1]).reshape(-1,3,3);tri=tri[np.max(np.abs(tri),axis=(1,2))<4].reshape(-1,3)
    rr=Raster(630,630,tri)
    for n,(x,y,z) in {'front':((1,0,0),(0,0,1),(0,1,0)),'right':((0,-1,0),(0,0,1),(1,0,0)),'back':((-1,0,0),(0,0,1),(0,-1,0)),'plan':((-1,0,0),(0,-1,0),(0,0,-1))}.items():
        mat=np.eye(4,dtype='f4');mat[:3,:3]=np.array([x,y,z])*np.array([.93,.93,.4])[:,None]
        dep=rr.depth(mat)[::-1];mask=dep<.995
        # Discontinuities in depth and surface slope make a compact technical elevation.
        gx=np.gradient(dep,axis=1);gy=np.gradient(dep,axis=0)
        edges=np.maximum(abs(np.gradient(gx,axis=1)),abs(np.gradient(gy,axis=0)))
        alpha=np.uint8(np.clip((edges-.000035)*54000,0,215)+np.where(mask,18,0))
        im=Image.new('RGBA',(630,630),(255,255,255));im.putalpha(Image.fromarray(alpha));im=im.crop(im.getbbox());im.save(OUT/(n+'.png'))
def text(pos,t,size,kind='R',col=ink,anchor=None):d.text(pos,t,font=font(size,kind),fill=col,anchor=anchor,stroke_width=0)
def line(x1,y1,x2,y2,col=rule,w=1):d.line((x1,y1,x2,y2),fill=col,width=w)
def rect(x,y,X,Y,c):d.rectangle((x,y,X,Y),fill=c)
def mark(x,y,k=1,c=red):
    for i in range(3):
        a=x+i*10*k;d.polygon([(a,y+20*k),(a+9*k,y),(a+16*k,y),(a+7*k,y+20*k)],fill=c)
def diagram(name,at,box,c):
    im=Image.open(OUT/(name+'.png'));im.thumbnail(box,Image.Resampling.LANCZOS)
    fil=Image.new('RGBA',im.size,c);fil.putalpha(im.getchannel('A'))
    x,y=at;canvas.alpha_composite(fil,(round(x+(box[0]-im.width)/2),round(y+(box[1]-im.height)/2)))
def bar(x,y,w,active=0,light=False):
    for i in range(5):
        rect(x+i*w/5,y,x+(i+1)*w/5-4,y+3,red if i==active else ('#66716c' if light else '#b8bcb2'))
def stamp(i):
    rect(1014,26,1249,57,(26,34,32,230));rect(1014,26,1020,57,red)
    text((1033,33),f'FR   /   007     PL. 0{i}',13,'M',paper)
def registry(dark=False):
    c=paper if dark else ink
    mark(32,34,.85,'#ed684a' if dark else red);text((75,31),'FIELD REGISTER',19,'B',c)
    line(32,72,319,72,'#63716c' if dark else rule)
    text((32,85),'MECHANICAL COLLECTION',12,'M',c);text((320,85),'Nº 007',12,'M',c,'ra')
def footer(n,title,dark=False):
    c=paper if dark else ink
    line(32,637,319,637,'#596560' if dark else rule)
    text((32,653),'0'+str(n),27,'M',c);text((83,658),title,15,'B',c)
    bar(32,696,291,n-1,dark)
def new():
    global canvas,d
    canvas=Image.new('RGBA',(1280,720));d=ImageDraw.Draw(canvas)
def save(n):canvas.save(OUT/f'plate_{n:02d}.png',optimize=True)
new();rect(0,0,351,720,paper);registry();stamp(1)
text((26,131),'SCV',118,'B');text((32,280),'Recovery walker',30,'S')
rect(33,338,63,342,red);text((75,331),'FIELD UNIT     /     07',14,'M')
line(32,380,319,380);text((32,393),'FIG. A',12,'M',dim);text((319,393),'FRONTAL ELEVATION',12,'M',dim,'ra')
diagram('front',(60,418),(233,174),ink)
line(67,603,284,603,dim);line(67,599,67,607,dim);line(284,599,284,607,dim)
rect(135,594,218,614,paper);text((176,596),'2.00 u',13,'M',dim,'ma')
footer(1,'GENERAL ARRANGEMENT');save(1)

new();stamp(2)
rect(0,540,354,720,'#202825');rect(0,540,8,720,red)
text((31,561),'02     /     OPERATOR STATION',13,'M','#e3baa0')
text((29,592),'Pilot cell',43,'B',white)
line(33,654,317,654,'#596560');text((32,668),'01  Canopy     02  Radiators',15,'M',paper);bar(32,698,290,1,True);save(2)

new();stamp(3)
rect(0,0,371,139,paper);rect(0,0,8,139,red)
text((31,19),'03     /     STARBOARD TOOLING',13,'M',dim)
text((28,44),'Extraction fork',33,'B',ink)
line(32,99,336,99);text((32,109),'THREE-TINE   /   FORGED STEEL',13,'M',dim);save(3)

new();rect(0,0,351,720,'#202825');registry(True);stamp(4)
text((30,135),'Induction',40,'B',paper);text((31,185),'plant',40,'B',paper)
rect(33,260,64,264,'#e96949');text((76,252),'REAR ASSEMBLY',14,'M',paper)
line(32,308,319,308,'#596560');text((32,323),'FIG. B',12,'M','#d1bba9');text((319,323),'REAR ELEVATION',12,'M','#d1bba9','ra')
diagram('back',(48,355),(258,208),'#e9e7dc')
text((32,593),'TWIN IMPELLER HOUSINGS',14,'M',paper);footer(4,'POWER GROUP',True);save(4)

new();rect(0,0,351,720,paper);registry();stamp(5)
text((29,131),'SCV',91,'B');text((32,243),'Material record',28,'S')
line(32,306,319,306);text((32,320),'FINISH SCHEDULE',13,'M',dim)
for i,(code,name,c) in enumerate([('01','Oxide enamel','#a93e2b'),('02','Canopy ochre','#c48d3f'),('03','Milled steel','#808a86')]):
    y=362+i*41;rect(32,y,50,y+18,c);text((65,y-2),code,14,'M',dim);text((105,y-4),name,18,'R',ink)
line(32,502,319,502);diagram('right',(32,519),(111,88),ink);diagram('plan',(178,519),(118,88),ink)
text((86,609),'R. ELEV.',11,'M',dim,'ma');text((239,609),'PLAN',11,'M',dim,'ma');footer(5,'ASSEMBLY COMPLETE');save(5)

# Fast moving physical divider: keyed horizontally in the VSE; alpha elsewhere.
new();d.polygon([(0,0),(422,0),(303,720),(0,720)],fill=ink)
d.polygon([(422,0),(454,0),(335,720),(303,720)],fill=red)
d.polygon([(459,0),(465,0),(346,720),(340,720)],fill=paper)
for i in range(14):line(29,80+i*36,114 if i%3==0 else 65,80+i*36,'#829087')
text((131,298),'FR',99,'B',paper);text((142,423),'SECTOR   /   007',16,'M',paper);canvas.save(OUT/'divider.png')
