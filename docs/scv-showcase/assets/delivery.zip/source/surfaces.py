"""Generate the packed surface maps and stencil sheet (Python 3, Pillow, NumPy)."""
from pathlib import Path
import random, math
import numpy as np
from PIL import Image, ImageDraw, ImageFont, ImageFilter

OUT = Path(__file__).resolve().parents[1] / "media"
OUT.mkdir(exist_ok=True)
rng = np.random.default_rng(32)
rd = random.Random(19)
N = 1024

def noise(n):
    a = rng.random((n, n))
    a = np.pad(a, ((0, 1), (0, 1)), mode='wrap')
    return np.asarray(Image.fromarray((a*255).astype('uint8')).resize(
        ((n+1)*N//n, (n+1)*N//n), Image.Resampling.BICUBIC).crop((0, 0, N, N)))/255

field = noise(8)*.32 + noise(32)*.30 + noise(128)*.24 + noise(512)*.14
chips = np.clip((field-.683)*22, 0, 1)
scr = Image.new('L',(N,N))
d=ImageDraw.Draw(scr)
for k in range(170):
    x,y=rd.randrange(N),rd.randrange(N)
    a=rd.uniform(-math.pi, math.pi)
    for j in range(rd.randrange(1,8)):
        o=rd.uniform(-12,12); p=rd.uniform(-16,16); l=rd.uniform(5,74)
        x1=x+p*math.cos(a)-o*math.sin(a); y1=y+p*math.sin(a)+o*math.cos(a)
        for ox in (-N,0,N):
            for oy in (-N,0,N):
                d.line((x1+ox,y1+oy,x1+ox+l*math.cos(a),y1+oy+l*math.sin(a)),
                       fill=rd.randint(48,227),width=rd.choices([1,2,3],[8,3,1])[0])
scratch=np.array(scr)/255
abrasion=np.maximum(chips,scratch)
grain=rng.normal(0,.037,(N,N))
value=np.clip(.36+field*.83+grain,0,1)
rough=np.clip(.22+field*.65+grain*.6+abrasion*.12,0,1)
Image.fromarray(np.uint8(np.stack((abrasion,value,rough),-1)*255)).save(OUT/'rolled_sheet.png')

W,H=1024,1024
im=Image.new("RGBA",(W,H))
d=ImageDraw.Draw(im)
fdir=OUT/'type'
def font(n,bold=True):
    return ImageFont.truetype(str(fdir/('DejaVuSans-Bold.ttf' if bold else 'DejaVuSansMono.ttf')),n)
ink=(243,229,196,255)
def row(i,large,small,style=0):
    y=128*i
    d.rectangle((14,y+21,23,y+109),fill=ink)
    d.text((42,y+4),large,font=font(78),fill=ink,stroke_width=0)
    d.text((50,y+93),small,font=font(17,False),fill=ink)
    for j in range(26):
        x=745+j*9
        d.rectangle((x,y+18,x+rd.choice([1,2,5]),y+78),fill=ink)
    d.text((744,y+85),'MFG : '+f'0{i+1} / C',font=font(18,False),fill=ink)
row(0,'SCV / 07','RECOVERY DIVISION   //   INDUSTRIAL SERVICE')
row(1,'KEEP CLEAR','PINCH POINT   //   DRIVEN LINKAGE')
row(2,'NO MINING','SERVICE LOCK   //   DISCONNECT BEFORE ACCESS')
row(3,'P - 02','POWER GROUP   //   PRESSURE TESTED')
row(4,'LIFT HERE','SHOULDER CARRIER   //   RATED LIFT EYE')
row(5,'J - 04','SERVO GROUP   //   RETURN CIRCUIT')
row(6,'Bobby-Jo','FIELD UNIT   //   0007')
y=896
for i in range(10):
    x=i*103;d.polygon([(x,y+114),(x+60,y+12),(x+97,y+12),(x+36,y+114)],fill=ink)
a=np.asarray(im).copy()
a[:,:,3]=np.uint8(a[:,:,3]*(1-np.clip((field-.59)*12,0,.99))*(1-scratch*.93))
Image.fromarray(a).save(OUT/'service_stencils.png')

ins=Image.new('L',(512,512));pen=ImageDraw.Draw(ins)
pen.ellipse((108,124,404,426),outline=255,width=11)
pen.polygon([(256,361),(237,324),(208,305),(164,246),(151,218),(208,239),(250,281),
             (268,245),(300,218),(359,193),(342,233),(304,291),(282,312)],fill=255)
def worn(im):
    pat=np.asarray(im).copy()*(1-scratch[::2,::2]*.91)*(1-np.clip((field[::2,::2]-.62)*11,0,1))
    return Image.fromarray(np.uint8(pat))
worn(ins).save(OUT/'pennant_mark.png')
ins=Image.new('L',(512,512));pen=ImageDraw.Draw(ins)
pen.polygon([(255+(155 if i%2==0 else 65)*cos,235-(191 if i%2==0 else 80)*sin)
             for i in range(10) for cos,sin in [(math.cos(math.pi/2+i*math.pi/5),math.sin(math.pi/2+i*math.pi/5))]],fill=255)
worn(ins).save(OUT/'canopy_mark.png')
