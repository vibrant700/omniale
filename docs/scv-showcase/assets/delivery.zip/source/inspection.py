"""Six canonical proof renders: blender -b asset.blend -P inspection.py -- CACHE"""
import bpy,sys
from pathlib import Path
from mathutils import Vector as V,Matrix
out=Path(sys.argv[sys.argv.index('--')+1]).resolve();out.mkdir(exist_ok=True,parents=True)
s=bpy.context.scene;s.render.engine='CYCLES';s.cycles.samples=10;s.cycles.use_denoising=True;s.cycles.max_bounces=3;s.render.use_persistent_data=True
s.render.resolution_x=s.render.resolution_y=576;s.render.resolution_percentage=100
s.render.film_transparent=True;s.render.image_settings.file_format='PNG';s.render.image_settings.color_mode='RGBA'
s.world.use_nodes=True;s.world.node_tree.nodes['Background'].inputs[0].default_value=(.16,.18,.22,1);s.world.node_tree.nodes['Background'].inputs[1].default_value=.65
for i,(p,pow) in enumerate([((-4,-6,7),1400),((5,-3,4),1000),((1,5,6),1600),((0,0,-5),600)]):
    d=bpy.data.lights.new('Softbox '+str(i+1),'AREA');d.energy=pow;d.shape='DISK';d.size=4
    o=bpy.data.objects.new(d.name,d);s.collection.objects.link(o);o.location=p;o.rotation_euler=(-V(p)).to_track_quat('-Z','Y').to_euler()
d=bpy.data.cameras.new('Inspection lens');d.type='ORTHO';d.ortho_scale=2.32
c=bpy.data.objects.new('Orthographic inspection',d);s.collection.objects.link(c);s.camera=c
for name,pos,up in [('front',(0,-8,0),(0,0,1)),('back',(0,8,0),(0,0,1)),('left',(8,0,0),(0,0,1)),('right',(-8,0,0),(0,0,1)),('top',(0,0,8),(0,-1,0)),('bottom',(0,0,-8),(0,-1,0))]:
    z=V(pos).normalized();y=V(up);x=y.cross(z);c.matrix_world=Matrix((x,y,z)).transposed().to_4x4();c.location=pos
    s.render.filepath=str(out/(name+'.png'));bpy.ops.render.render(write_still=True)
