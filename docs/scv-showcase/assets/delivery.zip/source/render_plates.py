"""Render Cycles lighting plates and export evaluated geometry for temporal reuse.
Blender -b stage.blend -P render_plates.py -- /path/to/cache [stride]
Set stride to 1 for ordinary, fully path-traced footage at every frame.
"""
import bpy, numpy as np, sys, json
from pathlib import Path
args=sys.argv[sys.argv.index('--')+1:]
out=Path(args[0]).resolve();out.mkdir(parents=True,exist_ok=True)
stride=int(args[1]) if len(args)>1 else 1
s=bpy.context.scene;W=s.render.resolution_x;H=s.render.resolution_y
s.render.resolution_percentage=100
shots=[(m.frame,m.name) for m in sorted(s.timeline_markers,key=lambda m:m.frame) if m.camera]
g=bpy.context.evaluated_depsgraph_get()
tri=[]
for oi in g.object_instances:
    o=oi.object
    if o.type not in ('MESH','CURVE','SURFACE','FONT'):continue
    me=o.to_mesh();me.calc_loop_triangles()
    vt=np.empty(3*len(me.vertices),'f4');me.vertices.foreach_get('co',vt)
    fs=np.empty(3*len(me.loop_triangles),'i4');me.loop_triangles.foreach_get('vertices',fs)
    mat=np.array(oi.matrix_world);pts=vt.reshape(-1,3)@mat[:3,:3].T+mat[:3,3]
    tri.append(pts[fs]);o.to_mesh_clear()
np.save(out/'triangles.npy',np.concatenate(tri).astype('f4'))
mats=[]
for fr in range(s.frame_start,s.frame_end+1):
    s.frame_set(fr);cam=s.camera.evaluated_get(g)
    mat=cam.calc_matrix_camera(g,x=W,y=H)@cam.matrix_world.inverted()
    mats.append(np.array(mat,'f4'))
np.save(out/'projections.npy',np.stack(mats))
anchors=[];segments=[]
for i,(f,n) in enumerate(shots):
    e=shots[i+1][0]-1 if i+1<len(shots) else s.frame_end
    a=sorted(set(range(f,e+1,stride))|{e});anchors+=a;segments.append(a)
(out/'manifest.json').write_text(json.dumps({'width':W,'height':H,'fps':s.render.fps,'segments':segments}))
for fr in anchors:
    p=out/f'plate_{fr:04d}.png'
    if p.is_file():continue
    s.frame_set(fr);s.render.filepath=str(p);bpy.ops.render.render(write_still=True)
