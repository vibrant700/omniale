"""Render the VSE master with audio; optionally rebuild the clean 3D picture first."""
import argparse,json,subprocess,tempfile,shutil
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
p=argparse.ArgumentParser(description=__doc__)
p.add_argument('--refresh',action='store_true',help='Re-render every 3D frame from stage.blend and replace the lighting cache first.')
p.add_argument('--output',type=Path,default=ROOT/'exports'/'field_register_007.mp4')
p.add_argument('--work',type=Path,help='Parent directory for temporary renders (several GB recommended for --refresh).')
p.add_argument('--blender',default='blender');p.add_argument('--ffmpeg',default='ffmpeg')
p.add_argument('--threads',type=int,default=0,help='Blender CPU threads; 0 = automatic')
args=p.parse_args();run=lambda cmd:subprocess.run([str(x) for x in cmd],check=True)
if args.work:args.work.mkdir(parents=True,exist_ok=True)
with tempfile.TemporaryDirectory(prefix='scv_export_',dir=args.work) as td:
    td=Path(td).resolve()
    if args.refresh:
        seq=td/'plates';seq.mkdir()
        import_repr=repr(str(td/'range.json'))
        expression=("import bpy,json; s=bpy.context.scene;"
                    f"open({import_repr},'w').write(json.dumps([s.frame_start,s.render.fps/s.render.fps_base]))")
        run([args.blender,'-b',ROOT/'stage.blend','-t',args.threads,'--python-exit-code',1,'--python-expr',expression,
             '-o',seq/'plate_####','-F','PNG','-a'])
        start,fps=json.loads((td/'range.json').read_text())
        run([args.ffmpeg,'-v','error','-y','-framerate',fps,'-start_number',start,'-i',seq/'plate_%04d.png','-an','-c:v','libx264','-crf',13,'-preset','medium','-vf','scale=out_color_matrix=bt709','-pix_fmt','yuv420p','-colorspace','bt709','-color_primaries','bt709','-color_trc','bt709','-movflags','+faststart',td/'lighting.mp4'])
        shutil.copyfile(td/'lighting.mp4',ROOT/'media'/'lighting.mp4')
    movie=td/'output';movie.mkdir()
    run([args.blender,'-b',ROOT/'edit.blend','-t',args.threads,'--python-exit-code',1,'-o',movie/'field_register.mp4','-a'])
    files=list(movie.glob('*.mp4'))
    if len(files)!=1:raise RuntimeError(f'Expected one movie, found {files}')
    args.output.parent.mkdir(parents=True,exist_ok=True)
    run([args.ffmpeg,'-v','error','-y','-i',files[0],'-map','0:v:0','-map','0:a:0','-c','copy','-movflags','+faststart',args.output.resolve()])
