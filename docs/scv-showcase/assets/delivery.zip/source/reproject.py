"""Optional Linux/EGL plate cache builder. Rasterizes the real evaluated geometry
at every camera sample, reusing adjacent Cycles illumination in world space.
Usage: python reproject.py CACHE FOOTAGE.mp4 [last_frame]
The Blender edit also has a live, entirely native scene-strip render path.
"""
import os,sys,json,ctypes as ct,subprocess,time,argparse
from pathlib import Path
import numpy as np
from PIL import Image
os.environ.setdefault('EGL_PLATFORM','surfaceless')
os.environ.setdefault('LP_NUM_THREADS','3')
P=ct.c_void_p;I=ct.c_int;U=ct.c_uint;F=ct.c_float;B=ct.c_ubyte
def api(lib,name,ret,*args):
    f=getattr(lib,name);f.restype=ret;f.argtypes=args;return f
class Raster:
    def __init__(self,W,H,tri):
        self.W,self.H=W,H
        e=ct.CDLL('libEGL.so.1');self.g=g=ct.CDLL('libGL.so.1')
        d=api(e,'eglGetDisplay',P,P)(None)
        assert api(e,'eglInitialize',U,P,P,P)(d,None,None)
        assert api(e,'eglBindAPI',U,U)(0x30a2)
        def attrs(a):return (I*(len(a)+1))(*a,0x3038)
        cfg=P();n=I()
        assert api(e,'eglChooseConfig',U,P,P,P,I,P)(d,attrs([0x3033,1,0x3040,8,0x3024,8,0x3023,8,0x3022,8,0x3025,24]),ct.byref(cfg),1,ct.byref(n)) and n.value
        surf=api(e,'eglCreatePbufferSurface',P,P,P,P)(d,cfg,attrs([0x3057,W,0x3056,H]))
        cx=api(e,'eglCreateContext',P,P,P,P,P)(d,cfg,None,attrs([]))
        assert api(e,'eglMakeCurrent',U,P,P,P,P)(d,surf,surf,cx)
        for name,res,args in [
          ('glViewport',None,[I,I,I,I]),('glClear',None,[U]),('glEnable',None,[U]),('glDisable',None,[U]),
          ('glEnableClientState',None,[U]),('glVertexPointer',None,[I,U,I,P]),('glDrawArrays',None,[U,I,I]),
          ('glMatrixMode',None,[U]),('glLoadMatrixf',None,[P]),('glReadPixels',None,[I,I,I,I,U,U,P]),
          ('glPixelStorei',None,[U,I]),('glCreateShader',U,[U]),('glShaderSource',None,[U,I,P,P]),('glCompileShader',None,[U]),
          ('glCreateProgram',U,[]),('glAttachShader',None,[U,U]),('glLinkProgram',None,[U]),('glUseProgram',None,[U]),
          ('glGetUniformLocation',I,[U,ct.c_char_p]),('glUniformMatrix4fv',None,[I,I,B,P]),
          ('glUniform1i',None,[I,I]),('glUniform1f',None,[I,F]),('glActiveTexture',None,[U]),('glBindTexture',None,[U,U]),
          ('glTexParameteri',None,[U,U,I]),('glTexImage2D',None,[U,I,I,I,I,I,U,U,P]),('glGenTextures',None,[I,P]),
          ('glGetShaderiv',None,[U,U,P]),('glGetShaderInfoLog',None,[U,I,P,P])]:
            setattr(self,name,api(g,name,res,*args))
        self.tri=np.ascontiguousarray(tri,'f4');self.glEnableClientState(0x8074);self.glVertexPointer(3,0x1406,0,self.tri.ctypes.data)
        self.glViewport(0,0,W,H);self.glEnable(0x0B71);self.glDisable(0x0BD0);self.glPixelStorei(0x0D05,1);self.glPixelStorei(0x0CF5,1)
        self.glMatrixMode(0x1701)
        vs=b"""#version 120
        uniform mat4 A,B;varying vec4 qa,qb;
        void main(){gl_Position=gl_ProjectionMatrix*gl_Vertex;qa=A*gl_Vertex;qb=B*gl_Vertex;}"""
        fs=b"""#version 120
        varying vec4 qa,qb;uniform sampler2D ca,cb,da,db;uniform float mixTime;
        float visible(vec3 p,sampler2D depth){
          float inside=step(.001,p.x)*step(p.x,.999)*step(.001,p.y)*step(p.y,.999);
          float z=texture2D(depth,p.xy).r;
          return inside*(1.-smoothstep(.00007,.00065,p.z-z));}
        void main(){vec3 a=qa.xyz/qa.w*.5+.5,b=qb.xyz/qb.w*.5+.5;
          float va=visible(a,da), vb=visible(b,db);
          float wa=(1.-mixTime)*va,wb=mixTime*vb;
          float t=(wa+wb>.001)?wb/(wa+wb):mixTime;
          gl_FragColor=mix(texture2D(ca,a.xy),texture2D(cb,b.xy),t);}"""
        prog=self.glCreateProgram()
        for ty,src in [(0x8b31,vs),(0x8b30,fs)]:
            sh=self.glCreateShader(ty);sp=ct.c_char_p(src);self.glShaderSource(sh,1,ct.byref(sp),None);self.glCompileShader(sh);status=I();self.glGetShaderiv(sh,0x8b81,ct.byref(status))
            if not status.value:
                msg=ct.create_string_buffer(4096);self.glGetShaderInfoLog(sh,4096,None,msg);raise RuntimeError(msg.value)
            self.glAttachShader(prog,sh)
        self.glLinkProgram(prog);self.prog=prog
        self.uniform={k:self.glGetUniformLocation(prog,k.encode()) for k in ['A','B','ca','cb','da','db','mixTime']}
        self.textures=(U*4)();self.glGenTextures(4,self.textures)
    def draw(self,mat):
        self.glLoadMatrixf(np.ascontiguousarray(mat.T,'f4').ctypes.data);self.glClear(0x4100);self.glDrawArrays(4,0,len(self.tri))
    def depth(self,mat):
        self.glUseProgram(0);self.draw(mat);a=np.empty((self.H,self.W),'f4');self.glReadPixels(0,0,self.W,self.H,0x1902,0x1406,a.ctypes.data);return a
    def segment(self,a,b,ca,cb):
        da=self.depth(a);db=self.depth(b)
        self.glUseProgram(self.prog)
        for key,m in [('A',a),('B',b)]:self.glUniformMatrix4fv(self.uniform[key],1,0,np.ascontiguousarray(m.T,'f4').ctypes.data)
        for i,(key,ar) in enumerate(zip(['ca','cb','da','db'],[ca,cb,da,db])):
            self.glActiveTexture(0x84c0+i);self.glBindTexture(0xde1,self.textures[i]);flt=0x2601 if i<2 else 0x2600
            for p,v in [(0x2801,flt),(0x2800,flt),(0x2802,0x812f),(0x2803,0x812f)]:self.glTexParameteri(0xde1,p,v)
            tex=np.ascontiguousarray(ar[::-1] if i<2 else ar)
            self.glTexImage2D(0xde1,0,0x8051 if i<2 else 0x822E,self.W,self.H,0,0x1907 if i<2 else 0x1903,0x1401 if i<2 else 0x1406,tex.ctypes.data)
            self.glUniform1i(self.uniform[key],i)
    def frame(self,m,t):
        self.glUniform1f(self.uniform['mixTime'],t);self.draw(m)
        a=np.empty((self.H,self.W,3),'u1');self.glReadPixels(0,0,self.W,self.H,0x1907,0x1401,a.ctypes.data)
        return a[::-1]
if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('cache',type=Path);parser.add_argument('dest',type=Path)
    parser.add_argument('last_frame',nargs='?',type=int,default=10**6)
    parser.add_argument('--follow',action='store_true',help='Wait for each lighting plate while Blender renders it.')
    args=parser.parse_args()
    cache=args.cache;mf=json.loads((cache/'manifest.json').read_text());W,H=mf['width'],mf['height']
    r=Raster(W,H,np.load(cache/'triangles.npy'));m=np.load(cache/'projections.npy')
    dest=args.dest;dest.parent.mkdir(parents=True,exist_ok=True)
    ff=subprocess.Popen(['ffmpeg','-v','error','-y','-f','rawvideo','-pix_fmt','rgb24','-s',f'{W}x{H}','-r',str(mf['fps']),'-i','-','-an','-c:v','libx264','-preset','fast','-crf','13','-threads','3','-pix_fmt','yuv420p','-colorspace','bt709','-color_primaries','bt709','-color_trc','bt709','-vf','scale=out_color_matrix=bt709','-movflags','+faststart',str(dest)],stdin=subprocess.PIPE)
    def read(k):
        path=cache/f'plate_{k:04d}.png'
        while True:
            try:
                if args.follow:
                    with path.open('rb') as test:
                        test.seek(-12,2)
                        if test.read()!=b'\0\0\0\0IEND\xaeB`\x82':raise OSError('Plate is still being written')
                with Image.open(path) as im:return np.asarray(im.convert('RGB'))
            except (OSError,SyntaxError):
                if not args.follow:raise
                time.sleep(1)
    maxframe=args.last_frame
    for arr in mf['segments']:
        if arr[0]>maxframe:break
        for a,b in zip(arr,arr[1:]):
            if a>maxframe:break
            ca=read(a);cb=read(b);r.segment(m[a-1],m[b-1],ca,cb)
            for f in range(a,min(b,maxframe+1)):
                ff.stdin.write((ca if f==a else r.frame(m[f-1],(f-a)/(b-a))).tobytes())
        if arr[-1]<=maxframe:ff.stdin.write(read(arr[-1]).tobytes())
    ff.stdin.close()
    if ff.wait():raise RuntimeError('Footage encoding failed')
