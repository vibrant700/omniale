"""Lay out the orthographic proofs: python contact_sheet.py CACHE OUTPUT.png"""
import sys
from pathlib import Path
from PIL import Image,ImageDraw,ImageFont
root=Path(__file__).resolve().parents[1];p=Path(sys.argv[1])
im=Image.new('RGB',(1800,1360),'#eae9e0');d=ImageDraw.Draw(im)
def f(n,k):return ImageFont.truetype(str(root/'media'/'type'/('DejaVu'+k+'.ttf')),n)
def text(pos,t,n,k='SansMono',c='#222925'):d.text(pos,t,font=f(n,k),fill=c)
text((50,35),'SCV',83,'Sans-Bold')
text((279,62),'Orthographic record',43,'Serif')
text((1410,40),'FIELD REGISTER  /  007',21)
text((1410,81),'ASSEMBLY INSPECTION',19,c='#606b61')
d.line((52,159,1748,159),fill='#434d46',width=2)
for i,(n,title,axis) in enumerate([('front','FRONT','-Y'),('left','PORT','+X'),('top','PLAN','+Z'),('back','REAR','+Y'),('right','STARBOARD','-X'),('bottom','UNDERSIDE','-Z')]):
    x=52+(i%3)*577;y=196+(i//3)*531
    text((x,y),f'0{i+1}',22,'SansMono','#b83d27');text((x+55,y),title,22,'Sans-Bold');text((x+455,y),axis,22)
    a=Image.open(p/(n+'.png')).convert('RGBA');a.thumbnail((500,500),Image.Resampling.LANCZOS)
    im.paste(a,(x+12,y+25),a);d.line((x,y+508,x+532,y+508),fill='#a1a89c')
d.line((52,1270,1748,1270),fill='#434d46',width=2)
text((52,1293),'SCV  /  GENERAL ARRANGEMENT',19,'Sans-Bold');text((750,1293),'NORMALIZED ENVELOPE   2.000 × 1.841 × 1.643 u',18);text((1599,1293),'FIG. A—F',19)
im.save(sys.argv[2],optimize=True)
