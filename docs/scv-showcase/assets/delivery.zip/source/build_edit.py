"""Assemble native Blender VSE edit. Optional -- alternate_footage alternate_blend."""
import bpy,sys,os
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];MEDIA=ROOT/'media'
args=sys.argv[sys.argv.index('--')+1:] if '--' in sys.argv else []
foot=Path(args[0]).resolve() if args else MEDIA/'lighting.mp4'
dest=Path(args[1]).resolve() if len(args)>1 else ROOT/'edit.blend'
bpy.ops.wm.read_factory_settings(use_empty=True)
bpy.context.preferences.filepaths.save_version=0
s=bpy.context.scene;s.name='MASTER | Field Register 007'
with bpy.data.libraries.load(str(ROOT/'stage.blend'),link=True) as (src,dst):
    dst.scenes=[src.scenes[0]]
stage=dst.scenes[0]
r=s.render;r.resolution_x=1280;r.resolution_y=720;r.resolution_percentage=100;r.fps=24
s.frame_start=1;s.frame_end=438;s.view_settings.view_transform='Standard';s.view_settings.look='None'
r.image_settings.media_type='VIDEO';r.image_settings.file_format='FFMPEG';r.ffmpeg.format='MPEG4';r.ffmpeg.codec='H264';r.ffmpeg.constant_rate_factor='HIGH';r.ffmpeg.ffmpeg_preset='GOOD'
r.ffmpeg.audio_codec='AAC';r.ffmpeg.audio_bitrate=256;r.ffmpeg.audio_mixrate=48000;r.ffmpeg.audio_channels='STEREO'
r.filepath='//exports/field_register_007.mp4'
ed=s.sequence_editor_create();st=ed.strips
live=st.new_scene('LIVE | linked stage (enable for camera revisions)',stage,1,1);live.mute=True
clip=st.new_movie('CACHE | approved lighting (mute for live stage)',str(foot),2,1);clip.right_handle=439
def still(name,path,ch,a,b):
    q=st.new_image(name,str(path),ch,a);q.right_handle=b+1;q.blend_type='ALPHA_OVER';return q
def key(o,prop,fr,v):
    setattr(o,prop,v);o.keyframe_insert(data_path=prop,frame=fr)
parts=[(1,96,'General arrangement'),(97,168,'Pilot cell'),(169,240,'Extraction fork'),(241,330,'Induction plant'),(331,438,'Material record')]
for i,(a,b,name) in enumerate(parts,1):
    still('PL. %02d | '%i+name,MEDIA/'graphics'/f'plate_{i:02d}.png',3,a,b)
    s.timeline_markers.new(f'{i:02d} / '+name,frame=a)
for center in [97,241]:
    q=still('WIPE | register divider',MEDIA/'graphics'/'divider.png',4,center-5,center+5)
    key(q.transform,'offset_x',center-5,-470);key(q.transform,'offset_x',center+5,1290)
black=st.new_effect('OUT | tail to black','COLOR',5,426,length=13);black.color=(.011,.014,.013);black.blend_type='ALPHA_OVER'
key(black,'blend_alpha',426,0);key(black,'blend_alpha',436,1)
def snd(name,file,ch,fr,vol):
    q=st.new_sound(name,str(MEDIA/(file+'.wav')),ch,fr);q.volume=vol;q.show_waveform=True;return q
music=snd('MUSIC | Industrial Pulse • excerpt 04:00','industrial_pulse',6,-95,.59);music.left_handle=1;music.right_handle=439
env=[(1,.47),(6,.60),(82,.60),(95,.43),(108,.60),(156,.60),(168,.44),(178,.60),(226,.60),(240,.42),(252,.60),(312,.60),(327,.41),(343,.56),(405,.56),(423,.40),(438,.0)]
for fr,v in env:key(music,'volume',fr,v)
snd('SFX | entry impact','hit',7,1,.22)
snd('SFX | canopy pass','whoosh',7,81,.43)
snd('SFX | tool detent','hit',7,168,.52)
snd('SFX | flyback','whoosh',7,225,.44)
snd('SFX | final downshift','drop',8,326,.52)
snd('SFX | final latch','hit',7,330,.28)
for i,n in enumerate(['Live 3D','Lighting cache','Register plates','Transitions','Picture out','Score','Mechanical cues','Downshift'],1):
    ed.channels[i].name=n
for q in st:
    q.select=False;q.color_tag={'SCENE':'COLOR_06','MOVIE':'COLOR_05','SOUND':'COLOR_04','IMAGE':'COLOR_02','COLOR':'COLOR_09'}.get(q.type,'NONE')
ed.active_strip=music
for sc in bpy.data.screens:
    if sc.name=='Layout':
        for a in sc.areas:
            if a.type=='VIEW_3D':
                a.type='SEQUENCE_EDITOR';a.spaces.active.view_type='SEQUENCER_PREVIEW';a.spaces.active.show_region_ui=False
s['Re-render']='For camera changes: edit stage.blend, reopen this file, mute CACHE on CH2 and unmute LIVE on CH1. Render Animation.'
s['Timebase']='24 fps; 438 frames; 18.25 s. Music starts at source 4.00 s.'
s.frame_set(1)
# Store portable paths even when building a test edit in another directory.
rel=lambda path:'//'+os.path.relpath(path,dest.parent).replace(os.sep,'/')
for q in st:
    if q.type=='MOVIE':q.filepath=rel(foot)
    elif q.type=='SOUND':q.sound.filepath=rel(MEDIA/Path(q.sound.filepath).name)
    elif q.type=='IMAGE':q.directory=rel(MEDIA/'graphics')+'/'
for lib in bpy.data.libraries:
    if lib.parent is None:lib.filepath=rel(ROOT/'stage.blend')
bpy.ops.wm.save_as_mainfile(filepath=str(dest),relative_remap=False,compress=True)
