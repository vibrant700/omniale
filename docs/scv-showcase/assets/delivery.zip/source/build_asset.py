"""SCV / FIELD UNIT 07. Run with Blender 5.3 -b -P build_asset.py."""
import bpy, math, random, os
from pathlib import Path
from mathutils import Vector as V, Matrix, Euler
from math import sin, cos, pi
ROOT=Path(__file__).resolve().parents[1]
bpy.ops.wm.read_factory_settings(use_empty=True)
sc=bpy.context.scene
sc.name="SCV  |  component library"
bpy.context.preferences.filepaths.save_version=0
random.seed(7)
master=bpy.data.collections.new("SCV  •  FIELD UNIT 07")
sc.collection.children.link(master)
master.asset_mark()
master.asset_data.description="Industrial recovery chassis. +Z up; forward -Y; port +X."
master.asset_data.author="SCV reconstruction | reference design: JohnMesplay (CC BY 4.0)"
for tag in ['SCV','Industrial','Walker','Hard surface']:master.asset_data.tags.new(tag)
col=master
def group(name):
    global col
    col=bpy.data.collections.new(name);master.children.link(col)
def obj(name,data):
    o=bpy.data.objects.new(name,data);col.objects.link(o);return o
def img(f,noncolor=False):
    im=bpy.data.images.load(str(ROOT/'media'/f));im.pack()
    im.filepath='//media/'+f
    if noncolor:im.colorspace_settings.name='Non-Color'
    return im
sheet=img('rolled_sheet.png',True);sheet.name="Rolled sheet | abrasion • value • roughness"
atlas=img('service_stencils.png')
M={}
def material(key,name,color,metal=.0,rough=.5,wear=0,emit=0):
    m=bpy.data.materials.new(name);m.diffuse_color=(*color,1);m.use_nodes=True;M[key]=m
    nd=m.node_tree.nodes; lk=m.node_tree.links.new; bs=nd.get('Principled BSDF')
    bs.inputs['Base Color'].default_value=(*color,1);bs.inputs['Metallic'].default_value=metal;bs.inputs['Roughness'].default_value=rough
    if emit:
        bs.inputs['Emission Color'].default_value=(*color,1);bs.inputs['Emission Strength'].default_value=emit
    if wear:
        tc=nd.new('ShaderNodeTexCoord');tc.location=(-1040,100)
        vm=nd.new('ShaderNodeVectorMath');vm.operation='SCALE';vm.inputs[3].default_value=2.9;vm.location=(-850,100);lk(tc.outputs['Object'],vm.inputs[0])
        im=nd.new('ShaderNodeTexImage');im.image=sheet;im.projection='BOX';im.projection_blend=.15;im.location=(-650,100);lk(vm.outputs[0],im.inputs[0])
        ch=nd.new('ShaderNodeSeparateColor');ch.location=(-400,110);lk(im.outputs[0],ch.inputs[0])
        mix=nd.new('ShaderNodeMixRGB');mix.location=(-110,290);mix.inputs[1].default_value=(*color,1);mix.inputs[2].default_value=(.28,.235,.20,1) if wear==1 else (.38,.4,.41,1);lk(ch.outputs[0],mix.inputs[0])
        val=nd.new('ShaderNodeMixRGB');val.location=(95,270);val.blend_type='MULTIPLY';val.inputs[0].default_value=.85;lk(mix.outputs[0],val.inputs[1]);lk(ch.outputs[1],val.inputs[2]);lk(val.outputs[0],bs.inputs['Base Color'])
        ramp=nd.new('ShaderNodeMapRange');ramp.location=(-90,-55);ramp.inputs['To Min'].default_value=rough-.13;ramp.inputs['To Max'].default_value=rough+.16;lk(ch.outputs[2],ramp.inputs[0]);lk(ramp.outputs[0],bs.inputs['Roughness'])
        bump=nd.new('ShaderNodeBump');bump.location=(100,-110);bump.inputs['Strength'].default_value=.16;bump.inputs['Distance'].default_value=.00065;lk(ch.outputs[1],bump.inputs['Height']);lk(bump.outputs[0],bs.inputs['Normal'])
        bs.location=(330,240);nd.get('Material Output').location=(650,240)
    return m
material('red','01 / Oxide vermilion · chipped enamel',(.46,.041,.025),.46,.39,1)
material('wine','02 / Red oxide · undercoat',(.17,.021,.013),.62,.48,1)
material('gold','03 / Ochre · canopy enamel',(.88,.35,.048),.36,.37,1)
material('steel','04 / Milled nickel · tool faces',(.32,.36,.37),.88,.31,2)
material('edge','05 / Polished cut edge',(.56,.59,.58),.93,.235)
material('gun','06 / Blued steel · frame',(.073,.084,.091),.82,.39,2)
material('black','07 / Carbon elastomer',(.015,.020,.022),.06,.57)
material('iron','08 / Cast iron · recess',(.033,.039,.038),.67,.48)
material('brass','09 / Oiled bronze',(.31,.164,.055),.78,.32,1)
material('seat','10 / Oxblood upholstery',(.085,.024,.014),.08,.61)
material('canvas','11 / Graphite canvas',(.051,.049,.042),.03,.89)
material('ivory','12 / Pale stencil',(.80,.75,.61),.25,.45)
material('amber','13 / Amber pilot lamp',(1,.32,.018),.22,.27,2 if False else 0,1.6)
material('teal','14 / Instrument phosphor',(.048,.67,.55),.2,.26,0,1.4)
material('glass','15 / Smoked gauge lens',(.019,.056,.055),.57,.15)
def surface_mark(o,coords,filename,color):
    uv=o.data.uv_layers.new(name='Printed finish')
    for lp in o.data.loops:uv.data[lp.index].uv=coords[lp.vertex_index]
    base=o.data.materials[0].copy();o.data.materials[0]=base;base.name+=' / marked'
    nd=base.node_tree.nodes;link=base.node_tree.links.new;bs=nd.get('Principled BSDF')
    im=nd.new('ShaderNodeTexImage');im.image=img(filename,True);im.location=(-290,610)
    mix=nd.new('ShaderNodeMixRGB');mix.inputs[2].default_value=(*color,1);mix.location=(80,520)
    src=bs.inputs['Base Color']
    if src.is_linked:link(src.links[0].from_socket,mix.inputs[1])
    else:mix.inputs[1].default_value=src.default_value
    link(im.outputs['Color'],mix.inputs[0]);link(mix.outputs[0],src)
m=material('decal','16 / Screen-printed service graphics',(1,1,1),.13,.51)
nd=m.node_tree.nodes;lk=m.node_tree.links.new;im=nd.new('ShaderNodeTexImage');im.image=atlas;bs=nd.get('Principled BSDF');lk(im.outputs['Color'],bs.inputs['Base Color']);lk(im.outputs['Alpha'],bs.inputs['Alpha'])
def mesh(name,vs,fs,mat,bevel=0,smooth=False,edge=True):
    me=bpy.data.meshes.new(name);me.from_pydata(vs,[],fs);me.materials.append(M[mat]);me.update()
    o=obj(name,me)
    if smooth:
        for p in me.polygons:p.use_smooth=True
    if bevel:
        b=o.modifiers.new("Rolled corners","BEVEL");b.width=bevel;b.segments=2;b.affect='EDGES'
        if edge and mat in ('red','wine','gold','gun','steel'):
            me.materials.append(M['steel'] if mat in ('red','wine','gold') else M['edge']);b.material=1
        w=o.modifiers.new("Machined normals",'WEIGHTED_NORMAL');w.keep_sharp=True
    return o
def box(name,p,d,mat='red',b=.006,rot=None):
    x,y,z=[v*.5 for v in d]
    vs=[(-x,-y,-z),(x,-y,-z),(x,y,-z),(-x,y,-z),(-x,-y,z),(x,-y,z),(x,y,z),(-x,y,z)]
    o=mesh(name,vs,[(3,2,1,0),(4,5,6,7),(0,1,5,4),(1,2,6,5),(2,3,7,6),(3,0,4,7)],mat,b)
    o.location=p
    if rot:o.rotation_euler=rot
    return o
def cylinder(name,a,b,r,mat='gun',r2=None,n=32,bev=.0018,cap=True):
    a,b=V(a),V(b);D=b-a;h=D.length/2
    vs=[(rad*cos(t*2*pi/n),rad*sin(t*2*pi/n),zz) for rad,zz in [(r,-h),(r if r2 is None else r2,h)] for t in range(n)]
    fs=[(i,(i+1)%n,(i+1)%n+n,i+n) for i in range(n)]
    if cap:fs+=[tuple(reversed(range(n))),tuple(range(n,2*n))]
    o=mesh(name,vs,fs,mat,bev)
    for p in o.data.polygons[:n]:p.use_smooth=n>10
    o.location=(a+b)*.5;o.rotation_euler=D.to_track_quat('Z','Y').to_euler();return o
def seg(name,a,b,r,mat='gun',**kw):return cylinder(name,a,b,r,mat,**kw)
def disc(name,c,axis,r,depth,mat,n=40):
    c=V(c);v=V(axis).normalized()*depth/2;return seg(name,c-v,c+v,r,mat,n=n)
def bolt(c,axis,r=.009):
    c=V(c);v=V(axis).normalized();disc("Fastener / washer",c,v,r*1.35,.003,'gun',20);disc("Fastener / hex",c+v*.0035,v,r,.006,'edge',6)
def beam(name,a,b,w,h,mat='gun',bevel=.004):
    a,b=V(a),V(b);o=box(name,(a+b)*.5,(w,h,(b-a).length),mat,bevel);o.rotation_euler=(b-a).to_track_quat('Z','Y').to_euler();return o
def tube(name,pts,r,mat='black',soft=True):
    cu=bpy.data.curves.new(name,'CURVE');cu.dimensions='3D';cu.resolution_u=10;cu.bevel_depth=r;cu.bevel_resolution=2;cu.use_fill_caps=True
    if soft:
        s=cu.splines.new('BEZIER');s.bezier_points.add(len(pts)-1)
        for p,pt in zip(s.bezier_points,pts):p.co=pt;p.handle_left_type='AUTO';p.handle_right_type='AUTO'
    else:
        s=cu.splines.new('POLY');s.points.add(len(pts)-1)
        for p,pt in zip(s.points,pts):p.co=(*pt,1)
    o=obj(name,cu);cu.materials.append(M[mat]);return o
def profile(name,points,x,w,mat='red',bev=.005,tilt=0):
    # Extruded side elevation. Shift X with height for the canted shoulder carriers.
    n=len(points);vs=[(x+s*w/2+tilt*z,y,z) for s in [-1,1] for y,z in points]
    fs=[tuple(reversed(range(n))),tuple(range(n,2*n))]+[(i,(i+1)%n,(i+1)%n+n,i+n) for i in range(n)]
    return mesh(name,vs,fs,mat,bev)
def rings(name,stations,mat='red',bev=.003):
    n=len(stations[0]);vs=[p for st in stations for p in st]
    fs=[tuple(reversed(range(n))),tuple(range(len(vs)-n,len(vs)))]+[(j*n+i,j*n+(i+1)%n,(j+1)*n+(i+1)%n,(j+1)*n+i) for j in range(len(stations)-1) for i in range(n)]
    return mesh(name,vs,fs,mat,bev)
def chamfer(x,y,z,w,d,ch=.02):
    a=w/2;b=d/2;c=min(ch,a*.7,b*.7)
    return [(x+X,y+Y,z) for X,Y in [(-a+c,-b),(a-c,-b),(a,-b+c),(a,b-c),(a-c,b),(-a+c,b),(-a,b-c),(-a,-b+c)]]
def decal(name,c,U,W,row):
    c,U,W=V(c),V(U),V(W);o=mesh(name,[c-U/2-W/2,c+U/2-W/2,c+U/2+W/2,c-U/2+W/2],[(0,1,2,3)],'decal');uv=o.data.uv_layers.new()
    lo=1-(row+1)/8;hi=1-row/8
    for lp,xy in zip(uv.data,[(0,lo),(1,lo),(1,hi),(0,hi)]):lp.uv=xy
    return o
def piston(name,a,b,r):
    a,b=V(a),V(b);v=b-a
    seg(name+' / sleeve',a,a+v*.62,r,'gun');seg(name+' / barrel',a+v*.04,a+v*.50,r*1.1,'red');seg(name+' / gland',a+v*.54,a+v*.62,r*1.16,'brass')
    seg(name+' / piston',a+v*.62,b,r*.62,'edge');disc(name+' / lock',a+v*.83,v,r*.75,.009,'gun')
def lathe(name,a,b,st,mat='red',n=48):
    a,b=V(a),V(b);q=(b-a).to_track_quat('Z','Y');L=(b-a).length
    objj=rings(name,[[(r*cos(2*pi*i/n),r*sin(2*pi*i/n),t*L) for i in range(n)] for t,r in st],mat,.0008)
    objj.location=a;objj.rotation_euler=q.to_euler()
    for p in objj.data.polygons[2:]:p.use_smooth=True
    return objj
C=.032
group("01  |  Torque box & pilot well")
rings("Chassis / cast saddle",[chamfer(C,.20,-.12,.43,.37,.06),chamfer(C,.21,.025,.64,.5,.04),chamfer(C,.294,.105,.60,.27,.05),chamfer(C,.31,.35,.48,.23,.045)],'wine',.011)
box('Rear bulkhead',(C,.415,.255),(.55,.12,.37),'red',.024)
seg("Shoulder / transverse axle",(-.62,.20,.275),(.65,.20,.275),.083,'gun')
box("Pilot well / floor",(C,-.006,.034),(.235,.30,.060),'gun',.017)
box("Pilot well / seat cushion",(C,.035,.102),(.154,.15,.059),'seat',.020)
box("Pilot well / stitched backrest",(C,.107,.244),(.139,.037,.239),'seat',.018,(-.12,0,0))
box("Pilot well / head pad",(C,.128,.387),(.102,.052,.075),'black',.012)
for s in [-1,1]:
    x=C+s*.109
    tube("Pilot well / roll hoop",[(x,-.112,.07),(x,-.028,.37),(x,.07,.50),(x,.17,.47)],.012,'gun')
    seg("Pilot well / harness",(C+s*.049,.068,.32),(C+s*.035,.065,.16),.009,'black')
    seg("Pilot well / control lever",(x,-.005,.12),(x,-.061,.251),.007,'edge');disc("Pilot well / grip",(x,-.060,.253),(0,0,1),.014,.029,'black')
    box("Foot controls",(C+s*.05,-.105,.064),(.066,.041,.027),'steel',.004)
box("Dashboard / binnacle",(C,-.065,.246),(.15,.065,.048),'wine',.008,(-.18,0,0))
for i in range(5):box("Instrument / pilot light",(C-.048+i*.024,-.075,.271),(.015,.011,.004),'teal' if i<3 else 'amber',.001)

group("02  |  Canopy & field pennant")
def hood(t,ang,delta=0):
    return (C+(.117+delta)*sin(ang),-.395+t*.218+(1-cos(ang))*.122,.407+.195*cos(ang)+.097*t+delta*cos(ang))
tt=[0,.05,.22,.77,.97,1];angles=[(i/12-.5)*pi for i in range(13)]
vs=[hood(t,a) for t in tt for a in angles]
o=mesh('Canopy / formed ochre shell',vs,[(j*13+i,j*13+i+1,(j+1)*13+i+1,(j+1)*13+i) for j in range(len(tt)-1) for i in range(12)],'gold')
mod=o.modifiers.new('Laminated shell','SOLIDIFY');mod.thickness=.009
surface_mark(o,[((a/pi)+.5,t) for t in tt for a in angles],'canopy_mark.png',(.83,.77,.60))
for t,m,r in [(0,'steel',.006),(.78,'red',.009),(1,'wine',.008)]:tube('Canopy / rolled arch',[hood(t,a,.002) for a in angles],r,m,False)
for s in [-1,1]:
    tube('Canopy / sill',[hood(t,s*pi/2) for t in tt],.013,'red',False)
    for y,z in [(-.245,.406),(-.064,.489)]:
        seg("Hood / stay",(C+s*.105,-.017,.29),(C+s*.113,y,z),.007,'steel')
    for t in [.07,.37,.72,.95]:bolt(hood(t,s*1.43,.004),(s,0,0),.0038)
# A worn white maintenance star follows the curvature of the roof.
points=[]
for i in range(10):
    a=pi/2+2*pi*i/10;r=1 if i%2==0 else .42
    points.append(hood(.45+.32*r*sin(a),.86*r*cos(a),.0012))
# Folded cloth with a tapered, irregular lower hem and a screen-printed crest.
def cloth(u,v):
    width=(.138*(1-v)**.62+.008)
    return (C+u*width,-.126+.045*v+.012*sin(u*8+v*3)*(.45+v)-.025*(1-u*u),
            -.018-.55*v+.022*(u*u)*v+.009*sin(34*u)*v**5)
nu,nv=32,20
o=mesh('Pennant / graphite drape',[cloth(2*i/nu-1,j/nv) for j in range(nv+1) for i in range(nu+1)],[(j*(nu+1)+i,j*(nu+1)+i+1,(j+1)*(nu+1)+i+1,(j+1)*(nu+1)+i) for j in range(nv) for i in range(nu)],'canvas',smooth=True)
o.modifiers.new('Bound textile','SOLIDIFY').thickness=.002
surface_mark(o,[(i/nu,1-j/nv) for j in range(nv+1) for i in range(nu+1)],'pennant_mark.png',(.58,.034,.012))
def crestpt(x,z):
    v=(z+.018)/(-.55);u=x/(.138*(1-v)**.62+.008);a,b,c=cloth(u,v);return (a,b-.0017,c)
tube('Pennant / hanger',[(C-.144,-.116,-.005),(C,-.160,-.069),(C+.144,-.116,-.005)],.008,'brass')

group("03  |  Paired radiator spines")
for s in [-1,1]:
    x=C+s*.219
    rings('Radiator / tapering plenum',[chamfer(x,.145,.036,.218,.42),chamfer(x,.18,.425,.217,.46),chamfer(x,.207,.477,.175,.399),chamfer(x,.233,.773,.138,.309,.012)],'red',.008)
    # Forward surface is raked back towards +Y from bottom to top.
    low=V((x,.007,.475));high=V((x,.077,.758))
    beam('Radiator / recessed intake',low,high,.129,.018,'iron')
    for j in range(16):
        c=low.lerp(high,(j+.45)/16);box('Radiator / intake louvre',(x,c.y-.012,c.z),(.119-.013*j/16,.030,.0085),'gun',.0015,(-.25,0,0))
    for q in [-1,1]:beam('Radiator / intake rim',low+V((q*.074,-.005,-.008)),high+V((q*.065,-.005,.009)),.014,.024,'red',.002)
    box('Radiator / upper lip',(x,.082,.766),(.147,.027,.020),'red',.003)
    for q in [-1,1]:
        profile('Spine / lift fin',[(.13,.766),(.16,.815),(.18,.818),(.17,.764)],x+q*.045,.012,'steel',.001)
    for j in range(3):
        z=.082+j*.127;y=-.061+j*.017
        box('Radiator / forward stepped cover',(x,y,z),(.148,.095,.081),'red',.009,(-.06,0,0))
        for q in [-1,1]:bolt((x+q*.052,y-.049,z+.016),(0,-1,0),.0065)
    for j in range(2):
        box('Radiator / warning flash',(x+(j-.5)*.049,-.113,.085),(.037,.008,.043),'ivory',.002)
    for q in [-1,1]:
        tube('Spine / side grab',[(x+q*.079,.146,.559),(x+q*.104,.148,.554),(x+q*.104,.257,.62),(x+q*.077,.266,.635)],.006,'steel',False)
    profile('Radiator / access cheek',[(.097,.499),(.31,.51),(.341,.587),(.34,.704),(.12,.744)],x+s*.075,.008,'wine',.003)
    for y,z in [(.12,.546),(.309,.569),(.14,.72)]:bolt((x+s*.082,y,z),(s,0,0),.006)
    decal('Stencil / lift here',(x,.238,.779),(.113,0,0),(0,.031,0),4)

group("04  |  Twin induction plant")
for s in [-1,1]:
    x=C+s*.211;z=.293
    lathe('Power pod / impeller cowl',(x,.315,z),(x,.775,z),[(0,.10),(.13,.142),(.31,.138),(.39,.127),(.52,.127),(.63,.137),(.82,.137),(.96,.128),(1,.117)],'red')
    for y,r,m in [(.405,.139,'wine'),(.512,.134,'gun'),(.538,.133,'red'),(.744,.131,'steel'),(.762,.124,'gun')]:
        disc('Power pod / casing band',(x,y,z),(0,1,0),r,.014,m)
    # Concentric annular socket rather than a flat dark cylinder.
    lathe('Power pod / intake throat',(x,.779,z),(x,.729,z),[(0,.119),(.10,.119),(.14,.094),(.65,.08),(1,.065)],'steel')
    disc('Power pod / recessed throat',(x,.781,z),(0,1,0),.096,.004,'iron')
    for j in range(17):
        a=2*pi*j/17
        def bladept(r,t,y):return (x+r*cos(t),y,z+r*sin(t))
        mesh('Power pod / curved impeller vane',[bladept(.033,a+.27,.789),bladept(.091,a,.785),bladept(.091,a+.13,.785),bladept(.034,a+.46,.789)],[(0,1,2,3)],'gun')
    disc('Power pod / spindle cap',(x,.793,z),(0,1,0),.034,.018,'brass')
    disc('Power pod / spindle crown',(x,.801,z),(0,1,0),.026,.01,'ivory')
    for j in range(12):
        a=2*pi*j/12;bolt((x+.108*cos(a),.784,z+.108*sin(a)),(0,1,0),.0043)
    for j in range(8):
        a=2*pi*j/8;tube('Cowl / runner',[(x+.13*cos(a),.593,z+.13*sin(a)),(x+.139*cos(a),.641,z+.139*sin(a)),(x+.133*cos(a),.72,z+.133*sin(a))],.0048,'red')
    lathe('Power pod / angled breather',(C+s*.132,.326,.485),(C+s*.185,.478,.65),[(0,.027),(.12,.035),(.21,.035),(.24,.027),(.86,.027),(.89,.032),(1,.03)],'gun',24)
    for y in [.36,.42,.48]:box('Plant / crosshead',(C,y,.43),(.35,.026,.045),'red',.004)
lathe('Plant / central accumulator',(C,.43,.445),(C,.704,.553),[(0,.046),(.2,.088),(.45,.117),(.7,.113),(.88,.08),(1,.046)],'red',10)
disc('Plant / accumulator end',(C,.702,.552),(0,1,.4),.048,.015,'gun',8)
box('Plant / heat exchanger',(C,.583,.225),(.14,.15,.16),'iron',.016)
for j in range(12):box('Plant / cooling lamella',(C,.66,.155+j*.012),(.11+.016*sin(j*pi/12),.029,.005),'steel',.001)
decal('Stencil / plant designation',(C,.403,.456),(.133,0,0),(0,.03,0),6)

for s,side in [(-1,'R'),(1,'L')]:
    group("05"+side+"  |  Reverse-link undercarriage")
    x=C+s*.318
    def xp(y,z,dx=0):return (x+dx,y,z)
    def hub(y,z,w,r):
        seg('Joint / through axle',xp(y,z,-w*.5),xp(y,z,w*.5),r,'gun')
        for q in [-1,1]:
            for off,rr,mat,depth in [(0,r,'steel',.018),(.009,r*.75,'iron',.014),(.017,r*.43,'brass',.008)]:
                disc('Joint / bearing race',xp(y,z,q*(w/2+off)),(1,0,0),rr,depth,mat)
            bolt(xp(y,z,q*(w/2+.023)),(q,0,0),r*.24)
    hub(.14,-.069,.231,.098)
    profile('Leg / cast upper linkage',[(-.009,-.047),(.171,.008),(.586,-.235),(.604,-.374),(.489,-.431),(.257,-.272),(.044,-.213)],x,.155,'wine',.012)
    for q in [-1,1]:
        profile('Leg / cheek plate',[(.08,-.085),(.174,-.025),(.55,-.255),(.541,-.345),(.459,-.35),(.217,-.184)],x+q*.086,.015,'red')
    # Forward guard: a bent sheet turning back over the hip.
    rs=[]
    for a in [-.2,.08,.46,.88,1.22,1.55,1.9]:
        y=.095-.144*cos(a);z=-.187+.205*sin(a)
        rs.append([(x+dx,y+dy,z+dz) for dx,dy,dz in [(-.091,-.007,0),(.091,-.007,0),(.091,.005,-.004),(-.091,.005,-.004)]])
    rings('Leg / rolled thigh shield',rs,'red',.003)
    for q in [-1,1]:bolt(xp(-.053,-.092,q*.068),(0,-1,0),.009)
    hub(.535,-.368,.20,.091)
    profile('Leg / lower rocker',[(.57,-.349),(.598,-.431),(.26,-.69),(.091,-.737),(.015,-.662),(.116,-.562),(.391,-.416),(.448,-.348)],x,.154,'gun',.012)
    for q in [-1,1]:
        profile('Rocker / armor',[(.489,-.4),(.531,-.443),(.23,-.658),(.123,-.666),(.125,-.597),(.361,-.452)],x+q*.084,.014,'red',.006)
        piston('Rocker / assist ram',xp(.06,-.071,q*.092),xp(.252,-.562,q*.092),.020)
    a=V(xp(.081,-.143));b=V(xp(.143,-.595));v=b-a
    lathe('Leg / vertical load cylinder',a,b,[(0,.070),(.08,.078),(.16,.075),(.20,.068),(.48,.068),(.51,.076),(.58,.076),(.60,.050),(.91,.050),(.92,.065),(1,.064)],'gun')
    for t in [.22,.30,.38,.46]:disc('Leg / strut cooling collar',a+v*t,v,.073,.012,'iron')
    for q in [-1,1]:
        seg('Leg / fork stanchion',xp(.067,-.212,q*.072),xp(.129,-.557,q*.072),.021,'steel')
        lathe('Leg / gaiter',xp(.105,-.389,q*.072),xp(.14,-.568,q*.072),[(i/12,.030 if i%2==0 else .024) for i in range(13)],'black',20)
        tube('Leg / flexible feed',[xp(.085,-.173,q*.089),xp(.032,-.239,q*.118),xp(.043,-.415,q*.114),xp(.125,-.52,q*.09)],.007,'black')
    # Twin rear struts of the characteristic long, upswept heel.
    for q in [-1,1]:
        a=V(xp(.092,-.684,q*.121));b=V(xp(.89,-.373,q*.131));v=b-a
        seg('Heel / guide rod',a,b,.039,'steel')
        lathe('Heel / shock jacket',a+v*.15,a+v*.71,[(0,.049),(.06,.058),(.13,.056),(.17,.048),(.88,.050),(.93,.058),(1,.053)],'red',24)
        for t in [.31,.44,.57]:disc('Heel / jacket band',a+v*t,v,.054,.024,'gun')
        disc('Heel / endstop',b-v*.012,v,.044,.020,'red')
        tube('Heel / relief line',[a+V((0,.03,.017)),a+v*.4+V((q*.026,.018,.035)),a+v*.72+V((q*.015,.023,-.024)),b-v*.015],.006,'black')
    hub(.236,-.729,.261,.048)
    # Split, wedge-shaped load pads with rounded steel contact edges.
    for q in [-1,1]:
        profile('Foot / split toe', [(-.153,-.814),(-.134,-.789),(-.035,-.735),(.091,-.724),(.173,-.754),(.175,-.808),(.126,-.821),(-.145,-.821)],x+q*.059,.107,'steel',.006)
        for k in range(4):box('Foot / traction key',xp(-.10+k*.063,-.821,q*.06),(.092,.026,.009),'gun',.002)
    profile('Foot / heel cleat',[(.17,-.814),(.202,-.75),(.287,-.741),(.376,-.801),(.381,-.822)],x,.194,'steel',.005)
    hub(.038,-.756,.234,.035)
    # Crown of the front foot, open at the toe.
    stations=[]
    for y,w,z,h in [(-.08,.133,-.745,.030),(-.035,.145,-.728,.075),(.078,.134,-.679,.115),(.164,.115,-.65,.113)]:
        stations.append([(x+w*sin(a),y,z+h*cos(a)) for a in [(-.5+i/12)*pi for i in range(13)]])
    vs=[p for st in stations for p in st];o=mesh('Foot / knuckle shell',vs,[(j*13+i,j*13+i+1,(j+1)*13+i+1,(j+1)*13+i) for j in range(3) for i in range(12)],'red')
    o.modifiers.new('Pressed shell','SOLIDIFY').thickness=.009
    tube("Foot / toe edging",stations[0],.005,'edge',False)
    for q in [-1,1]:bolt(xp(.06,-.582,q*.040),(0,-.3,.95),.011)

for s,side in [(-1,'R'),(1,'L')]:
    group("06"+side+"  |  Gimbal & shoulder carrier")
    def X(v):return C+s*v
    z=.279;y=.204
    for a,b,r1,r2,mat in [(.29,.401,.102,.077,'steel'),(.391,.43,.083,.077,'gun'),(.425,.499,.079,.13,'steel'),(.483,.562,.138,.142,'gun'),(.534,.653,.143,.139,'steel'),(.625,.68,.135,.097,'wine')]:
        seg('Gimbal / splined collar',(X(a),y,z),(X(b),y,z+.012),r1,mat,r2=r2)
    for i in range(20):
        a=2*pi*i/20
        o=box('Gimbal / rib',(X(.582),y+.143*cos(a),z+.012+.143*sin(a)),(.045,.014,.006),'gun',.001);o.rotation_euler.x=a-pi/2
    profile('Arm / upper clevis',[(.125,.329),(.279,.319),(.452,.101),(.456,-.004),(.375,-.045),(.286,.008),(.184,.18)],X(.596),.13,'gun',.01)
    for q in [-1,1]:
        piston('Arm / drive cylinder',(X(.59)+q*.058,.194,.25),(X(.677)+q*.056,.34,.045),.036)
    seg('Elbow / axle',(X(.505),.398,.048),(X(.791),.398,.048),.079,'wine')
    for off,rr,mat in [(.779,.072,'red'),(.798,.049,'gun'),(.808,.027,'steel')]:disc('Elbow / boss',(X(off),.398,.048),(s,0,0),rr,.02,mat)
    # Canted, separately built carrier and edge rail.
    top=.785 if s==-1 else .707
    P=[(-.031,.558),(.044,.635),(.135,top),(.294,top-.019),(.371,.631),(.394,.432),(.336,.341),(.389,.179),(.307,.103),(.231,.154),(.182,.288),(.032,.355)]
    xb=X(.91);tilt=-s*.407
    profile('Shoulder / reinforced silhouette',P,xb,.04,'gun',.008,tilt)
    P2=[(.008,.554),(.089,.647),(.146,top-.027),(.272,top-.039),(.338,.60),(.352,.444),(.293,.344),(.34,.197),(.301,.158),(.251,.194),(.209,.314),(.059,.38)]
    profile('Shoulder / pressed vermilion face',P2,xb+s*.024,.026,'red',.012,tilt)
    profile('Shoulder / inner liner',[(.046,.532),(.135,top-.05),(.264,top-.073),(.337,.46),(.258,.34),(.064,.387)],xb-s*.023,.012,'wine',.004,tilt)
    def sh(y,z,off):return (xb+tilt*z+s*off,y,z)
    profile('Shoulder / inset strike plate',[(.038,.524),(.14,.641),(.283,.624),(.324,.53),(.293,.393),(.214,.349),(.064,.401)],xb+s*.042,.008,'gun',.003,tilt)
    for yy,zz in [(.072,.401),(.30,.444),(.138,.658),(.287,.598),(.303,.192)]:
        bolt(sh(yy,zz,.052),(s,0,.4),.012)
    for j,zz in enumerate([.46,.526,.588]):
        tube('Shoulder / exoskeleton rib',[sh(-.029,zz,.038),sh(.066,zz+.044,.077),sh(.244,zz+.052,.076),sh(.384,zz-.016,.044)],.012 if j!=1 else .017,'gun',False)
    for yy,zz in [(.30,.21),(.253,.30)]:
        for off,rr,mat in [(.052,.045,'gun'),(.067,.031,'steel'),(.075,.015,'iron')]:
            disc('Shoulder / damper cap',sh(yy,zz,off),(s,0,.4),rr,.016,mat)
    tube('Shoulder / lanyard',[sh(.17,top-.024,.03),sh(.049,.66,.094),sh(-.043,.54,.083),sh(.083,.411,.055)],.007,'steel')
    # Different top details on port and starboard.
    if s<0:
        for y0 in [.138,.255]:
            profile('Shoulder / lift lug',[(y0-.03,.689),(y0-.022,.757),(y0+.035,.809),(y0+.045,.777),(y0+.015,.697)],xb+s*.046,.016,'steel',.003,tilt)
    else:
        seg('Shoulder / reserve cell',sh(.128,.58,.073),sh(.264,.524,.071),.052,'red')
        for yy,zz in [(.142,.575),(.245,.532)]:disc('Shoulder / reserve clamp',sh(yy,zz,.071),(0,1,-.4),.055,.023,'iron')

    group("07"+side+"  |  "+("Long extraction fork" if s<0 else "Service pincers"))
    # Tool-local forward, transverse and vertical axes.
    f=V((s*.105,-1,-.365)).normalized();u=V((1,s*.105,0)).normalized();h=f.cross(u).normalized()
    origin=V((X(.704 if s<0 else .695),.219,-.067 if s<0 else -.074))
    def P(xx,t,zz):return origin+xx*u+t*f+zz*h
    def section(t,w,hh,ch):
        a=w/2;b=hh/2;c=ch
        return [P(xx,t,zz) for xx,zz in [(-a+c,-b),(a-c,-b),(a,-b+c),(a,b-c),(a-c,b),(-a+c,b),(-a,b-c),(-a,-b+c)]]
    L=.643 if s<0 else .423;w=.31 if s<0 else .267
    for q in [-1,1]:
        piston('Forearm / actuator',(X(.68)+q*.064,.393,.041),P(q*.062,.13,-.011),.038)
    if s<0:
        rings('Tool / ribbed drive housing',[section(-.03,w*.70,.18,.031),section(.061,w,.249,.038),section(L-.035,w*.92,.255,.025),section(L,w*.82,.22,.027)],'red',.008)
    else:
        rings('Pincer / transmission cap',[section(-.03,w*.70,.18,.031),section(.061,w,.249,.038),section(.13,w*.91,.202,.03)],'red',.008)
        rings('Pincer / jaw saddle',[section(L-.103,w*.90,.226,.035),section(L-.052,w,.25,.031),section(L,w*.82,.22,.027)],'red',.008)
        for q in [-1,1]:
            piston('Pincer / exposed drive ram',P(q*.055,.118,.014),P(q*.055,L-.079,.014),.040)
            seg('Pincer / slide rail',P(q*.091,.10,-.07),P(q*.091,L-.061,-.07),.024,'steel')
        seg('Pincer / cross pin',P(-w*.55,L-.043,.019),P(w*.55,L-.043,.019),.034,'gun')
    for k in [.07,L-.059]:
        rings('Tool / banded collar',[section(k-.013,w+.010,.263,.032),section(k+.013,w+.010,.263,.032)],'wine',.004)
    for q in [-1,1]:
        a=P(q*(w*.5-.036),-.038,.103);b=P(q*(w*.5-.036),L+.009,.101)
        lathe('Tool / armored longitudinal rail',a,b,[(0,.023),(.033,.030),(.106,.03),(.128,.024),(.93,.024),(.94,.03),(1,.03)],'red',20)
        disc('Tool / rail plug',b,f,.019,.007,'steel')
        # Broad bolt-on side access cover.
        if s>0:continue
        xx=q*(w/2+.003)
        poly=[P(xx,t,zz) for t,zz in [(.122,-.064),(L-.13,-.064),(L-.105,-.042),(L-.105,.047),(L-.126,.067),(.116,.067)]]
        mesh('Tool / service plate',poly,[tuple(range(len(poly)))],'gun')
        for t in [.138,L-.136]:
            for zz in [-.044,.046]:bolt(P(xx+q*.003,t,zz),u*q,.0055)
    decal('Stencil / tool service',P(0,L*.56 if s<0 else L-.055,.129),f*(L*.61 if s<0 else .046),u*.058,2 if s<0 else 1)
    # Side badge follows a slanted bolt-on panel.
    if s<0:decal('Stencil / type number',P(s*(w/2+.008),L*.49,.003),f*(L*.38),h*.037,5)
    disc('Tool / drive flange',P(0,L+.012,0),f,.102,.04,'steel')
    disc('Tool / drive recess',P(0,L+.036,0),f,.084,.011,'iron')
    for j in range(10):
        a=2*pi*j/10;bolt(P(.091*cos(a),L+.034,.091*sin(a)),f,.0049)
    seg('Tool / central mandrel',P(0,L+.019,0),P(0,L+.19,0),.043,'steel',r2=.028)
    # Individually forged jaws, asymmetrical sections thinning into an edge.
    for j in range(3 if s<0 else 2):
        a=(pi/2+j*2*pi/3) if s<0 else (.3+j*pi)
        radial=u*cos(a)+h*sin(a);tan=-u*sin(a)+h*cos(a)
        length=(.56 if s<0 else .531)*([1,.96,.94][j])
        sts=[]
        for t,rad,span,th in [(0,.065,.038,.016),(.076,.083,.067,.021),(.23,.097,.061,.016),(.72,.112,.051,.012),(.91,.101,.039,.009),(1,.091,.014,.0028)]:
            c=P(0,L+t*length,0)+radial*rad+tan*(.017*t*t)
            sts.append([c+radial*th,c+tan*span,c-radial*th*.96,c-tan*span])
        o=rings('Tool / forged jaw '+str(j+1),sts,'steel',.001)
        o.data.materials.append(M['edge'])
        for p in o.data.polygons[2:]:
            if (p.index-2)%4==1:p.material_index=len(o.data.materials)-1
        for t in [.075,.16,.25]:
            disc('Jaw / locking pin',P(0,L+length*t,0)+radial*(.105),radial,.009,.005,'gun',8)
    for q in [-1,1]:
        pts=[P(q*w*.45,.09,.005),P(q*(w*.5+.035),.135,-.09),P(q*(w*.5+.034),L*.77,-.11),P(q*w*.46,L*.87,-.066)]
        tube('Tool / formed crash rail',pts,.009,'steel')

    group("08"+side+"  |  Return lines & harness")
    pts=[(X(.065),.575,.096),(X(.092),.643,.027),(X(.27),.641,-.031),(X(.447),.585,-.104),(X(.585),.53,-.241),(X(.679),.512,-.301),(X(.732),.411,-.291),tuple(P(s*.081,.035,-.092))]
    tube('Return / main pressure hose',pts,.030,'black')
    for i0 in [0,-1]:
        a=V(pts[i0]);v=(V(pts[1])-a if i0==0 else V(pts[-2])-a).normalized()
        seg('Return / ferrule',a-v*.009,a+v*.043,.036,'steel',n=12)
        disc('Return / crimp band',a+v*.048,v,.034,.013,'brass')
    tube('Control / braided loom',[(X(.236),.61,.16),(X(.37),.585,.124),(X(.42),.523,.041),(X(.573),.49,-.031),(X(.70),.46,-.168),tuple(P(s*.116,.14,-.043))],.011,'black')
    tube('Control / gimbal feed',[(X(.57),.255,.27),(X(.584),.436,.144),(X(.657),.553,-.034),(X(.785),.512,-.15),tuple(P(s*.11,.099,-.072))],.008,'gun')
    tube('Control / actuator feed',[(X(.253),.36,.136),(X(.39),.419,-.06),(X(.522),.388,-.046),tuple(P(-s*.1,.24,-.10))],.008,'black')

group("09  |  Identification & running lights")
for s in [-1,1]:
    x=C+s*.218
    box('Headlamp / casting',(x,-.086,.231),(.080,.028,.032),'gun',.005)
    for i in range(3):box('Headlamp / individual lens',(x+(i-1)*.021,-.101,.231),(.014,.006,.016),'amber',.003)
    decal('Stencil / radiator number',(x,-.088,.344),(.108,0,0),(0,0,.023),3)
decal('Stencil / cab number',(C,-.105,.045),(.165,0,0),(0,0,.026),0)
sc.world=bpy.data.worlds.new('Workshop ambient');sc.world.color=(.20,.20,.20)
sc.render.engine='CYCLES'
sc.unit_settings.system='NONE'
anchor=bpy.data.objects.new('SCV | assembly datum',None);master.objects.link(anchor)
anchor.empty_display_type='PLAIN_AXES';anchor.empty_display_size=.12
for part in list(master.all_objects):
    if part!=anchor:part.parent=anchor
anchor.scale=(2/1.8693092,1,1);anchor.location=(-.00920347*anchor.scale.x,.01496475,.00382415)
for screen in bpy.data.screens:
    for area in screen.areas:
        if area.type=='VIEW_3D':
            sp=area.spaces.active;sp.region_3d.view_rotation=V((-.42,.91,-.32)).to_track_quat('-Z','Y');sp.region_3d.view_distance=3.0;sp.region_3d.view_location=(0,0,0)
            sp.overlay.show_overlays=False;sp.shading.color_type='MATERIAL';sp.shading.light='STUDIO';sp.shading.show_cavity=True;sp.shading.cavity_type='WORLD'
sc['Orientation']="Right-handed | +Z up | -Y forward | +X port (mech left). Normalized scene units."
preview=ROOT/'media'/'graphics'/'asset_preview.png'
if preview.is_file():
    with bpy.context.temp_override(id=master):
        bpy.ops.ed.lib_id_load_custom_preview(filepath=str(preview))
bpy.ops.wm.save_as_mainfile(filepath=str(ROOT/'asset.blend'),compress=True,relative_remap=False)
