"""Build the five-shot lighting stage. The machine is linked, not duplicated."""
import bpy, math
from mathutils import Vector as V
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
bpy.ops.wm.read_factory_settings(use_empty=True)
bpy.context.preferences.filepaths.save_version=0
s=bpy.context.scene;s.name='STAGE | Recovery walker'
with bpy.data.libraries.load(str(ROOT/'asset.blend'),link=True) as (src,dst):
    dst.collections=[n for n in src.collections if n.startswith('SCV')]
o=bpy.data.objects.new('SCV | library instance',None);s.collection.objects.link(o)
o.instance_type='COLLECTION';o.instance_collection=dst.collections[0]
def point(o,p):o.rotation_euler=(V(p)-o.location).to_track_quat('-Z','Y').to_euler()
def light(n,p,color,power,size,ratio=1):
    d=bpy.data.lights.new(n,'AREA');d.shape='RECTANGLE';d.size=size;d.size_y=size*ratio;d.energy=power;d.color=color
    o=bpy.data.objects.new(n,d);s.collection.objects.link(o);o.location=p;point(o,(0,0,0))
light('01 / warm overhead',(-2.4,-3.5,4.1),(1,.88,.75),325,3.2,.66)
light('02 / cool book light',(3.3,-1.6,1.65),(.69,.85,1),154,2.4,1.35)
light('03 / shoulder strip',(1.5,2.5,3.2),(1,.91,.82),515,2.4,.48)
light('04 / back reflector',(-2.8,2.1,1.2),(.72,.88,1),145,2,.48)
s.world=bpy.data.worlds.new('Neutral studio');s.world.use_nodes=True
bg=s.world.node_tree.nodes['Background'];bg.inputs[0].default_value=(.38,.41,.46,1);bg.inputs[1].default_value=.36
bpy.ops.mesh.primitive_plane_add(size=200,location=(0,0,-.8218));floor=bpy.context.object;floor.name='Cyclorama | warm grey / graphite'
m=bpy.data.materials.new('Painted stage | shot palette');m.use_nodes=True;floor.data.materials.append(m);bs=m.node_tree.nodes['Principled BSDF']
bs.inputs['Roughness'].default_value=.68
for fr,c in [(1,(.26,.255,.23)),(97,(.036,.048,.056)),(169,(.034,.041,.044)),(241,(.050,.064,.064)),(331,(.26,.255,.23))]:
    bs.inputs['Base Color'].default_value=(*c,1);bs.inputs['Base Color'].keyframe_insert(data_path='default_value',frame=fr)
def curves(id):
    a=id.animation_data.action
    return a.layers[0].strips[0].channelbag(id.animation_data.action_slot).fcurves
for c in curves(m.node_tree):
    for k in c.keyframe_points:k.interpolation='CONSTANT'
# (start, end, azimuth around -Y, elevation, aim, field width, horizontal placement)
shots=[
 ('01 | The recovery walker',1,96,(-8,15,(.01,.02,-.02),3.73,.645),(-38,21,(.01,.02,-.035),3.82,.645)),
 ('02 | Operator cell',97,168,(21,20,(.015,.025,.37),1.68,.650),(-2,17,(.03,.013,.388),1.53,.650)),
 ('03 | Extraction fork',169,240,(-58,24,(-.66,-.245,-.221),2.14,.511),(-83,14,(-.62,-.232,-.23),2.04,.505)),
 ('04 | Induction plant',241,330,(143,21,(.03,.39,.18),2.69,.65),(190,10,(.03,.40,.17),2.58,.64)),
 ('05 | Final elevation',331,438,(43,23,(0,.03,-.03),3.88,.653),(16,12,(0,.015,-.02),3.78,.645))]
for name,first,last,A,B in shots:
    d=bpy.data.cameras.new(name);d.type='ORTHO';o=bpy.data.objects.new(name,d);s.collection.objects.link(o);d.clip_end=90
    for j in range(5):
        t=j/4; fr=round(first+(last-first)*t)
        v=lambda a,b:a*(1-t)+b*t
        az,el=math.radians(v(A[0],B[0])),math.radians(v(A[1],B[1]))
        aim=V(A[2]).lerp(V(B[2]),t);direction=V((math.sin(az)*math.cos(el),-math.cos(az)*math.cos(el),math.sin(el)))
        q=(-direction).to_track_quat('-Z','Y');field=v(A[3],B[3])
        o.location=aim+direction*5+(q@V((1,0,0)))*field*(.5-v(A[4],B[4]));o.rotation_euler=q.to_euler()
        if j and abs(o.rotation_euler.z-prev)>math.pi:
            o.rotation_euler.z+=2*math.pi if o.rotation_euler.z<prev else -2*math.pi
        prev=o.rotation_euler.z
        o.keyframe_insert(data_path='location',frame=fr);o.keyframe_insert(data_path='rotation_euler',frame=fr)
        d.ortho_scale=field;d.keyframe_insert(data_path='ortho_scale',frame=fr)
    for id in (o,d):
        for c in curves(id):
            for k in c.keyframe_points:k.interpolation='BEZIER';k.handle_left_type=k.handle_right_type='AUTO_CLAMPED'
    s.timeline_markers.new(name,frame=first).camera=o
s.render.engine='CYCLES';s.cycles.samples=8;s.cycles.use_denoising=True
s.cycles.max_bounces=3;s.cycles.diffuse_bounces=1;s.cycles.glossy_bounces=2;s.cycles.transparent_max_bounces=3
s.render.use_persistent_data=True
s.render.resolution_x=1280;s.render.resolution_y=720;s.render.resolution_percentage=100
s.render.fps=24;s.frame_start=1;s.frame_end=438
s.render.image_settings.file_format='PNG';s.render.image_settings.color_mode='RGB';s.render.image_settings.compression=15
s.render.filepath='//renders/plate_'
s.view_settings.view_transform='AgX';s.view_settings.look='AgX - Medium High Contrast'
s.frame_set(1);s.camera=bpy.data.objects[shots[0][0]]
for a in bpy.context.screen.areas:
    if a.type=='VIEW_3D':a.spaces.active.region_3d.view_perspective='CAMERA';a.spaces.active.overlay.show_overlays=False;a.spaces.active.shading.color_type='MATERIAL'
bpy.ops.wm.save_as_mainfile(filepath=str(ROOT/'stage.blend'),compress=True,relative_remap=True)
for lib in bpy.data.libraries:lib.filepath='//asset.blend'
bpy.ops.wm.save_as_mainfile(filepath=str(ROOT/'stage.blend'),compress=True)
