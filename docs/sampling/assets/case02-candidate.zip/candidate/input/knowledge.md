# 事实资料

1. 采样是按一定时间间隔记录信号值；采样率fs是每秒采样次数，单位Hz。信号频率f描述每秒振荡次数，二者不是同一个量。
2. 对带限基带信号，理想重建要求fs大于最高频率的两倍。实际系统还需要为非理想滤波留余量，不应宣称恰好两点必能恢复任意波形。
3. 采样点可能同时符合多个连续信号。没有足够带宽约束时，不能唯一知道采样前是哪一个。
4. 本题使用余弦信号。3 kHz在8 kHz采样时低于4 kHz奈奎斯特频率；3 kHz在4 kHz采样时超过2 kHz奈奎斯特频率。
5. 在4 kHz采样时，cos(2π·3000·n/4000)与cos(2π·1000·n/4000)的离散采样值相同。这里混叠频率为1 kHz。此等式不能推广为所有情况都直接相减。
6. 本题的混叠示范故意省略采样前的低通处理。正常采集/降采样通常包含抗混叠滤波，不能说所有降采样都会把高音变成低音。
7. 在降至4 kHz前抑制高于2 kHz的3 kHz分量，可以避免它折叠成错误低频，但不会保留该3 kHz原声。应提高采样率或降低输入带宽。
8. 对已经混叠的数据事后升采样，不会凭空找回丢失的原始频率信息。混叠不等同于慢放。

三段试听的输出容器均为48 kHz，这是为了统一播放条件，不等于模拟实验的有效采样率。图中须区分模拟采样率与交付文件采样率。

来源：
- The Scientist and Engineer's Guide to DSP, Chapter 3：https://www.analog.com/media/en/technical-documentation/dsp-book/dsp_book_Ch3.pdf
- SciPy resample_poly：https://docs.scipy.org/doc/scipy/reference/generated/scipy.signal.resample_poly.html

本资料为自写摘要与可计算例子。允许补充等价解释，但不增加未经依据支持的绝对结论。
