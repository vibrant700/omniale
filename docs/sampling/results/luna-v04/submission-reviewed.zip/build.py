from pathlib import Path
from PIL import Image, ImageDraw, ImageFont
import numpy as np, math, subprocess, json, wave, shutil
ROOT=Path(__file__).resolve().parent.parent
OUT=ROOT/'submission'; SCR=ROOT/'scratch'; OUT.mkdir(exist_ok=True)
W,H=1280,720; FPS=20; DUR=111.5
FONT='C:/Windows/Fonts/msyh.ttc'
def f(sz): return ImageFont.truetype(FONT,sz)
BG='#f3f1e9'; INK='#172d35'; MUT='#63747a'; TEAL='#14877d'; ORANGE='#e4774c'; BLUE='#4679bd'; LIME='#a5c94d'; WHITE='#fffefa'
# hand-timed scene sequence, all explanatory labels persist with corresponding visual
scenes=[(0,7,'question'),(7,25,'sampling'),(25,47,'alias'),(47,61,'listen'),(61,84,'upsample'),(84,111.5,'conclusion')]
def txt(d,xy,s,size=24,color=INK): d.text(xy,s,font=f(size),fill=color)
def waveplot(d,box, freq, color, phase=0, n=600, amp=1.0):
 x0,y0,x1,y1=box; pts=[]
 for i in range(n):
  x=i/(n-1); v=amp*math.cos(2*math.pi*freq*x+phase); pts.append((x0+x*(x1-x0), (y0+y1)/2-v*(y1-y0)*.43))
 d.line(pts,fill=color,width=4)
def chart(d,box):
 x0,y0,x1,y1=box
 d.rounded_rectangle(box,20,fill=WHITE,outline='#d9ddd6',width=2)
 d.line((x0+55,(y0+y1)//2,x1-24,(y0+y1)//2),fill='#c8d1cf',width=2)
 d.line((x0+55,y0+25,x0+55,y1-28),fill='#c8d1cf',width=2)
def frame(t):
 im=Image.new('RGB',(W,H),BG); d=ImageDraw.Draw(im)
 d.rounded_rectangle((28,24,1252,696),26,fill=BG,outline='#d8ddd6',width=2)
 d.rounded_rectangle((55,48,1225,116),18,fill=INK)
 txt(d,(82,63),'听见采样：点够不够？',30,WHITE); txt(d,(1020,68),f'{t:05.1f} s',22,'#c0d7d2')
 scene=next((s for s in scenes if s[0]<=t<s[1]),scenes[-1]); key=scene[2]
 if key=='question':
  txt(d,(85,165),'采样率不足，声音为什么变了样？',38)
  txt(d,(85,229),'把文件升到更高采样率，能补回来吗？',34,TEAL)
  chart(d,(85,310,1195,590)); waveplot(d,(135,350,1145,548),5,ORANGE)
  txt(d,(150,600),'连续信号：5 kHz 余弦',23,ORANGE); txt(d,(775,600),'本片实验：8 kHz 采样',23,BLUE)
 elif key=='sampling':
  txt(d,(85,145),'每秒 5,000 次振荡；每秒记录 8,000 个样本',28)
  chart(d,(85,205,1195,530)); waveplot(d,(140,230,1140,505),5,ORANGE)
  for i in range(17):
   x=140+i*62.5; v=math.cos(2*math.pi*5*i/8); y=367-v*120
   d.line((x,235,x,y),fill='#b2c5c6',width=2); d.ellipse((x-7,y-7,x+7,y+7),fill=BLUE,outline=WHITE,width=2)
  txt(d,(130,560),'橙线 原信号',22,ORANGE); txt(d,(410,560),'蓝点 采样值',22,BLUE); txt(d,(700,560),'每周期 5/8 圈',22,INK)
  txt(d,(130,610),'慢速展开示意：横轴放大，采样时刻和值不变；不是声音慢放。',21,MUT)
 elif key=='alias':
  txt(d,(85,145),'同一批采样值，也能对应另一条波形',29)
  chart(d,(85,190,1195,510)); waveplot(d,(140,225,1140,480),5,ORANGE)
  waveplot(d,(140,225,1140,480),3,TEAL)
  for i in range(17):
   x=140+i*62.5; v=math.cos(2*math.pi*3*i/8); y=352-v*110
   d.ellipse((x-7,y-7,x+7,y+7),fill=BLUE,outline=WHITE,width=2)
  txt(d,(140,530),'橙线 5 kHz',23,ORANGE); txt(d,(390,530),'绿线 3 kHz',23,TEAL); txt(d,(730,530),'蓝点：两者逐点重合',23,BLUE)
  txt(d,(125,584),'f_s = 8 kHz：cos(2π·5000·n/f_s) = cos(2π·3000·n/f_s)',25)
  txt(d,(125,630),'因为 5000 = 8000 − 3000；相位相差整圈。',22,MUT)
 elif key=='listen':
  txt(d,(85,150),'听一听：同一段采样，重建音高不同',30)
  for j,(yy,title,col,sub) in enumerate([(230,'原始信号：5 kHz',ORANGE,'48 kHz 播放'),(405,'8 kHz 采样的混叠重建：3 kHz',TEAL,'同样 48 kHz 播放')]):
   d.rounded_rectangle((95,yy,1185,yy+130),18,fill=WHITE,outline='#d9ddd6',width=2)
   txt(d,(125,yy+18),title,26,col); txt(d,(125,yy+70),sub,20,MUT)
   waveplot(d,(650,yy+22,1135,yy+110),5 if j==0 else 3,col)
  txt(d,(125,590),'音频按对应频率生成，等时长试听；不是播放慢速动画。',23,INK)
 elif key=='upsample':
  txt(d,(85,145),'8 kHz → 32 kHz：样本变密，原信息不会凭空增加',27)
  chart(d,(85,195,1195,510)); waveplot(d,(140,220,1140,485),3,TEAL)
  for i in range(17):
   x=140+i*62.5; v=math.cos(2*math.pi*3*i/8); y=352-v*110
   d.ellipse((x-7,y-7,x+7,y+7),fill=BLUE,outline=WHITE,width=2)
  for i in range(65):
   x=140+i*15.625; v=math.cos(2*math.pi*3*i/32); y=352-v*110
   d.ellipse((x-3,y-3,x+3,y+3),fill=LIME)
  txt(d,(130,535),'蓝点 原有样本',21,BLUE); txt(d,(400,535),'绿点 插值新增样本',21,'#6b8c22')
  txt(d,(130,580),'保持时长的采样率转换：在旧样本之间插值，不是重测原信号。',21)
  txt(d,(130,620),'试听升采样结果：仍对应 3 kHz；不自动恢复成 5 kHz。',23,TEAL)
 else:
  txt(d,(85,145),'结论：先看信号带宽，再谈采样够不够',30)
  for y,n,s in [(230,'01','带限基带信号的理想重建：采样率 > 最高频率的 2 倍；实际留滤波余量。'),(340,'02','升采样只增加插值点；混叠后的样本不能保证找回原信号。'),(450,'03','降采样前的抗混叠低通能滤掉带外成分；这是避免混叠，不是恢复。')]:
   d.rounded_rectangle((92,y,1188,y+83),16,fill=WHITE,outline='#d9ddd6',width=2); txt(d,(118,y+18),n,24,TEAL); txt(d,(195,y+18),s,22)
  txt(d,(95,580),'8 kHz 采样时奈奎斯特频率为 4 kHz；3 kHz 可表示，5 kHz 折回为 3 kHz。',21,MUT)
  txt(d,(95,624),'实际听到何种音色，还受重建滤波、扬声器与播放链路影响。',20,MUT)
 return im
# render through ffmpeg raw frames
ff='$USER/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/python.exe'
import imageio_ffmpeg
enc=imageio_ffmpeg.get_ffmpeg_exe()
video=SCR/'picture.mp4'
p=subprocess.Popen([enc,'-y','-v','error','-f','rawvideo','-pix_fmt','rgb24','-s',f'{W}x{H}','-r',str(FPS),'-i','pipe:0','-an','-c:v','libx264','-preset','ultrafast','-pix_fmt','yuv420p',str(video)],stdin=subprocess.PIPE)
for i in range(round(DUR*FPS)): p.stdin.write(np.asarray(frame(i/FPS)).tobytes())
p.stdin.close(); assert p.wait()==0
# mono sine excerpts, gated to align with listening and ending
sr=48000; seconds=111.5; t=np.arange(int(sr*seconds))/sr; tones=np.zeros_like(t)
for start,end,freq in [(48,54,5000),(54,60,3000),(75,82,3000)]:
 idx=(t>=start)&(t<end); rel=t[idx]-start; env=np.minimum(1,rel/.15)*np.minimum(1,(end-start-rel)/.2); tones[idx]=.30*env*np.cos(2*np.pi*freq*rel)
with wave.open(str(SCR/'tones.wav'),'wb') as w: w.setnchannels(1); w.setsampwidth(2); w.setframerate(sr); w.writeframes((np.clip(tones,-1,1)*32767).astype('<i2').tobytes())
# normalize voice to 95.5 sec visual, mix tones softly beneath speech in listen segment
out=OUT/'采样与混叠_教学短片.mp4'
cmd=[enc,'-y','-v','error','-i',str(video),'-i',str(OUT/'narration.mp3'),'-i',str(SCR/'tones.wav'),'-filter_complex','[1:a]aresample=48000,volume=1.25,apad=pad_dur=111.5,atrim=0:111.5[v];[2:a]volume=0.20[t];[v][t]amix=inputs=2:duration=first:dropout_transition=0[a]','-map','0:v:0','-map','[a]','-c:v','copy','-c:a','aac','-b:a','192k','-t',str(seconds),'-movflags','+faststart',str(out)]
subprocess.run(cmd,check=True)
print(out)





