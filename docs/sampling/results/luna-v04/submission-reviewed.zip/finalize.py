from pathlib import Path
import imageio_ffmpeg,subprocess
root=Path(__file__).resolve().parent.parent; out=root/'submission'; enc=imageio_ffmpeg.get_ffmpeg_exe()
video=root/'scratch'/'picture.mp4'; voice=out/'narration.mp3'; tones=root/'scratch'/'tones.wav'; srt=out/'字幕.srt'; final=out/'采样与混叠_教学短片.mp4'
def ts(x):
 h=int(x//3600); m=int(x%3600//60); s=x%60; return f'{h:02}:{m:02}:{s:06.3f}'.replace('.',',')
paras=[
('问题：采样率不足，声音为什么会变样？升到更高采样率能补救吗？看一个逐点可核对的例子。',0,7.5),
('原信号是 5 kHz 余弦，每秒振荡五千次。实验每秒只取 8,000 个样本。橙线是连续信号，蓝点是记录值。下方慢速展开横轴，样本仍取自原信号同一时刻；这不是声音慢放。',7.5,27),
('现在叠加 3 kHz 余弦。8 kHz 采样时，5 kHz 与 3 kHz 在每个采样时刻的值完全相同：频率和相位差对应整圈。蓝点无法告诉我们原来是五千还是三千赫兹，这就是混叠。图中逐点重合，表明两种波形有相同样本。',27,49),
('听原始 5 kHz 音，再听由这组样本重建的 3 kHz 音。统一用 48 kHz 播放，音高对应各自的信号频率，时长不变。',49,62),
('把 8 kHz 样本转换到 32 kHz，并保持时长。绿色新增点由插值产生；它让表示更密，却没有重新测量。听升采样结果，仍是 3 kHz，不能自动回到 5 kHz。只改采样率标记会改变播放速度和音高；这里做的是实际转换。',62,85),
('结论：带限基带信号的理想重建通常要求采样率严格大于最高频率的两倍，实际滤波还需余量。是否采够取决于带宽。升采样不能保证找回混叠前的信息。若降采样前用抗混叠低通滤掉带外成分，那是避免混叠，不是恢复这些成分。听感还会受重建滤波和播放设备影响。',85,111.5)]
from pathlib import Path
import imageio_ffmpeg,subprocess
root=Path(__file__).resolve().parent.parent; out=root/'submission'; enc=imageio_ffmpeg.get_ffmpeg_exe()
video=root/'scratch'/'picture.mp4'; voice=out/'narration.mp3'; tones=root/'scratch'/'tones.wav'; srt=out/'字幕.srt'; final=out/'采样与混叠_教学短片.mp4'
def ts(x):
 h=int(x//3600); m=int(x%3600//60); s=x%60; return f'{h:02}:{m:02}:{s:06.3f}'.replace('.',',')
paras=[
('问题：采样率不足，声音为什么会变样？升到更高采样率能补救吗？看一个逐点可核对的例子。',0,7.5),
('原信号是 3 kHz 余弦，每秒振荡三千次。实验每秒只取 8,000 个样本。橙线是连续信号，蓝点是记录值。下方慢速展开横轴，样本仍取自原信号同一时刻；这不是声音慢放。',7.5,27),
('现在叠加 5 kHz 余弦。8 kHz 采样时，3 kHz 与 5 kHz 在每个采样时刻的值完全相同：频率和相位差对应整圈。蓝点无法告诉我们原来是三千还是五千赫兹，这就是混叠。图中逐点重合，表明两种波形有相同样本。',27,49),
('听原始 3 kHz 音，再听由这组样本重建的 5 kHz 音。统一用 48 kHz 播放，音高对应各自的信号频率，时长不变。',49,62),
('把 8 kHz 样本转换到 32 kHz，并保持时长。绿色新增点由插值产生；它让表示更密，却没有重新测量。听升采样结果，仍是 5 kHz，不能自动回到 3 kHz。只改采样率标记会改变播放速度和音高；这里做的是实际转换。',62,85),
('结论：带限基带信号的理想重建通常要求采样率严格大于最高频率的两倍，实际滤波还需余量。是否采够取决于带宽。升采样不能保证找回混叠前的信息。若降采样前用抗混叠低通滤掉带外成分，那是避免混叠，不是恢复这些成分。听感还会受重建滤波和播放设备影响。',85,111.5)]
srt.write_text('\n\n'.join(f'{i}\n{ts(a)} --> {ts(b)}\n{line}' for i,(line,a,b) in enumerate(paras,1))+'\n',encoding='utf-8-sig')
cmd=[enc,'-y','-v','error','-i',str(video),'-i',str(voice),'-i',str(tones),'-i',str(srt),'-filter_complex','[1:a]aresample=48000,volume=1.25,apad=pad_dur=111.5,atrim=0:111.5[v];[2:a]volume=0.20[t];[v][t]amix=inputs=2:duration=first:dropout_transition=0[a]','-map','0:v:0','-map','[a]','-map','3:s:0','-c:v','copy','-c:a','aac','-b:a','192k','-c:s','mov_text','-t','111.5','-movflags','+faststart',str(final)]
subprocess.run(cmd,check=True)
# standalone copy of final mixed playback audio
subprocess.run([enc,'-y','-v','error','-i',str(final),'-vn','-ac','2','-ar','48000','-c:a','pcm_s16le',str(out/'实际音轨.wav')],check=True)


