import sys,math,subprocess
from pathlib import Path
ROOT=Path(__file__).parent
TOOLS=ROOT.parent/'candidate'/'tools'
sys.path.insert(0,str(TOOLS))
from animation import render,font,polyline
import numpy as np
from PIL import Image
W,H=1280,720
def draw(t,d):
 f=font(29); small=font(22); title=font(40)
 d.rectangle((0,0,W,105),fill='#12243a'); d.text((54,25),'采样率与混叠',font=title,fill='white')
 d.text((900,38),'信号实验室  /  01',font=small,fill='#b9d9d0')
 stage=min(int(t//12),4); local=t-stage*12
 heads=['每秒记录几次？','两种频率，同一条信号','足够采样：20 Hz','连续降低采样率','欠采样：10 Hz → 混叠']
 d.text((62,132),heads[stage],font=title,fill='#172c32')
 fs=20 if stage<3 else max(10,20-10*min(local/8,1))
 if stage==4: fs=10
 low=2; high=7; span=1.5
 box=(100,245,1170,545)
 d.line((100,395,1170,395),fill='#a6b2b1',width=2)
 dense=[(x,0.55*math.sin(2*math.pi*low*x)+0.30*math.sin(2*math.pi*high*x)) for x in np.linspace(0,span,700)]
 polyline(d,dense,box,(0,span),(-1,1),'#152e45',4)
 samplefs=fs
 pts=[i/samplefs for i in range(int(span*samplefs)+1)]
 vals=[.55*math.sin(2*math.pi*low*x)+.30*math.sin(2*math.pi*high*x) for x in pts]
 coords=polyline(d,list(zip(pts,vals)),box,(0,span),(-1,1),'#dc7652',3)
 for i,(x,y) in enumerate(coords):
  r=9 if i==int(local*samplefs)%len(coords) and stage==3 else 6
  d.ellipse((x-r,y-r,x+r,y+r),fill='#dc7652')
 d.text((100,570),f'橙点：每秒取样  {samplefs:.1f} Hz     橙线：2 Hz + 7 Hz 成分相加',font=small,fill='#172c32')
 d.text((100,614),'低频 2 Hz',font=small,fill='#dc7652'); d.text((340,614),'高频 7 Hz',font=small,fill='#287ca3')
 labels=['采样率≠信号频率','两种振荡叠加','20 Hz > 2×7 Hz','点间距变大，点仍跟着走','7 Hz 折到 3 Hz；2 Hz 保留']
 d.rounded_rectangle((770,140,1170,198),radius=14,fill='#dcebe7');d.text((790,153),labels[stage],font=small,fill='#193d3c')
 for k in range(3):
  d.ellipse((54+k*22,680,66+k*22,692),fill=('#dc7652' if k==stage%3 else '#c7cfca'))
if __name__=='__main__':
 render(draw,ROOT/'video_silent.mp4',duration=102,size=(W,H),fps=20)
 # synthesize actual matching sound: low 2 Hz always retained, high 7 Hz becomes 3 Hz only in final state
 import wave,struct
 sr=44100; n=sr*60; samples=np.zeros(n)
 for i in range(5):
  a=i*12*sr;b=(i+1)*12*sr;t=np.arange(b-a)/sr
  high=3 if i==4 else 7
  samples[a:b]=.20*np.sin(2*np.pi*2*t)+.12*np.sin(2*np.pi*high*t)
 samples=np.clip(samples*32767,-32768,32767).astype('<i2')
 with wave.open(str(ROOT/'comparison.wav'),'wb') as w:w.setnchannels(1);w.setsampwidth(2);w.setframerate(sr);w.writeframes(samples.tobytes())
