import subprocess,sys
import imageio_ffmpeg
from pathlib import Path
r=Path(__file__).parent; ff=imageio_ffmpeg.get_ffmpeg_exe()
cmd=[ff,'-y','-i',str(r/'video_silent.mp4'),'-i',str(r/'narration.mp3'),'-i',str(r/'comparison.wav'),'-i',str(r/'captions.srt'),'-filter_complex','[1:a]volume=1.0[v];[2:a]volume=0.18[t];[v][t]amix=inputs=2:duration=first:normalize=0[a]','-map','0:v','-map','[a]','-map','3:s','-c:v','copy','-c:a','aac','-b:a','128k','-c:s','mov_text','-shortest','-movflags','+faststart',str(r/'lesson.mp4')]
subprocess.run(cmd,check=True)
