# 采样率与混叠短片

交付包含 `lesson.mp4`、真实网络合成配音 `narration.mp3`、讲解原文 `narration.txt`、独立字幕 `captions.srt`、声音对比合成 `comparison.wav`、事实映射表 `facts.csv` 和可重建工程 `build.py`。工程调用题包通用动画工具 `candidate/tools/animation.py`；环境依赖 Pillow、NumPy、imageio-ffmpeg，字体使用 Windows 微软雅黑。

图形示例参数：2 Hz 与 7 Hz 正弦相加，采样率从20 Hz连续下降至10 Hz。10 Hz时7 Hz折叠为3 Hz，2 Hz仍保留。音频采用单声道正弦合成作听觉示意，不代表录音或完整采样器滤波实现。

重建：设置 `PYTHONPATH` 指向题包提供依赖目录，运行 `python build.py` 生成无声画面及对比wav；配音通过 `candidate/tools/speak.py` 根据 `narration.txt` 生成。最终封装用FFmpeg合并画面、配音、对比音和字幕。
