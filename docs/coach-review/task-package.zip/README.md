# AG 五路战术大屏 v2 · 官播声画联动

本版在原 AG 对 RW 第一局的五路任务中新增官播主声道、底部解说重点字幕及选手窗口高亮。

将 candidate/task.md 与 candidate/commentary.m4a 发放给 Agent。按 video-sources.json 的五路来源链接和 requested_cut_s 准备对应 MP4，保留各自起点及原始偏移，放入 candidate/。五路视频采用地址提供，ZIP 不内嵌录像。

官播音轨来自 https://www.bilibili.com/video/BV1tyH76XEgz/?p=1 ，截取源播放秒数 802.000–1825.622563，AAC 原声复制，覆盖与轩染录像相同的整局片段。官播画面不发放给参测模型。音轨哈希与截取信息在 video-sources.json 中。

交付 dashboard.mp4、timeline.json、commentary.json，完整要求以 candidate/task.md 为准。本 ZIP 不包含官方伤害参考、五处声画节点答案、ASR 转写或评分实检材料。

历史 Astra 31/100 与 Sol 19/100 属于未加官播联动要求的 v1，不是本版的测试结果。v2 尚未参测。
