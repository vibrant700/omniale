# AG 五人第一视角战术大屏题包

将五路录像按表中的文件名保存到 candidate/，与原始题面 candidate/task.md 一同发给 Agent。

素材链接指向原始分 P。以 video-sources.json 记录的 requested_cut_s 为截取位置，从视频起点截到水晶告破，并保留画面与音轨。该文件同时记录本次评测所用 MP4 的尺寸、时长和 SHA‑256。来源站点提供的码率或封装版本可能随时间变化。

| 选手 | 保存文件名 | 原始视频 | 截取时长（秒） |
|---|---|---|---:|
| 轩染 | xuanran.mp4 | [P1](https://www.bilibili.com/video/BV1kwHp6dEkR/?p=1) | 1023.5 |
| 钟意 | zhongyi.mp4 | [P4](https://www.bilibili.com/video/BV1kwHp6dEkR/?p=4) | 1021.867 |
| 长生 | changsheng.mp4 | [P7](https://www.bilibili.com/video/BV1kwHp6dEkR/?p=7) | 1023.467 |
| 一诺 | yinuo.mp4 | [P10](https://www.bilibili.com/video/BV1kwHp6dEkR/?p=10) | 1023.7 |
| 大帅 | dashuai.mp4 | [P13](https://www.bilibili.com/video/BV1kwHp6dEkR/?p=13) | 1019.367 |
