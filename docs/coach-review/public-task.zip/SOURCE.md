原录像不重复打包。来源：https://huggingface.co/datasets/ZhaokunYan/OmniGame-Bench
视频ID：game_moba_lol_fp_001
https://www.youtube.com/watch?v=10QbqBfysPw
SHA256：94ff81bdd8ee29e54a1b8cf387a9556ef92dd04b6d965292f9ccabf6d0a52f8b
