https://huggingface.co/datasets/ZhaokunYan/OmniGame-Bench
视频ID：game_moba_lol_fp_001
https://www.youtube.com/watch?v=10QbqBfysPw
