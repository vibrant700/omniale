#!/usr/bin/env bash
set -euo pipefail
here="$(cd "$(dirname "$0")" && pwd)"
work="${WORK:-$here/render_work}"
mkdir -p "$work/frames"

python3 "$here/sound/mix.py" --output "$work/flight.wav"
"${BLENDER:-blender}" -b "$here/scene.blend" -P "$here/render.py" \
    -o "$work/frames/T1_" -F PNG -a
ffmpeg -hide_banner -loglevel warning -y -framerate 30 -start_number 0 \
    -i "$work/frames/T1_%04d.png" -i "$work/flight.wav" \
    -map 0:v:0 -map 1:a:0 \
    -vf "scale=out_color_matrix=bt709:out_range=tv,format=yuv420p" \
    -c:v libx264 -crf 15 -preset slow -colorspace bt709 \
    -color_primaries bt709 -color_trc bt709 -c:a aac -b:a 256k -ar 48000 \
    -t 3.333333333 -movflags +faststart "$work/T1.mp4"
printf '%s\n' "$work/T1.mp4"
