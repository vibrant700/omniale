"""Render the phoenix Foley score. Edit cues.json, then run python3 mix.py."""
import argparse
import json
from pathlib import Path

import numpy as np
from scipy import signal
from scipy.io import wavfile

HERE = Path(__file__).resolve().parent
ANCHOR = {
    "sweep_broad": 0.21, "sweep_light": 0.11, "air_long": 0.65,
    "air_low": 0.30, "feather_rustle": 0.14,
}


def db(gain):
    return 10.0 ** (gain / 20.0)


def render(cuefile, output, stemdir=None):
    score = json.loads(cuefile.read_text(encoding="utf-8"))
    sr, fps = score["sample_rate"], score["fps"]
    length = round(score["frame_count"] * sr / fps)
    buses = {k: np.zeros((length, 2)) for k in score["bus_gain_db"]}
    samples = {}
    for name in ANCHOR:
        hz, data = wavfile.read(str(HERE / "sources" / (name + ".wav")))
        if hz != sr or data.dtype != np.int16 or data.shape[1] != 2:
            raise ValueError(f"{name}: expected {sr} Hz stereo PCM16")
        samples[name] = data.astype(float) / 32768

    def play(bus, name, peak_frame, speed, gain, pan, band, spread=1.0, reverse=False):
        data = samples[name][::-1] if reverse else samples[name]
        x = np.arange(0, len(data) - 1, speed)
        v = np.column_stack([np.interp(x, np.arange(len(data)), ch) for ch in data.T])
        eq = signal.butter(2, np.asarray(band) / (sr * 0.5), btype="bandpass", output="sos")
        v = signal.sosfilt(eq, v, axis=0)
        mid = v.mean(axis=1, keepdims=True)
        v = (mid + (v - mid) * spread) * np.sqrt([1.0 - pan, 1.0 + pan])
        fade = min(360, len(v) // 3)
        ramp = np.sin(np.linspace(0, np.pi / 2, fade)) ** 2
        v[:fade] *= ramp[:, None]
        v[-fade:] *= ramp[::-1, None]
        anchor = (len(data) / sr - ANCHOR[name]) if reverse else ANCHOR[name]
        start = round((peak_frame / fps - anchor / speed) * sr)
        lo, hi = max(0, start), min(length, start + len(v))
        if hi > lo:
            buses[bus][lo:hi] += db(gain) * v[lo-start:hi-start]

    for i, beat in enumerate(score["beats"]):
        down, up, fold = (beat[k] for k in ("down_frame", "up_frame", "fold_frame"))
        rate, level, pan = (beat[k] for k in ("speed", "gain_db", "pan"))
        play("wake", "air_long", down - 1.2, rate * 0.92, level, -0.04, (90, 3200), 0.65)
        play("downstroke", "sweep_broad", down, rate, level, pan, (95, 10100), 0.90)
        play("pressure", "air_low", down + 0.65, rate * 1.07, level, -0.02, (48, 1150), 0.48)
        play("barbs", "feather_rustle", fold - 0.35, rate * 1.12, level - 0.8, -pan,
             (1100, 10400), 0.85, reverse=i % 2 == 1)
        play("recovery", "sweep_light", up, rate * 0.90, level - 0.9, -0.035, (430, 7300), 0.78)
        play("barbs", "feather_rustle", up + 2.4, rate * 1.31, level - 3.6, pan,
             (1750, 11500), 0.90)

    for name, value in buses.items():
        value *= db(score["bus_gain_db"][name])
    mix = sum(buses.values())
    # Brief equal-power fades preserve the four stroke transients at the cut.
    env = np.ones(length)
    for at_start, duration in [(True, 0.035), (False, 0.044)]:
        n = round(duration * sr)
        a = np.sin(np.linspace(0, np.pi / 2, n)) ** 2
        if at_start:
            env[:n] = a
        else:
            env[-n:] = a[::-1]
    mix *= env[:, None]
    trim = db(score["master_peak_db"]) / max(np.max(np.abs(mix)), 1e-8)
    output.parent.mkdir(parents=True, exist_ok=True)
    to_pcm = lambda v: np.rint(np.clip(v, -1, 1) * 32767).astype("<i2")
    wavfile.write(str(output), sr, to_pcm(mix * trim))
    if stemdir:
        stemdir.mkdir(parents=True, exist_ok=True)
        for name, value in buses.items():
            wavfile.write(str(stemdir / (name + ".wav")), sr, to_pcm(value * env[:, None] * trim))
    print(f"{output}: {length} samples/channel, stereo, {sr} Hz")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--cues", type=Path, default=HERE / "cues.json")
    parser.add_argument("--output", type=Path, default=HERE / "flight.wav")
    parser.add_argument("--stems", type=Path, help="Also write five post-fader aligned stems.")
    args = parser.parse_args()
    render(args.cues, args.output, args.stems)
