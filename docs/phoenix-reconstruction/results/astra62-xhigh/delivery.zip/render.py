"""Blender render setup: blender -b scene.blend -P render.py -o ... -a"""
import bpy

scene = bpy.context.scene
prefs = bpy.context.preferences.addons["cycles"].preferences
scene.cycles.device = "CPU"
for backend in ("CUDA", "OPTIX", "HIP", "METAL", "ONEAPI"):
    try:
        prefs.compute_device_type = backend
        prefs.refresh_devices()
        cards = [d for d in prefs.devices if d.type == backend]
        if cards:
            for d in prefs.devices:
                d.use = d.type == backend
            scene.cycles.device = "GPU"
            print("Cycles:", ", ".join(d.name for d in cards), flush=True)
            break
    except (TypeError, RuntimeError):
        continue
scene.render.use_persistent_data = True
